<?php
session_start();
define('ROOT_URL', 'http://localhost/finalphp/');
define('DB_HOST', 'localhost');
define('DB_USER', 'Alternese');
define('DB_PASS','Alternese1234');
define('DB_NAME', 'finalphp');