-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 16, 2023 at 11:36 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `finalphp`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) UNSIGNED NOT NULL,
  `title` varchar(50) NOT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `title`, `description`) VALUES
(1, 'Food', 'Food is one of the most essential neccessity to my life'),
(2, 'Animals', 'This is the section of Animals '),
(3, 'Art', 'This is an Art studio'),
(4, 'Science and technology', 'This is the description of science and technology'),
(5, 'Uncategorized', 'This is the description of uncategorized categories'),
(6, 'Wildlife', 'This is the description of Wildlife...');

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` int(11) UNSIGNED NOT NULL,
  `title` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `thumbnail` varchar(255) NOT NULL,
  `date_time` timestamp NOT NULL DEFAULT current_timestamp(),
  `category_id` int(11) UNSIGNED DEFAULT NULL,
  `author_id` int(11) UNSIGNED NOT NULL,
  `is_featured` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `title`, `body`, `thumbnail`, `date_time`, `category_id`, `author_id`, `is_featured`) VALUES
(4, 'excuse me this is my edit post', 'For as long as humanity has existed, art has been part of our lives. For many years, people have been creating and enjoying art.  It expresses emotions or expression of life. It is one such creation that enables interpretation of any kind.\r\n\r\nIt is a skill that applies to music, painting, poetry, dance and more. Moreover, nature is no less than art. For instance, if nature creates something unique, it is also art. Artists use their artwork for passing along their feelings.\r\n\r\nThus, art and artists bring value to society and have been doing so throughout history. Art gives us an innovative way to view the world or society around us. Most important thing is that it lets us interpret it on our own individual experiences and associations.\r\n\r\nArt is similar to live which has many definitions and examples. What is constant is that art is not perfect or does not revolve around perfection. It is something that continues growing and developing to express emotions, thoughts and human capacities.', '1681900485mu.jpg', '2023-04-17 10:14:10', 2, 3, 0),
(7, 'Hello this is the AI file', ' Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#039;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularized in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.', '1681831337e2.jpg', '2023-04-18 15:11:45', 4, 6, 0),
(8, 'This is the wild life photo', 'Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of &quot;de Finibus Bonorum et Malorum&quot; (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, &quot;Lorem ipsum dolor sit amet..&quot;, comes from a line in section 1.10.32.\r\n\r\n', '1684140808nature852.png', '2023-04-19 10:29:30', 6, 6, 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) UNSIGNED NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `avatar` varchar(255) NOT NULL,
  `is_admin` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `firstname`, `lastname`, `username`, `email`, `password`, `avatar`, `is_admin`) VALUES
(1, 'Aung Tunn', 'Lin', 'DIAN', 'Gerard@gmail.com', '$2y$10$0vgtGvX.9cVmHcr./8Ociu/fcPZR9m2BL4DeEb5SdrT2QBE9nIlbW', '1681549104icon.png', 0),
(3, 'Selena', 'Gomez', 'Selgo', 'Gomezsel34@gmail.com', '$2y$10$dZ3urPhx8X2O1MCoR0SQvOKkaydxTnGB15lrH8NiRUQbzyYC5gEAa', '1681641146download.jpg', 1),
(6, 'Sing', 'is', 'sing', 'Sing45@gmail.com', '$2y$10$o2aLpsQtxw7h6FGMnxwG5uhWcU3r.hYC0LZY3dRCzi2OoG8RSpZEm', '1681830478wizard.png', 0),
(7, 'Su', 'Hlaing', 'Teacher Su', 'hlaing@gmail.com', '$2y$10$VqSrLJUxpfDUv1JZq5.Yzuio1BXfFOr0SrEl1164wQSYwi7ZxzpkC', '1681983661girl.jpg', 0),
(9, 'Tanat', 'Arora', 'Naveen', 'Tanat78@gmail.com', '$2y$10$1xGPIFEpHh2Cnr8lJBMHEOs7m9zP2faJKt7g2MfubND1Yepe03E02', '1684130150messi.jpg', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK_finalphp_category` (`category_id`),
  ADD KEY `FK_finalphp_author` (`author_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `posts`
--
ALTER TABLE `posts`
  ADD CONSTRAINT `FK_finalphp_author` FOREIGN KEY (`author_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `FK_finalphp_category` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE SET NULL;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
