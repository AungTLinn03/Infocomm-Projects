<!DOCTYPE html>

<head>
    <style>
/*ninja*/
.ninjer{
  --uib-size: 2.8rem;
  --uib-speed: .9s;
  --uib-color: white;
  position: absolute;
  display: -webkit-box;
  display: -ms-flexbox;
  display: flex;
  -webkit-box-align: center;
      -ms-flex-align: center;
          align-items: center;
  -webkit-box-pack: start;
      -ms-flex-pack: start;
          justify-content: flex-start;
  height: var(--uib-size);
  width: var(--uib-size);
  left:50%;


}

.ninjers {
  position: absolute;
  top: 0;
  left: 0;
  display: -webkit-box;
  display: -ms-flexbox;
  display: flex;
  -webkit-box-align: center;
      -ms-flex-align: center;
          align-items: center;
  -webkit-box-pack: start;
      -ms-flex-pack: start;
          justify-content: flex-start;
  height: 100%;
  width: 100%;
}

.ninjers::before {
  content: '';
  height: 20%;
  width: 20%;
  border-radius: 50%;
  background-color: var(--uib-color);
  -webkit-transform: scale(0);
      -ms-transform: scale(0);
          transform: scale(0);
  opacity: 0.5;
  -webkit-animation: pulse0112 calc(var(--uib-speed) * 1.111) ease-in-out infinite;
          animation: pulse0112 calc(var(--uib-speed) * 1.111) ease-in-out infinite;
  -webkit-box-shadow: 0 0 20px rgba(18, 31, 53, 0.3);
          box-shadow: 0 0 20px rgba(18, 31, 53, 0.3);
   padding-bottom: 222px;
}

.ninjers:nth-child(2) {
  -webkit-transform: rotate(45deg);
      -ms-transform: rotate(45deg);
          transform: rotate(45deg);
}

.ninjers:nth-child(2)::before {
  -webkit-animation-delay: calc(var(--uib-speed) * -0.875);
          animation-delay: calc(var(--uib-speed) * -0.875);
  
}

.ninjers:nth-child(3) {
  -webkit-transform: rotate(90deg);
      -ms-transform: rotate(90deg);
          transform: rotate(90deg);
}

.ninjers:nth-child(3)::before {
  -webkit-animation-delay: calc(var(--uib-speed) * -0.75);
          animation-delay: calc(var(--uib-speed) * -0.75);
}

.ninjers:nth-child(4) {
  -webkit-transform: rotate(135deg);
      -ms-transform: rotate(135deg);
          transform: rotate(135deg);
}

.ninjers:nth-child(4)::before {
  -webkit-animation-delay: calc(var(--uib-speed) * -0.625);
          animation-delay: calc(var(--uib-speed) * -0.625);
}

.ninjers:nth-child(5) {
  -webkit-transform: rotate(180deg);
      -ms-transform: rotate(180deg);
          transform: rotate(180deg);
}

.ninjers:nth-child(5)::before {
  -webkit-animation-delay: calc(var(--uib-speed) * -0.5);
          animation-delay: calc(var(--uib-speed) * -0.5);
}

.ninjers:nth-child(6) {
  -webkit-transform: rotate(225deg);
      -ms-transform: rotate(225deg);
          transform: rotate(225deg);
}

.ninjers:nth-child(6)::before {
  -webkit-animation-delay: calc(var(--uib-speed) * -0.375);
          animation-delay: calc(var(--uib-speed) * -0.375);
}

.dot-spinner__dot:nth-child(7) {
  -webkit-transform: rotate(270deg);
      -ms-transform: rotate(270deg);
          transform: rotate(270deg);
}

.ninjers:nth-child(7)::before {
  -webkit-animation-delay: calc(var(--uib-speed) * -0.25);
          animation-delay: calc(var(--uib-speed) * -0.25);
}

.ninjers:nth-child(8) {
  -webkit-transform: rotate(315deg);
      -ms-transform: rotate(315deg);
          transform: rotate(315deg);
}

.ninjers:nth-child(8)::before {
  -webkit-animation-delay: calc(var(--uib-speed) * -0.125);
          animation-delay: calc(var(--uib-speed) * -0.125);
}

@-webkit-keyframes pulse0112 {
  0%,
  100% {
    -webkit-transform: scale(0);
            transform: scale(0);
    opacity: 0.5;
  }

  50% {
    -webkit-transform: scale(1);
            transform: scale(1);
    opacity: 1;
  }
}

@keyframes pulse0112 {
  0%,
  100% {
    -webkit-transform: scale(0);
            transform: scale(0);
    opacity: 0.5;
  }

  50% {
    -webkit-transform: scale(1);
            transform: scale(1);
    opacity: 1;
  }
}

/*pencil */
.pencil {
  display: block;
  width: 10em;
  height: 10em;
  left:80%;
  bottom:-30%;
  position:absolute;
  
  
}

.pencil__body1,
.pencil__body2,
.pencil__body3,
.pencil__eraser,
.pencil__eraser-skew,
.pencil__point,
.pencil__rotate,
.pencil__stroke {
  -webkit-animation-duration: 3s;
          animation-duration: 3s;
  -webkit-animation-timing-function: linear;
          animation-timing-function: linear;
  -webkit-animation-iteration-count: infinite;
          animation-iteration-count: infinite;
}

.pencil__body1,
.pencil__body2,
.pencil__body3 {
  -webkit-transform: rotate(-90deg);
      -ms-transform: rotate(-90deg);
          transform: rotate(-90deg);
}

.pencil__body1 {
  -webkit-animation-name: pencilBody1;
          animation-name: pencilBody1;
}

.pencil__body2 {
  -webkit-animation-name: pencilBody2;
          animation-name: pencilBody2;
}

.pencil__body3 {
  -webkit-animation-name: pencilBody3;
          animation-name: pencilBody3;
}

.pencil__eraser {
  -webkit-animation-name: pencilEraser;
          animation-name: pencilEraser;
  -webkit-transform: rotate(-90deg) translate(49px,0);
      -ms-transform: rotate(-90deg) translate(49px,0);
          transform: rotate(-90deg) translate(49px,0);
}

.pencil__eraser-skew {
  -webkit-animation-name: pencilEraserSkew;
          animation-name: pencilEraserSkew;
  -webkit-animation-timing-function: ease-in-out;
          animation-timing-function: ease-in-out;
}

.pencil__point {
  -webkit-animation-name: pencilPoint;
          animation-name: pencilPoint;
  -webkit-transform: rotate(-90deg) translate(49px,-30px);
      -ms-transform: rotate(-90deg) translate(49px,-30px);
          transform: rotate(-90deg) translate(49px,-30px);
}

.pencil__rotate {
  -webkit-animation-name: pencilRotate;
          animation-name: pencilRotate;
}

.pencil__stroke {
  -webkit-animation-name: pencilStroke;
          animation-name: pencilStroke;
  -webkit-transform: translate(100px,100px) rotate(-113deg);
      -ms-transform: translate(100px,100px) rotate(-113deg);
          transform: translate(100px,100px) rotate(-113deg);
}

/* Animations */
@-webkit-keyframes pencilBody1 {
  from,
	to {
    stroke-dashoffset: 351.86;
    -webkit-transform: rotate(-90deg);
            transform: rotate(-90deg);
  }

  50% {
    stroke-dashoffset: 150.8;
 /* 3/8 of diameter */
    -webkit-transform: rotate(-225deg);
            transform: rotate(-225deg);
  }
}
@keyframes pencilBody1 {
  from,
	to {
    stroke-dashoffset: 351.86;
    -webkit-transform: rotate(-90deg);
            transform: rotate(-90deg);
  }

  50% {
    stroke-dashoffset: 150.8;
 /* 3/8 of diameter */
    -webkit-transform: rotate(-225deg);
            transform: rotate(-225deg);
  }
}

@-webkit-keyframes pencilBody2 {
  from,
	to {
    stroke-dashoffset: 406.84;
    -webkit-transform: rotate(-90deg);
            transform: rotate(-90deg);
  }

  50% {
    stroke-dashoffset: 174.36;
    -webkit-transform: rotate(-225deg);
            transform: rotate(-225deg);
  }
}

@keyframes pencilBody2 {
  from,
	to {
    stroke-dashoffset: 406.84;
    -webkit-transform: rotate(-90deg);
            transform: rotate(-90deg);
  }

  50% {
    stroke-dashoffset: 174.36;
    -webkit-transform: rotate(-225deg);
            transform: rotate(-225deg);
  }
}

@-webkit-keyframes pencilBody3 {
  from,
	to {
    stroke-dashoffset: 296.88;
    -webkit-transform: rotate(-90deg);
            transform: rotate(-90deg);
  }

  50% {
    stroke-dashoffset: 127.23;
    -webkit-transform: rotate(-225deg);
            transform: rotate(-225deg);
  }
}

@keyframes pencilBody3 {
  from,
	to {
    stroke-dashoffset: 296.88;
    -webkit-transform: rotate(-90deg);
            transform: rotate(-90deg);
  }

  50% {
    stroke-dashoffset: 127.23;
    -webkit-transform: rotate(-225deg);
            transform: rotate(-225deg);
  }
}

@-webkit-keyframes pencilEraser {
  from,
	to {
    -webkit-transform: rotate(-45deg) translate(49px,0);
            transform: rotate(-45deg) translate(49px,0);
  }

  50% {
    -webkit-transform: rotate(0deg) translate(49px,0);
            transform: rotate(0deg) translate(49px,0);
  }
}

@keyframes pencilEraser {
  from,
	to {
    -webkit-transform: rotate(-45deg) translate(49px,0);
            transform: rotate(-45deg) translate(49px,0);
  }

  50% {
    -webkit-transform: rotate(0deg) translate(49px,0);
            transform: rotate(0deg) translate(49px,0);
  }
}

@-webkit-keyframes pencilEraserSkew {
  from,
	32.5%,
	67.5%,
	to {
    -webkit-transform: skewX(0);
            transform: skewX(0);
  }

  35%,
	65% {
    -webkit-transform: skewX(-4deg);
            transform: skewX(-4deg);
  }

  37.5%, 
	62.5% {
    -webkit-transform: skewX(8deg);
            transform: skewX(8deg);
  }

  40%,
	45%,
	50%,
	55%,
	60% {
    -webkit-transform: skewX(-15deg);
            transform: skewX(-15deg);
  }

  42.5%,
	47.5%,
	52.5%,
	57.5% {
    -webkit-transform: skewX(15deg);
            transform: skewX(15deg);
  }
}

@keyframes pencilEraserSkew {
  from,
	32.5%,
	67.5%,
	to {
    -webkit-transform: skewX(0);
            transform: skewX(0);
  }

  35%,
	65% {
    -webkit-transform: skewX(-4deg);
            transform: skewX(-4deg);
  }

  37.5%, 
	62.5% {
    -webkit-transform: skewX(8deg);
            transform: skewX(8deg);
  }

  40%,
	45%,
	50%,
	55%,
	60% {
    -webkit-transform: skewX(-15deg);
            transform: skewX(-15deg);
  }

  42.5%,
	47.5%,
	52.5%,
	57.5% {
    -webkit-transform: skewX(15deg);
            transform: skewX(15deg);
  }
}

@-webkit-keyframes pencilPoint {
  from,
	to {
    -webkit-transform: rotate(-90deg) translate(49px,-30px);
            transform: rotate(-90deg) translate(49px,-30px);
  }

  50% {
    -webkit-transform: rotate(-225deg) translate(49px,-30px);
            transform: rotate(-225deg) translate(49px,-30px);
  }
}

@keyframes pencilPoint {
  from,
	to {
    -webkit-transform: rotate(-90deg) translate(49px,-30px);
            transform: rotate(-90deg) translate(49px,-30px);
  }

  50% {
    -webkit-transform: rotate(-225deg) translate(49px,-30px);
            transform: rotate(-225deg) translate(49px,-30px);
  }
}

@-webkit-keyframes pencilRotate {
  from {
    -webkit-transform: translate(100px,100px) rotate(0);
            transform: translate(100px,100px) rotate(0);
  }

  to {
    -webkit-transform: translate(100px,100px) rotate(720deg);
            transform: translate(100px,100px) rotate(720deg);
  }
}

@keyframes pencilRotate {
  from {
    -webkit-transform: translate(100px,100px) rotate(0);
            transform: translate(100px,100px) rotate(0);
  }

  to {
    -webkit-transform: translate(100px,100px) rotate(720deg);
            transform: translate(100px,100px) rotate(720deg);
  }
}

@-webkit-keyframes pencilStroke {
  from {
    stroke-dashoffset: 439.82;
    -webkit-transform: translate(100px,100px) rotate(-113deg);
            transform: translate(100px,100px) rotate(-113deg);
  }

  50% {
    stroke-dashoffset: 164.93;
    -webkit-transform: translate(100px,100px) rotate(-113deg);
            transform: translate(100px,100px) rotate(-113deg);
  }

  75%,
	to {
    stroke-dashoffset: 439.82;
    -webkit-transform: translate(100px,100px) rotate(112deg);
            transform: translate(100px,100px) rotate(112deg);
  }
}

@keyframes pencilStroke {
  from {
    stroke-dashoffset: 439.82;
    -webkit-transform: translate(100px,100px) rotate(-113deg);
            transform: translate(100px,100px) rotate(-113deg);
  }

  50% {
    stroke-dashoffset: 164.93;
    -webkit-transform: translate(100px,100px) rotate(-113deg);
            transform: translate(100px,100px) rotate(-113deg);
  }

  75%,
	to {
    stroke-dashoffset: 439.82;
    -webkit-transform: translate(100px,100px) rotate(112deg);
            transform: translate(100px,100px) rotate(112deg);
  }
}


/*pingpong*/
.pingpong {
            width: 200px;
            height: 60px;
          
            margin-top: 20%;
            margin-left: 50%;
            transform: translate(-50%, -50%);
            top:50%;
        }
        .ballpong {
            width: 20px;
            height: 20px;
            position: absolute;
            border-radius: 50%;
            left: 15%;
            animation: ball .5s alternate infinite ease;
        }
        @keyframes ball {
            0% {
                top: 60px;
                height: 5px;
                border-radius: 50px 50px 25px 25px;
                transform: scaleX(1.7);
                background-color: #FF3EA5FF;
            }
            40% {
                height: 20px;
                border-radius: 50%;
                transform: scaleX(1);
                background-color: #EDFF00FF;
            }
            100% {
                top: 0%;
                background-color: #00A4CCFF;
            }
        }
        .ballpong:nth-child(2) {
            left: 45%;
            animation-delay: .2s;
        }
        .ballpong:nth-child(3) {
            left: auto;
            right: 15%;
            animation-delay: .3s;
        }
        .shadowpong {
            width: 20px;
            height: 4px;
            border-radius: 50%;
            background-color: #ffffff59;
            position: absolute;
            top: 62px;
            z-index: -1;
            left: 15%;
            filter: blur(1px);
            animation: shadow .5s alternate infinite ease;
        }
        @keyframes shadow {
            0% {
                transform: scaleX(1.5);
                background-color: #ff3ea56b;
            }
            40% {
                transform: scaleX(1);
                opacity: .7;
                background-color: #edff0066;
            }
            100% {
                transform: scaleX(.2);
                opacity: .4;
                background-color: #00a4cc6b;
            }
        }
        .shadowpong:nth-child(4) {
            left: 45%;
            animation-delay: .2s;
        }
        .shadowpong:nth-child(5) {
            left: auto;
            right: 15%;
            animation-delay: .3s;
        }

        /*pyramid*/



        .pyramid-loader {
  position:absolute;
  width: 300px;
  height: 300px;
  display: block;
  -webkit-transform-style: preserve-3d;
          transform-style: preserve-3d;
  -webkit-transform: rotateX(-20deg);
          transform: rotateX(-20deg);
          left:3%;
          bottom:-80%;
          
}

.wrapper {
  position: relative;
  width: 100%;
  height: 100%;
  -webkit-transform-style: preserve-3d;
          transform-style: preserve-3d;
  -webkit-animation: spin 4s linear infinite;
          animation: spin 4s linear infinite;
}

@-webkit-keyframes spin {
  100% {
    -webkit-transform: rotateY(360deg);
            transform: rotateY(360deg);
  }
}

@keyframes spin {
  100% {
    -webkit-transform: rotateY(360deg);
            transform: rotateY(360deg);
  }
}

.pyramid-loader .wrapper .side {
  width: 70px;
  height: 70px;
/* you can choose any gradient or color you want */
  /* background: radial-gradient( #2F2585 10%, #F028FD 70%, #2BDEAC 120%); */
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  margin: auto;
  -webkit-transform-origin: center top;
      -ms-transform-origin: center top;
          transform-origin: center top;
  -webkit-clip-path: polygon(50% 0%, 0% 100%, 100% 100%);
          clip-path: polygon(50% 0%, 0% 100%, 100% 100%);
}

.pyramid-loader .wrapper .side1 {
  -webkit-transform: rotateZ(-30deg) rotateY(90deg);
          transform: rotateZ(-30deg) rotateY(90deg);
  background: conic-gradient( #2BDEAC, #F028FD, #D8CCE6, #2F2585);
}

.pyramid-loader .wrapper .side2 {
  -webkit-transform: rotateZ(30deg) rotateY(90deg);
          transform: rotateZ(30deg) rotateY(90deg);
  background: conic-gradient( #2F2585, #D8CCE6, #F028FD, #2BDEAC);

}

.pyramid-loader .wrapper .side3 {
  -webkit-transform: rotateX(30deg);
          transform: rotateX(30deg);
  background: conic-gradient( #2F2585, #D8CCE6, #F028FD, #2BDEAC);

}

.pyramid-loader .wrapper .side4 {
  -webkit-transform: rotateX(-30deg);
          transform: rotateX(-30deg);
  background: conic-gradient( #2BDEAC, #F028FD, #D8CCE6, #2F2585);

}

.pyramid-loader .wrapper .shadow {
  width: 60px;
  height: 60px;
  background: #8B5AD5;
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  margin: auto;
  -webkit-transform: rotateX(90deg) translateZ(-40px);
          transform: rotateX(90deg) translateZ(-40px);
  -webkit-filter: blur(12px);
          filter: blur(12px);
}

/*spinner*/
.spinner {
 position: absolute;
 top:20%;
 right:10%;
 width: 60px;
 height: 60px;
 border-radius: 50%;

}

.spinner::before,
.spinner:after {
 content: "";
 position: absolute;
 border-radius: inherit;
}

.spinner:before {
 width: 100%;
 height: 100%;
 background-image: -webkit-gradient(linear, left bottom, left top, from(#ff00cc), to(#333399));
 background-image: linear-gradient(0deg, #ff00cc 0%, #333399 100%);
 -webkit-animation: spin8932 .5s infinite linear;
         animation: spin8932 .5s infinite linear;
}

.spinner:after {
 width: 85%;
 height: 85%;
 background-color: #212121;
 top: 50%;
 left: 50%;
 -webkit-transform: translate(-50%, -50%);
     -ms-transform: translate(-50%, -50%);
         transform: translate(-50%, -50%);
}

@-webkit-keyframes spin8932 {
 to {
  -webkit-transform: rotate(360deg);
          transform: rotate(360deg);
 }
}

@keyframes spin8932 {
 to {
  -webkit-transform: rotate(360deg);
          transform: rotate(360deg);
 }
}


/*lamp

.lamp {
  position:absolute;
margin-bottom:45%;

  right:20%;
  
  -webkit-transform: translate(-50%, -50%);
      -ms-transform: translate(-50%, -50%);
          transform: translate(-50%, -50%);
  height: 30em;
  min-height: 300px;
  width: 13em;
  min-width: calc(300px * 3 / 7);
  background: #0ae89a;
  -webkit-clip-path: polygon(33% 0, 0 70%, 22% 88%, 0 100%, 100% 100%, 78% 88%, 100% 70%, 67% 0);
          clip-path: polygon(33% 0, 0 70%, 22% 88%, 0 100%, 100% 100%, 78% 88%, 100% 70%, 67% 0);
}

.glass {
  background: #b6e1e0;
  width: 100%;
  height: 60%;
  position: absolute;
  bottom: 30%;
  overflow: hidden;
}

.lava {
  -webkit-filter: url("#goo");
          filter: url("#goo");
  position: absolute;
  height: 100%;
  width: 100%;
  top: 0;
  left: 0;
}

.blob {
  border-radius: 50%;
  background: #0ae89a;
  position: absolute;
}

.blob.top {
  width: 100%;
  height: 4%;
  top: -3.7%;
  left: 0;
}

.blob.bottom {
  width: 100%;
  height: 4%;
  bottom: -3%;
  left: 0;
}

.blob:nth-child(1) {
  width: calc(15% * 1.4);
  height: 15%;
  left: 45%;
  bottom: -15%;
  -webkit-animation: blob-one_2 ease-in-out 7s infinite;
          animation: blob-one_2 ease-in-out 7s infinite;
}

.blob:nth-child(2) {
  width: calc(22% * 1.4);
  height: 22%;
  right: 14%;
  bottom: -15%;
  -webkit-animation: blob-two_2 ease-in-out 11s infinite;
          animation: blob-two_2 ease-in-out 11s infinite;
}

.blob:nth-child(3) {
  width: calc(32% * 1.4);
  height: 32%;
  bottom: -15%;
  left: 14%;
  -webkit-animation: blob-three_2 ease-in-out 16s infinite;
          animation: blob-three_2 ease-in-out 16s infinite;
}

@-webkit-keyframes blob-one_2 {
  0%, 100% {
    -webkit-transform: translatey(0);
            transform: translatey(0);
  }

  50% {
    -webkit-transform: translatey(-700%);
            transform: translatey(-700%);
  }
}

@keyframes blob-one_2 {
  0%, 100% {
    -webkit-transform: translatey(0);
            transform: translatey(0);
  }

  50% {
    -webkit-transform: translatey(-700%);
            transform: translatey(-700%);
  }
}

@-webkit-keyframes blob-two_2 {
  0%, 100% {
    -webkit-transform: translatey(0);
            transform: translatey(0);
  }

  50% {
    -webkit-transform: translatey(-420%);
            transform: translatey(-420%);
  }
}

@keyframes blob-two_2 {
  0%, 100% {
    -webkit-transform: translatey(0);
            transform: translatey(0);
  }

  50% {
    -webkit-transform: translatey(-420%);
            transform: translatey(-420%);
  }
}

@-webkit-keyframes blob-three_2 {
  0%, 100% {
    -webkit-transform: translatey(0);
            transform: translatey(0);
  }

  50% {
    -webkit-transform: translatey(-305%);
            transform: translatey(-305%);
  }
}

@keyframes blob-three_2 {
  0%, 100% {
    -webkit-transform: translatey(0);
            transform: translatey(0);
  }

  50% {
    -webkit-transform: translatey(-305%);
            transform: translatey(-305%);
  }
}
*/

/*ring*/
.ringerball {
  width: 10em;
  height: 3em;
  border: 0.3em solid silver;
  border-radius: 3em;
  font-size: 10px;
  border-left-color: hotpink;
  border-right-color: dodgerblue;
  position: absolute;
  animation: spin 3s linear infinite;
  left:10%;
  bottom:30%;
 

}
@keyframes spin {
  to {
    transform: rotate(360deg);
  }
}
.ringerball::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  width: 3em;
  height: 3em;
  border-radius: 50%;
  background-color: dodgerblue;
  animation:
    shift 3s linear infinite,
    change-color 3s linear infinite;
}
@keyframes shift {
  50% {
    left: 7em;
  }
}
@keyframes change-color {
  0%, 55% {
    background-color: dodgerblue;
  }
  5%, 50% {
    background-color: hotpink;
  }
}


/*spaceship*/

.svg-frame {
  position: absolute;
  width: 300px;
  height: 300px;
  -webkit-transform-style: preserve-3d;
          transform-style: preserve-3d;
  display: -webkit-box;
  display: -ms-flexbox;
  display: flex;
  -webkit-box-pack: center;
      -ms-flex-pack: center;
          justify-content: center;
  -webkit-box-align: center;
      -ms-flex-align: center;
          align-items: center;
          left:40%;
          bottom:-75%;
}

.svg-frame svg {
  position: absolute;
  -webkit-transition: .5s;
  transition: .5s;
  z-index: calc(1 - (0.2 * var(--j)));
  -webkit-transform-origin: center;
      -ms-transform-origin: center;
          transform-origin: center;
  width: 344px;
  height: 344px;
  fill: none;
}

.svg-frame:hover svg {
  -webkit-transform: rotate(-80deg) skew(30deg) translateX(calc(45px * var(--i))) translateY(calc(-35px * var(--i)));
      -ms-transform: rotate(-80deg) skew(30deg) translateX(calc(45px * var(--i))) translateY(calc(-35px * var(--i)));
          transform: rotate(-80deg) skew(30deg) translateX(calc(45px * var(--i))) translateY(calc(-35px * var(--i)));
}

.svg-frame svg #center {
  -webkit-transition: .5s;
  transition: .5s;
  -webkit-transform-origin: center;
      -ms-transform-origin: center;
          transform-origin: center;
}

.svg-frame:hover svg #center {
  -webkit-transform: rotate(-30deg) translateX(45px) translateY(-3px);
      -ms-transform: rotate(-30deg) translateX(45px) translateY(-3px);
          transform: rotate(-30deg) translateX(45px) translateY(-3px);
}

#out2 {
  -webkit-animation: rotate16 7s ease-in-out infinite alternate;
          animation: rotate16 7s ease-in-out infinite alternate;
  -webkit-transform-origin: center;
      -ms-transform-origin: center;
          transform-origin: center;
}

#out3 {
  -webkit-animation: rotate16 3s ease-in-out infinite alternate;
          animation: rotate16 3s ease-in-out infinite alternate;
  -webkit-transform-origin: center;
      -ms-transform-origin: center;
          transform-origin: center;
  stroke: #ff0;
}

#inner3,
#inner1 {
  -webkit-animation: rotate16 4s ease-in-out infinite alternate;
          animation: rotate16 4s ease-in-out infinite alternate;
  -webkit-transform-origin: center;
      -ms-transform-origin: center;
          transform-origin: center;
}

#center1 {
  fill: #ff0;
  -webkit-animation: rotate16 2s ease-in-out infinite alternate;
          animation: rotate16 2s ease-in-out infinite alternate;
  -webkit-transform-origin: center;
      -ms-transform-origin: center;
          transform-origin: center;
}

@-webkit-keyframes rotate16 {
  to {
    -webkit-transform: rotate(360deg);
            transform: rotate(360deg);
  }
}

@keyframes rotate16 {
  to {
    -webkit-transform: rotate(360deg);
            transform: rotate(360deg);
  }
}

/*saturn*/


button {
  border: 0;
  background: radial-gradient(ellipse at 50% 50%,black 20%,transparent 72%);
  font-size: 17px;
  height: 200px;
  width: 300px;
  zoom: 1.2;
  position:absolute;
  left:50%;
  top:69%;
}

.main {
  width: 70px;
  margin: auto;
  position: relative;
  -webkit-transform: rotateZ(0deg);
      -ms-transform: rotate(0deg);
          transform: rotateZ(0deg);
  isolation: isolate;
  scale: 1;
  -webkit-transition: all 1.5s;
  transition: all 1.5s;
}

.main:hover {
  -webkit-transform: rotateZ(240deg);
      -ms-transform: rotate(240deg);
          transform: rotateZ(240deg);
  scale: 2;
  /* filter: drop-shadow(10px,10px,10px,white); */
  -webkit-filter: drop-shadow(-1px -1px 5px #69e9d6);
          filter: drop-shadow(-1px -1px 5px #69e9d6);
}

.rings {
  position: absolute;
  width: 200px;
  height: 100px;
  /* background-color: #000000; */
  border-radius: 150px 150px 0 0;
  background: radial-gradient(circle at 50% 100%,transparent 30%, #69e9d6 40%,#404D44 50%,#44867c 60%,#404D44 70%,transparent);
}

#saturn {
  width: 70px;
  height: 70px;
  border-radius: 50%;
  background: linear-gradient(80deg,#69e9d6,#404D44,#000000);
}

#ring1 {
  -webkit-transform: rotateX(80deg);
          transform: rotateX(80deg);
  top: -20px;
  left: -65px;
}

#ring2 {
  -webkit-transform: rotateX(-100deg);
          transform: rotateX(-100deg);
  left: -65px;
  z-index: -1;
  top: -3px;
}

.asteriods-large {
  position: absolute;
  width: 8px;
  height: 10px;
  border-radius: 15px 8px;
  background: linear-gradient(220deg,#6f7776,#598ea3,#311515);
  -webkit-transform: rotateZ(0deg);
      -ms-transform: rotate(0deg);
          transform: rotateZ(0deg);
  -webkit-transition: all 3s;
  transition: all 3s;
}

#asteriod1 {
  top: 8px;
  height: 12px;
  width: 12px;
  border-radius: 50%;
}

#asteriod2 {
  top: 35px;
  height: 10px;
  left: -55px;
}

#asteriod3 {
  top: 35px;
  height: 8px;
  left: 85px;
}

#asteriod4 {
  top: 40px;
  height: 4px;
  width: 4px;
  left: -40px;
}

#asteriod5 {
  top: 35px;
  height: 4px;
  width: 4px;
  left: 82px;
}

.asteriods-small {
  position: absolute;
  width: 4px;
  height: 3px;
  border-radius: 15px 8px;
  background: linear-gradient(80deg,#6f7776,#598ea3,#311515);
  -webkit-transform-origin: 50px 50px;
      -ms-transform-origin: 50px 50px;
          transform-origin: 50px 50px;
  -webkit-transform: rotateZ(0deg);
      -ms-transform: rotate(0deg);
          transform: rotateZ(0deg);
  -webkit-transition: all 3s;
  transition: all 3s;
}

#asteriod6 {
  top: 6px;
  left: -5px;
  border-radius: 50%;
}

#asteriod7 {
  top: 15px;
  left: -35px;
}

#asteriod8 {
  top: 35px;
  left: 65px;
}

#asteriod9 {
  top: 60px;
  left: -10px;
}

#asteriod10 {
  top: 15px;
  left: 112px;
}

#explore {
  position: absolute;
  top: 32px;
  font-size: 15px;
  color: hsl(171, 59%, 74%);
  left: 10px;
  -webkit-transition: all 3s;
  transition: all 3s;
}

.main:hover > .asteriods-large,.main:hover > .asteriods-small {
  -webkit-transform: translateX(28px);
      -ms-transform: translateX(28px);
          transform: translateX(28px);
}

.main:hover > #explore {
  translate: -10px 20px;
  -webkit-transform: rotateZ(120deg);
      -ms-transform: rotate(120deg);
          transform: rotateZ(120deg);
}

.main:not(hover) > #explore {
  translate: 0px;
  -webkit-transform: rotateZ(0deg);
      -ms-transform: rotate(0deg);
          transform: rotateZ(0deg);
}

.main:not(hover) > .asteriods-large,.main:not(hover) > .asteriods-small {
  -webkit-transform: translateX(0px);
      -ms-transform: translateX(0px);
          transform: translateX(0px);
}

.main:is(:active) > #explore {
  translate: -100px 200px;
}

.main:is(:active) {
  translate: -200px;
}



/*searcher*/

#wifi-searcher {
  --background: #62abff;
  --front-color: #4f29f0;
  --back-color: #c3c8de;
  --text-color: #414856;
  width: 50px;
  height: 50px;
  border-radius: 40px;
  position: relative;
  display: -webkit-box;
  display: -ms-flexbox;
  display: flex;
  -webkit-box-pack: center;
      -ms-flex-pack: center;
          justify-content: center;
  -webkit-box-align: center;
      -ms-flex-align: center;
          align-items: center;
          left:10%;
          top:20%;
          position:absolute;
}

#wifi-searcher svg {
  position: absolute;
  display: -webkit-box;
  display: -ms-flexbox;
  display: flex;
  -webkit-box-pack: center;
      -ms-flex-pack: center;
          justify-content: center;
  -webkit-box-align: center;
      -ms-flex-align: center;
          align-items: center;
}

#wifi-searcher svg circle {
  position: absolute;
  fill: none;
  stroke-width: 6px;
  stroke-linecap: round;
  stroke-linejoin: round;
  -webkit-transform: rotate(-100deg);
      -ms-transform: rotate(-100deg);
          transform: rotate(-100deg);
  -webkit-transform-origin: center;
      -ms-transform-origin: center;
          transform-origin: center;
}

#wifi-searcher svg circle.back {
  stroke: var(--back-color);
}

#wifi-searcher svg circle.front {
  stroke: var(--front-color);
}

#wifi-searcher svg.circle-outer {
  height: 86px;
  width: 86px;
}

#wifi-searcher svg.circle-outer circle {
  stroke-dasharray: 62.75 188.25;
}

#wifi-searcher svg.circle-outer circle.back {
  -webkit-animation: circle-outer135 1.8s ease infinite 0.3s;
          animation: circle-outer135 1.8s ease infinite 0.3s;
}

#wifi-searcher svg.circle-outer circle.front {
  -webkit-animation: circle-outer135 1.8s ease infinite 0.15s;
          animation: circle-outer135 1.8s ease infinite 0.15s;
}

#wifi-searcher svg.circle-middle {
  height: 60px;
  width: 60px;
}

#wifi-searcher svg.circle-middle circle {
  stroke-dasharray: 42.5 127.5;
}

#wifi-searcher svg.circle-middle circle.back {
  -webkit-animation: circle-middle6123 1.8s ease infinite 0.25s;
          animation: circle-middle6123 1.8s ease infinite 0.25s;
}

#wifi-searcher svg.circle-middle circle.front {
  -webkit-animation: circle-middle6123 1.8s ease infinite 0.1s;
          animation: circle-middle6123 1.8s ease infinite 0.1s;
}

#wifi-searcher svg.circle-inner {
  height: 34px;
  width: 34px;
}

#wifi-searcher svg.circle-inner circle {
  stroke-dasharray: 22 66;
}

#wifi-searcher svg.circle-inner circle.back {
  -webkit-animation: circle-inner162 1.8s ease infinite 0.2s;
          animation: circle-inner162 1.8s ease infinite 0.2s;
}

#wifi-searcher svg.circle-inner circle.front {
  -webkit-animation: circle-inner162 1.8s ease infinite 0.05s;
          animation: circle-inner162 1.8s ease infinite 0.05s;
}

#wifi-searcher .text {
  position: absolute;
  bottom: -40px;
  display: -webkit-box;
  display: -ms-flexbox;
  display: flex;
  -webkit-box-pack: center;
      -ms-flex-pack: center;
          justify-content: center;
  -webkit-box-align: center;
      -ms-flex-align: center;
          align-items: center;
  text-transform: lowercase;
  font-weight: 500;
  font-size: 14px;
  letter-spacing: 0.2px;
}

#wifi-searcher .text::before, #wifi-loader .text::after {
  content: attr(data-text);
}

#wifi-searcher .text::before {
  color: var(--text-color);
}

#wifi-searcher .text::after {
  color: var(--front-color);
  -webkit-animation: text-animation76 3.6s ease infinite;
          animation: text-animation76 3.6s ease infinite;
  position: absolute;
  left: 0;
}

@-webkit-keyframes circle-outer135 {
  0% {
    stroke-dashoffset: 25;
  }

  25% {
    stroke-dashoffset: 0;
  }

  65% {
    stroke-dashoffset: 301;
  }

  80% {
    stroke-dashoffset: 276;
  }

  100% {
    stroke-dashoffset: 276;
  }
}

@keyframes circle-outer135 {
  0% {
    stroke-dashoffset: 25;
  }

  25% {
    stroke-dashoffset: 0;
  }

  65% {
    stroke-dashoffset: 301;
  }

  80% {
    stroke-dashoffset: 276;
  }

  100% {
    stroke-dashoffset: 276;
  }
}

@-webkit-keyframes circle-middle6123 {
  0% {
    stroke-dashoffset: 17;
  }

  25% {
    stroke-dashoffset: 0;
  }

  65% {
    stroke-dashoffset: 204;
  }

  80% {
    stroke-dashoffset: 187;
  }

  100% {
    stroke-dashoffset: 187;
  }
}

@keyframes circle-middle6123 {
  0% {
    stroke-dashoffset: 17;
  }

  25% {
    stroke-dashoffset: 0;
  }

  65% {
    stroke-dashoffset: 204;
  }

  80% {
    stroke-dashoffset: 187;
  }

  100% {
    stroke-dashoffset: 187;
  }
}

@-webkit-keyframes circle-inner162 {
  0% {
    stroke-dashoffset: 9;
  }

  25% {
    stroke-dashoffset: 0;
  }

  65% {
    stroke-dashoffset: 106;
  }

  80% {
    stroke-dashoffset: 97;
  }

  100% {
    stroke-dashoffset: 97;
  }
}

@keyframes circle-inner162 {
  0% {
    stroke-dashoffset: 9;
  }

  25% {
    stroke-dashoffset: 0;
  }

  65% {
    stroke-dashoffset: 106;
  }

  80% {
    stroke-dashoffset: 97;
  }

  100% {
    stroke-dashoffset: 97;
  }
}

@-webkit-keyframes text-animation76 {
  0% {
    -webkit-clip-path: inset(0 100% 0 0);
            clip-path: inset(0 100% 0 0);
  }

 }
/*solaruni*/

 .uni {
    font-size: 10px;
    width: 40em;
    height: 40em;
    position: absolute;
    bottom:-50%;
   left:1%;

}
.sunny {
    position: absolute;
    top: 15em;
    left: 15em;
    width: 10em;
    height: 10em;
    background-color: yellow;
    border-radius: 50%;
    box-shadow: 0 0 3em white;
}
.earthy,.moony {
    position: absolute;
    border-style: solid;
    border-color: white transparent transparent transparent;
    border-width: 0.1em 0.1em 0 0;
    border-radius: 50%;
}
.earthy {
    top: 5em;
    left: 5em;
    width: 30em;
    height: 30em; 
    animation: orbit 36.5s linear infinite;   
}
.moony {
    top: 0;
    right: 0;
    width: 8em;
    height: 8em; 
    animation: orbit 2.7s linear infinite;
}
.earthy::before,
.moony::before {
    content: '';
    position: absolute;
    border-radius: 50%;
}
.earthy::before {
    top: 2.8em;
    right: 2.8em;
    width: 3em;
    height: 3em;
    background-color: aqua;    
}
.moony::before {
    top: 0.8em;
    right: 0.2em;
    width: 1.2em;
    height: 1.2em;
    background-color: silver;
}
@keyframes orbit {
    to {
        transform: rotate(360deg);
    }
}

/*solarpanel*/

.solarpanel {
  display: -webkit-box;
  display: -ms-flexbox;
  display: flex;
  -ms-flex-wrap: wrap;
      flex-wrap: wrap;
  width: 15em;
  -webkit-box-align: center;
      -ms-flex-align: center;
          align-items: center;
  -webkit-box-pack: center;
      -ms-flex-pack: center;
          justify-content: center;
          position:absolute;
          left:25%;
          bottom:30%;
}

.card {
  width: 40px;
  height: 40px;
  border-top-left-radius: 10px;
  background: lightgrey;
  -webkit-transition: .4s ease-in-out, .2s background-color;
  transition: .4s ease-in-out, .2s background-color;
  background: rgba(255, 255, 255, 0.2);
  -webkit-backdrop-filter: blur(5px);
          backdrop-filter: blur(5px);
  margin: .2em;
  border-radius: 5px;
  -webkit-box-shadow: 0 4px 30px rgba(0, 0, 0, 0.1);
          box-shadow: 0 4px 30px rgba(0, 0, 0, 0.1);
  border: 1px solid rgba(255, 255, 255, 0.3);
  -webkit-animation: 2s loading90 infinite;
          animation: 2s loading90 infinite;
}

.card:nth-child(2) {
  -webkit-animation-delay: 1s;
          animation-delay: 1s;
}

.card:nth-child(4) {
  -webkit-animation-delay: 1s;
          animation-delay: 1s;
}

.card:nth-child(6) {
  -webkit-animation-delay: 1s;
          animation-delay: 1s;
}

.card:nth-child(8) {
  -webkit-animation-delay: 1s;
          animation-delay: 1s;
}

.card:nth-child(10) {
  -webkit-animation-delay: 1s;
          animation-delay: 1s;
}

.card:nth-child(12) {
  -webkit-animation-delay: 1s;
          animation-delay: 1s;
}

.card:nth-child(14) {
  -webkit-animation-delay: 1s;
          animation-delay: 1s;
}

@-webkit-keyframes loading90 {
  0% {
    background: rgba(255, 255, 255, 0.2);
  }

  50% {
    background: limegreen;
  }

  100% {
    background: rgba(255, 255, 255, 0.2);
  }
}

@keyframes loading90 {
  0% {
    background: rgba(255, 255, 255, 0.2);
  }

  50% {
    background: limegreen;
  }

  100% {
    background: rgba(255, 255, 255, 0.2);
  }
}


/*astronaut
@-webkit-keyframes snow {
0% {
    opacity: 0;
    -webkit-transform: translateY(0px);
            transform: translateY(0px);
  }

  20% {
    opacity: 1;
  }

  100% {
    opacity: 1;
    -webkit-transform: translateY(650px);
            transform: translateY(650px);
  }
}

@keyframes snow {
  0% {
    opacity: 0;
    -webkit-transform: translateY(0px);
            transform: translateY(0px);
  }

  20% {
    opacity: 1;
  }

  100% {
    opacity: 1;
    -webkit-transform: translateY(650px);
            transform: translateY(650px);
  }
}

@-webkit-keyframes astronaut {
  0% {
    -webkit-transform: rotate(0deg);
            transform: rotate(0deg);
  }

  100% {
    -webkit-transform: rotate(360deg);
            transform: rotate(360deg);
  }
}

@keyframes astronaut {
  0% {
    -webkit-transform: rotate(0deg);
            transform: rotate(0deg);
  }

  100% {
    -webkit-transform: rotate(360deg);
            transform: rotate(360deg);
  }
}

.box-of-star1,
.box-of-star2,
.box-of-star3,
.box-of-star4 {
  width: 100%;
  position: absolute;
  z-index: 10;
  left: 0;
  top: 0;
  -webkit-transform: translateY(0px);
      -ms-transform: translateY(0px);
          transform: translateY(0px);
  height: 700px;
  position:absolute;
}

.box-of-star1 {
  -webkit-animation: snow 5s linear infinite;
          animation: snow 5s linear infinite;
}

.box-of-star2 {
  -webkit-animation: snow 5s -1.64s linear infinite;
          animation: snow 5s -1.64s linear infinite;
}

.box-of-star3 {
  -webkit-animation: snow 5s -2.30s linear infinite;
          animation: snow 5s -2.30s linear infinite;
}

.box-of-star4 {
  -webkit-animation: snow 5s -3.30s linear infinite;
          animation: snow 5s -3.30s linear infinite;
}

.star {
  width: 3px;
  height: 3px;
  border-radius: 50%;
  background-color: #FFF;
  position: absolute;
  z-index: 10;
  opacity: 0.7;
}

.star:before {
  content: "";
  width: 6px;
  height: 6px;
  border-radius: 50%;
  background-color: #FFF;
  position: absolute;
  z-index: 10;
  top: 80px;
  left: 70px;
  opacity: .7;
}

.star:after {
  content: "";
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background-color: #FFF;
  position: absolute;
  z-index: 10;
  top: 8px;
  left: 170px;
  opacity: .9;
}

.star-position1 {
  top: 30px;
  left: 20px;
}

.star-position2 {
  top: 110px;
  left: 250px;
}

.star-position3 {
  top: 60px;
  left: 570px;
}

.star-position4 {
  top: 120px;
  left: 900px;
}

.star-position5 {
  top: 20px;
  left: 1120px;
}

.star-position6 {
  top: 90px;
  left: 1280px;
}

.star-position7 {
  top: 30px;
  left: 1480px;
}

.astronaut {
  width: 250px;
  height: 300px;
  position: absolute;
  z-index: 11;
  top: calc(50% - 150px);
  left: calc(50% - 125px);
  -webkit-animation: astronaut 5s linear infinite;
          animation: astronaut 5s linear infinite;
}

.schoolbag {
  width: 100px;
  height: 150px;
  position: absolute;
  z-index: 1;
  top: calc(50% - 75px);
  left: calc(50% - 50px);
  background-color: #94b7ca;
  border-radius: 50px 50px 0 0 / 30px 30px 0 0;
}

.head {
  width: 97px;
  height: 80px;
  position: absolute;
  z-index: 3;
  background: -webkit-linear-gradient(left, #e3e8eb 0%, #e3e8eb 50%, #fbfdfa 50%, #fbfdfa 100%);
  border-radius: 50%;
  top: 34px;
  left: calc(50% - 47.5px);
}

.head:after {
  content: "";
  width: 60px;
  height: 50px;
  position: absolute;
  top: calc(50% - 25px);
  left: calc(50% - 30px);
  background: -webkit-linear-gradient(top, #15aece 0%, #15aece 50%, #0391bf 50%, #0391bf 100%);
  border-radius: 15px;
}

.head:before {
  content: "";
  width: 12px;
  height: 25px;
  position: absolute;
  top: calc(50% - 12.5px);
  left: -4px;
  background-color: #618095;
  border-radius: 5px;
  -webkit-box-shadow: 92px 0px 0px #618095;
          box-shadow: 92px 0px 0px #618095;
}

.body {
  width: 85px;
  height: 100px;
  position: absolute;
  z-index: 2;
  background-color: #fffbff;
  border-radius: 40px / 20px;
  top: 105px;
  left: calc(50% - 41px);
  background: -webkit-linear-gradient(left, #e3e8eb 0%, #e3e8eb 50%, #fbfdfa 50%, #fbfdfa 100%);
}

.panel {
  width: 60px;
  height: 40px;
  position: absolute;
  top: 20px;
  left: calc(50% - 30px);
  background-color: #b7cceb;
}

.panel:before {
  content: "";
  width: 30px;
  height: 5px;
  position: absolute;
  top: 9px;
  left: 7px;
  background-color: #fbfdfa;
  -webkit-box-shadow: 0px 9px 0px #fbfdfa, 0px 18px 0px #fbfdfa;
          box-shadow: 0px 9px 0px #fbfdfa, 0px 18px 0px #fbfdfa;
}

.panel:after {
  content: "";
  width: 8px;
  height: 8px;
  position: absolute;
  top: 9px;
  right: 7px;
  background-color: #fbfdfa;
  border-radius: 50%;
  -webkit-box-shadow: 0px 14px 0px 2px #fbfdfa;
          box-shadow: 0px 14px 0px 2px #fbfdfa;
}

.arm {
  width: 80px;
  height: 30px;
  position: absolute;
  top: 121px;
  z-index: 2;
}

.arm-left {
  left: 30px;
  background-color: #e3e8eb;
  border-radius: 0 0 0 39px;
}

.arm-right {
  right: 30px;
  background-color: #fbfdfa;
  border-radius: 0 0 39px 0;
}

.arm-left:before,
.arm-right:before {
  content: "";
  width: 30px;
  height: 70px;
  position: absolute;
  top: -40px;
}

.arm-left:before {
  border-radius: 50px 50px 0px 120px / 50px 50px 0 110px;
  left: 0;
  background-color: #e3e8eb;
}

.arm-right:before {
  border-radius: 50px 50px 120px 0 / 50px 50px 110px 0;
  right: 0;
  background-color: #fbfdfa;
}

.arm-left:after,
.arm-right:after {
  content: "";
  width: 30px;
  height: 10px;
  position: absolute;
  top: -24px;
}

.arm-left:after {
  background-color: #6e91a4;
  left: 0;
}

.arm-right:after {
  right: 0;
  background-color: #b6d2e0;
}

.leg {
  width: 30px;
  height: 40px;
  position: absolute;
  z-index: 2;
  bottom: 70px;
}

.leg-left {
  left: 76px;
  background-color: #e3e8eb;
  -webkit-transform: rotate(20deg);
      -ms-transform: rotate(20deg);
          transform: rotate(20deg);
}

.leg-right {
  right: 73px;
  background-color: #fbfdfa;
  -webkit-transform: rotate(-20deg);
      -ms-transform: rotate(-20deg);
          transform: rotate(-20deg);
}

.leg-left:before,
.leg-right:before {
  content: "";
  width: 50px;
  height: 25px;
  position: absolute;
  bottom: -26px;
}

.leg-left:before {
  left: -20px;
  background-color: #e3e8eb;
  border-radius: 30px 0 0 0;
  border-bottom: 10px solid #6d96ac;
}

.leg-right:before {
  right: -20px;
  background-color: #fbfdfa;
  border-radius: 0 30px 0 0;
  border-bottom: 10px solid #b0cfe4;
}

*/
/*special*

.gegga {
  
}

.snurra {
  -webkit-filter: url(#gegga);
          filter: url(#gegga);
}

.stopp1 {
  stop-color: #f700a8;
}

.stopp2 {
  stop-color: #ff8000;
}

.halvan {
  -webkit-animation: Snurra1 10s infinite linear;
          animation: Snurra1 10s infinite linear;
  stroke-dasharray: 180 800;
  fill: none;
  stroke: url(#gradient);
  stroke-width: 23;
  stroke-linecap: round;

  right:10%;
  bottom:20%;
}

.strecken {
  -webkit-animation: Snurra1 3s infinite linear;
          animation: Snurra1 3s infinite linear;
  stroke-dasharray: 26 54;
  fill: none;
  stroke: url(#gradient);
  stroke-width: 23;
  stroke-linecap: round;
}

.skugga {
  -webkit-filter: blur(5px);
          filter: blur(5px);
  opacity: 0.3;
  position: absolute;
  -webkit-transform: translate(3px, 3px);
      -ms-transform: translate(3px, 3px);
          transform: translate(3px, 3px);
}

@-webkit-keyframes Snurra1 {
  0% {
    stroke-dashoffset: 0;
  }

  100% {
    stroke-dashoffset: -403px;
  }
}

@keyframes Snurra1 {
  0% {
    stroke-dashoffset: 0;
  }

  100% {
    stroke-dashoffset: -403px;
  }
}
*/

/*colorful ring*/

.special1-1 {
  width: 100px;
  height: 100px;
  border-radius: 50%;
  border: 5px solid rgb(218, 203, 4);
  border-left-color: transparent;
  -webkit-animation: animate_681 3s linear infinite;
          animation: animate_681 3s linear infinite;
  position: absolute;
  top:50%;
         
            display: flex;
            align-items: center;
            justify-content: center;
            right:10%;
}

.special1-2 {
  width: 80px;
  height: 80px;
  border-radius: 50%;
  border: 5px solid rgb(0, 119, 255);
  border-top-color: transparent;
  -webkit-animation: animate_6810 .9s linear infinite;
          animation: animate_6810 .9s linear infinite;
  position: absolute;
  margin: 5px;
}

.special1-3 {
  width: 60px;
  height: 60px;
  border-radius: 50%;
  border: 5px solid rgb(30, 255, 0);
  border-right-color: transparent;
  -webkit-animation: animate_681 2s linear  infinite;
          animation: animate_681 2s linear  infinite;
  position: absolute;
  margin: 15px;
}

.special1-4 {
  width: 40px;
  height: 40px;
  border-radius: 50%;
  border: 5px solid rgb(194, 3, 92);
  border-bottom-color: transparent;
  -webkit-animation: animate_6810 .7s linear  infinite;
          animation: animate_6810 .7s linear  infinite;
  position: absolute;
  margin: 25px;
}

@-webkit-keyframes animate_6810 {
  0% {
    -webkit-transform: rotate(360deg);
            transform: rotate(360deg);
  }
}

@keyframes animate_6810 {
  0% {
    -webkit-transform: rotate(360deg);
            transform: rotate(360deg);
  }
}

@-webkit-keyframes animate_681 {
  0% {
    -webkit-transform: rotate(-360deg);
            transform: rotate(-360deg);
  }
}

@keyframes animate_681 {
  0% {
    -webkit-transform: rotate(-360deg);
            transform: rotate(-360deg);
  }
}

/*sphere*/

.sphere {
  width: 200px;
  height: 200px;
  -webkit-perspective: 200px;
          perspective: 200px;
          right:25%;
          top:30%;
          display: flex;
            align-items: center;
            justify-content: center;
            position: absolute;

}


.dott {
  position: absolute;
  top: 50%;
  left: 50%;
  width: 120px;
  height: 120px;
  margin-top: -60px;
  margin-left: -60px;
  border-radius: 100px;
  border: 40px outset #1e3f57;
  -webkit-transform-origin: 50% 50%;
      -ms-transform-origin: 50% 50%;
          transform-origin: 50% 50%;
  -webkit-transform: rotateX(24deg) rotateY(20deg) rotateZ(0deg) translateZ(-25px);
          transform: rotateX(24deg) rotateY(20deg) rotateZ(0deg) translateZ(-25px);
  background-color: transparent;
  -webkit-animation: dot1 1000ms cubic-bezier(.49,.06,.43,.85) infinite;
          animation: dot1 1000ms cubic-bezier(.49,.06,.43,.85) infinite;
}

.dott:nth-child(2) {
  width: 140px;
  height: 140px;
  margin-top: -70px;
  margin-left: -70px;
  border-width: 30px;
  border-color: #447891;
  -webkit-animation-name: dot2;
          animation-name: dot2;
  -webkit-animation-delay: 75ms;
          animation-delay: 75ms;
  -webkit-box-shadow: inset 0 0 15px 0 rgba(0, 0, 0, 0.1);
          box-shadow: inset 0 0 15px 0 rgba(0, 0, 0, 0.1);
  -webkit-transform: rotateX(24deg) rotateY(20deg) rotateZ(0deg) translateZ(-25px);
          transform: rotateX(24deg) rotateY(20deg) rotateZ(0deg) translateZ(-25px);
}

.dott:nth-child(3) {
  width: 160px;
  height: 160px;
  margin-top: -80px;
  margin-left: -80px;
  border-width: 20px;
  border-color: #6bb2cd;
  -webkit-animation-name: dot3;
          animation-name: dot3;
  -webkit-animation-delay: 150ms;
          animation-delay: 150ms;
  -webkit-box-shadow: inset 0 0 15px 0 rgba(0, 0, 0, 0.1);
          box-shadow: inset 0 0 15px 0 rgba(0, 0, 0, 0.1);
  -webkit-transform: rotateX(24deg) rotateY(20deg) rotateZ(0deg) translateZ(-25px);
          transform: rotateX(24deg) rotateY(20deg) rotateZ(0deg) translateZ(-25px);
}

@-webkit-keyframes dot1 {
  0% {
    border-color: #1e3f57;
    -webkit-transform: rotateX(24deg) rotateY(20deg) rotateZ(0deg) translateZ(-25px);
            transform: rotateX(24deg) rotateY(20deg) rotateZ(0deg) translateZ(-25px);
  }

  50% {
    border-color: #1e574f;
    -webkit-transform: rotateX(20deg) rotateY(20deg) rotateZ(50deg) translateZ(0px);
            transform: rotateX(20deg) rotateY(20deg) rotateZ(50deg) translateZ(0px);
  }

  100% {
    border-color: #1e3f57;
    -webkit-transform: rotateX(24deg) rotateY(20deg) rotateZ(0deg) translateZ(-25px);
            transform: rotateX(24deg) rotateY(20deg) rotateZ(0deg) translateZ(-25px);
  }
}

@keyframes dot1 {
  0% {
    border-color: #1e3f57;
    -webkit-transform: rotateX(24deg) rotateY(20deg) rotateZ(0deg) translateZ(-25px);
            transform: rotateX(24deg) rotateY(20deg) rotateZ(0deg) translateZ(-25px);
  }

  50% {
    border-color: #1e574f;
    -webkit-transform: rotateX(20deg) rotateY(20deg) rotateZ(50deg) translateZ(0px);
            transform: rotateX(20deg) rotateY(20deg) rotateZ(50deg) translateZ(0px);
  }

  100% {
    border-color: #1e3f57;
    -webkit-transform: rotateX(24deg) rotateY(20deg) rotateZ(0deg) translateZ(-25px);
            transform: rotateX(24deg) rotateY(20deg) rotateZ(0deg) translateZ(-25px);
  }
}

@-webkit-keyframes dot2 {
  0% {
    border-color: #447891;
    -webkit-box-shadow: inset 0 0 15px 0 rgba(255, 255, 255, 0.2);
            box-shadow: inset 0 0 15px 0 rgba(255, 255, 255, 0.2);
    -webkit-transform: rotateX(24deg) rotateY(20deg) rotateZ(0deg) translateZ(-25px);
            transform: rotateX(24deg) rotateY(20deg) rotateZ(0deg) translateZ(-25px);
  }

  50% {
    border-color: #449180;
    -webkit-box-shadow: inset 0 0 15px 0 rgba(0, 0, 0, 0.8);
            box-shadow: inset 0 0 15px 0 rgba(0, 0, 0, 0.8);
    -webkit-transform: rotateX(20deg) rotateY(20deg) rotateZ(50deg) translateZ(0px);
            transform: rotateX(20deg) rotateY(20deg) rotateZ(50deg) translateZ(0px);
  }

  100% {
    border-color: #447891;
    -webkit-box-shadow: inset 0 0 15px 0 rgba(255, 255, 255, 0.2);
            box-shadow: inset 0 0 15px 0 rgba(255, 255, 255, 0.2);
    -webkit-transform: rotateX(24deg) rotateY(20deg) rotateZ(0deg) translateZ(-25px);
            transform: rotateX(24deg) rotateY(20deg) rotateZ(0deg) translateZ(-25px);
  }
}

@keyframes dot2 {
  0% {
    border-color: #447891;
    -webkit-box-shadow: inset 0 0 15px 0 rgba(255, 255, 255, 0.2);
            box-shadow: inset 0 0 15px 0 rgba(255, 255, 255, 0.2);
    -webkit-transform: rotateX(24deg) rotateY(20deg) rotateZ(0deg) translateZ(-25px);
            transform: rotateX(24deg) rotateY(20deg) rotateZ(0deg) translateZ(-25px);
  }

  50% {
    border-color: #449180;
    -webkit-box-shadow: inset 0 0 15px 0 rgba(0, 0, 0, 0.8);
            box-shadow: inset 0 0 15px 0 rgba(0, 0, 0, 0.8);
    -webkit-transform: rotateX(20deg) rotateY(20deg) rotateZ(50deg) translateZ(0px);
            transform: rotateX(20deg) rotateY(20deg) rotateZ(50deg) translateZ(0px);
  }

  100% {
    border-color: #447891;
    -webkit-box-shadow: inset 0 0 15px 0 rgba(255, 255, 255, 0.2);
            box-shadow: inset 0 0 15px 0 rgba(255, 255, 255, 0.2);
    -webkit-transform: rotateX(24deg) rotateY(20deg) rotateZ(0deg) translateZ(-25px);
            transform: rotateX(24deg) rotateY(20deg) rotateZ(0deg) translateZ(-25px);
  }
}

@-webkit-keyframes dot3 {
  0% {
    border-color: #6bb2cd;
    -webkit-box-shadow: inset 0 0 15px 0 rgba(0, 0, 0, 0.1);
            box-shadow: inset 0 0 15px 0 rgba(0, 0, 0, 0.1);
    -webkit-transform: rotateX(24deg) rotateY(20deg) rotateZ(0deg) translateZ(-25px);
            transform: rotateX(24deg) rotateY(20deg) rotateZ(0deg) translateZ(-25px);
  }

  50% {
    border-color: #6bcdb2;
    -webkit-box-shadow: inset 0 0 15px 0 rgba(0, 0, 0, 0.8);
            box-shadow: inset 0 0 15px 0 rgba(0, 0, 0, 0.8);
    -webkit-transform: rotateX(20deg) rotateY(20deg) rotateZ(50deg) translateZ(0px);
            transform: rotateX(20deg) rotateY(20deg) rotateZ(50deg) translateZ(0px);
  }

  100% {
    border-color: #6bb2cd;
    -webkit-box-shadow: inset 0 0 15px 0 rgba(0, 0, 0, 0.1);
            box-shadow: inset 0 0 15px 0 rgba(0, 0, 0, 0.1);
    -webkit-transform: rotateX(24deg) rotateY(20deg) rotateZ(0deg) translateZ(-25px);
            transform: rotateX(24deg) rotateY(20deg) rotateZ(0deg) translateZ(-25px);
  }
}

@keyframes dot3 {
  0% {
    border-color: #6bb2cd;
    -webkit-box-shadow: inset 0 0 15px 0 rgba(0, 0, 0, 0.1);
            box-shadow: inset 0 0 15px 0 rgba(0, 0, 0, 0.1);
    -webkit-transform: rotateX(24deg) rotateY(20deg) rotateZ(0deg) translateZ(-25px);
            transform: rotateX(24deg) rotateY(20deg) rotateZ(0deg) translateZ(-25px);
  }

  50% {
    border-color: #6bcdb2;
    -webkit-box-shadow: inset 0 0 15px 0 rgba(0, 0, 0, 0.8);
            box-shadow: inset 0 0 15px 0 rgba(0, 0, 0, 0.8);
    -webkit-transform: rotateX(20deg) rotateY(20deg) rotateZ(50deg) translateZ(0px);
            transform: rotateX(20deg) rotateY(20deg) rotateZ(50deg) translateZ(0px);
  }

  100% {
    border-color: #6bb2cd;
    -webkit-box-shadow: inset 0 0 15px 0 rgba(0, 0, 0, 0.1);
            box-shadow: inset 0 0 15px 0 rgba(0, 0, 0, 0.1);
    -webkit-transform: rotateX(24deg) rotateY(20deg) rotateZ(0deg) translateZ(-25px);
            transform: rotateX(24deg) rotateY(20deg) rotateZ(0deg) translateZ(-25px);
  }
}

/*spinnerbaeyblade*/

.spinners {
  width: 3em;
  height: 3em;
  cursor: not-allowed;
  border-radius: 50%;
  border: 3px solid seagreen;
  -webkit-box-shadow: -10px -10px 10px #6359f8, 0px -10px 10px 0px #9c32e2, 10px -10px 10px #f36896, 10px 0 10px #ff0b0b, 10px 10px 10px 0px#ff5500, 0 10px 10px 0px #ff9500, -10px 10px 10px 0px #ffb700;
          box-shadow: -10px -10px 10px #6359f8, 0px -10px 10px 0px #9c32e2, 10px -10px 10px #f36896, 10px 0 10px #ff0b0b, 10px 10px 10px 0px#ff5500, 0 10px 10px 0px #ff9500, -10px 10px 10px 0px #ffb700;
  -webkit-animation: rot55 0.7s linear infinite;
          animation: rot55 0.7s linear infinite;
          position:absolute;
          left:35%;
          top:90%;

}

.spinnersin {
  border: 3px solid seagreen;
  width: 1.5em;
  height: 1.5em;
  border-radius: 50%;
  position: absolute;
  top: 50%;
  left: 50%;
  -webkit-transform: translate(-50%, -50%);
      -ms-transform: translate(-50%, -50%);
          transform: translate(-50%, -50%);
}

@-webkit-keyframes rot55 {
  to {
    -webkit-transform: rotate(360deg);
            transform: rotate(360deg);
  }
}

@keyframes rot55 {
  to {
    -webkit-transform: rotate(360deg);
            transform: rotate(360deg);
  }
}


/*spinners1*/

.spinners1:before {
  -webkit-transform: rotateX(60deg) rotateY(45deg) rotateZ(45deg);
          transform: rotateX(60deg) rotateY(45deg) rotateZ(45deg);
  animation: 750ms rotateBefore infinite linear reverse;
}

.spinners1:after {
  -webkit-transform: rotateX(240deg) rotateY(45deg) rotateZ(45deg);
          transform: rotateX(240deg) rotateY(45deg) rotateZ(45deg);
  -webkit-animation: 750ms rotateAfter infinite linear;
          animation: 750ms rotateAfter infinite linear;
}

.spinners1:before,
.spinners1:after {
  -webkit-box-sizing: border-box;
          box-sizing: border-box;
  content: '';
  display: block;
  position: absolute;
  margin-top: -5em;
  margin-left: -5em;
  width: 10em;
  height: 10em;
  top:20%;
  right:20%;
  -webkit-transform-style: preserve-3d;
          transform-style: preserve-3d;
  -webkit-transform-origin: 50%;
      -ms-transform-origin: 50%;
          transform-origin: 50%;
  -webkit-transform: rotateY(50%);
          transform: rotateY(50%);
  -webkit-perspective-origin: 50% 50%;
          perspective-origin: 50% 50%;
  -webkit-perspective: 340px;
          perspective: 340px;
  background-size: 10em 10em;
  background-image: url(data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiIHN0YW5kYWxvbmU9Im5vIj8+Cjxzdmcgd2lkdGg9IjI2NnB4IiBoZWlnaHQ9IjI5N3B4IiB2aWV3Qm94PSIwIDAgMjY2IDI5NyIgdmVyc2lvbj0iMS4xIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB4bWxuczpza2V0Y2g9Imh0dHA6Ly93d3cuYm9oZW1pYW5jb2RpbmcuY29tL3NrZXRjaC9ucyI+CiAgICA8dGl0bGU+c3Bpbm5lcjwvdGl0bGU+CiAgICA8ZGVzY3JpcHRpb24+Q3JlYXRlZCB3aXRoIFNrZXRjaCAoaHR0cDovL3d3dy5ib2hlbWlhbmNvZGluZy5jb20vc2tldGNoKTwvZGVzY3JpcHRpb24+CiAgICA8ZGVmcz48L2RlZnM+CiAgICA8ZyBpZD0iUGFnZS0xIiBzdHJva2U9Im5vbmUiIHN0cm9rZS13aWR0aD0iMSIgZmlsbD0ibm9uZSIgZmlsbC1ydWxlPSJldmVub2RkIiBza2V0Y2g6dHlwZT0iTVNQYWdlIj4KICAgICAgICA8cGF0aCBkPSJNMTcxLjUwNzgxMywzLjI1MDAwMDM4IEMyMjYuMjA4MTgzLDEyLjg1NzcxMTEgMjk3LjExMjcyMiw3MS40OTEyODIzIDI1MC44OTU1OTksMTA4LjQxMDE1NSBDMjE2LjU4MjAyNCwxMzUuODIwMzEgMTg2LjUyODQwNSw5Ny4wNjI0OTY0IDE1Ni44MDA3NzQsODUuNzczNDM0NiBDMTI3LjA3MzE0Myw3NC40ODQzNzIxIDc2Ljg4ODQ2MzIsODQuMjE2MTQ2MiA2MC4xMjg5MDY1LDEwOC40MTAxNTMgQy0xNS45ODA0Njg1LDIxOC4yODEyNDcgMTQ1LjI3NzM0NCwyOTYuNjY3OTY4IDE0NS4yNzczNDQsMjk2LjY2Nzk2OCBDMTQ1LjI3NzM0NCwyOTYuNjY3OTY4IC0yNS40NDkyMTg3LDI1Ny4yNDIxOTggMy4zOTg0Mzc1LDEwOC40MTAxNTUgQzE2LjMwNzA2NjEsNDEuODExNDE3NCA4NC43Mjc1ODI5LC0xMS45OTIyOTg1IDE3MS41MDc4MTMsMy4yNTAwMDAzOCBaIiBpZD0iUGF0aC0xIiBmaWxsPSIjMDAwMDAwIiBza2V0Y2g6dHlwZT0iTVNTaGFwZUdyb3VwIj48L3BhdGg+CiAgICA8L2c+Cjwvc3ZnPg==);
}

@-webkit-keyframes rotateBefore {
  from {
    -webkit-transform: rotateX(60deg) rotateY(45deg) rotateZ(0deg);
            transform: rotateX(60deg) rotateY(45deg) rotateZ(0deg);
  }

  to {
    -webkit-transform: rotateX(60deg) rotateY(45deg) rotateZ(-360deg);
            transform: rotateX(60deg) rotateY(45deg) rotateZ(-360deg);
  }
}
@keyframes rotateBefore {
  from {
    -webkit-transform: rotateX(60deg) rotateY(45deg) rotateZ(0deg);
            transform: rotateX(60deg) rotateY(45deg) rotateZ(0deg);
  }

  to {
    -webkit-transform: rotateX(60deg) rotateY(45deg) rotateZ(-360deg);
            transform: rotateX(60deg) rotateY(45deg) rotateZ(-360deg);
  }
}

@-webkit-keyframes rotateAfter {
  from {
    -webkit-transform: rotateX(240deg) rotateY(45deg) rotateZ(0deg);
            transform: rotateX(240deg) rotateY(45deg) rotateZ(0deg);
  }

  to {
    -webkit-transform: rotateX(240deg) rotateY(45deg) rotateZ(360deg);
            transform: rotateX(240deg) rotateY(45deg) rotateZ(360deg);
  }
}

@keyframes rotateAfter {
  from {
    -webkit-transform: rotateX(240deg) rotateY(45deg) rotateZ(0deg);
            transform: rotateX(240deg) rotateY(45deg) rotateZ(0deg);
  }

  to {
    -webkit-transform: rotateX(240deg) rotateY(45deg) rotateZ(360deg);
            transform: rotateX(240deg) rotateY(45deg) rotateZ(360deg);
  }
}


/*square*/
.squarer {
  --cell-size: 30px;
  --cell-spacing: 1px;
  --cells: 3;
  --total-size: calc(var(--cells) * (var(--cell-size) + 2 * var(--cell-spacing)));
  display: -webkit-box;
  display: -ms-flexbox;
  display: flex;
  -ms-flex-wrap: wrap;
      flex-wrap: wrap;
  width: var(--total-size);
  height: var(--total-size);
  left:45%;
top:40%;
  position:absolute;

}

.cell {
  -webkit-box-flex: 0;
      -ms-flex: 0 0 var(--cell-size);
          flex: 0 0 var(--cell-size);
  margin: var(--cell-spacing);
  background-color: transparent;
  -webkit-box-sizing: border-box;
          box-sizing: border-box;
  border-radius: 4px;
  -webkit-animation: 1.5s ripple ease infinite;
          animation: 1.5s ripple ease infinite;
}

.cell.d-1 {
  -webkit-animation-delay: 100ms;
          animation-delay: 100ms;
}

.cell.d-2 {
  -webkit-animation-delay: 200ms;
          animation-delay: 200ms;
}

.cell.d-3 {
  -webkit-animation-delay: 300ms;
          animation-delay: 300ms;
}

.cell.d-4 {
  -webkit-animation-delay: 400ms;
          animation-delay: 400ms;
}

.cell:nth-child(1) {
  --cell-color: #00FF87;
}

.cell:nth-child(2) {
  --cell-color: #0CFD95;
}

.cell:nth-child(3) {
  --cell-color: #17FBA2;
}

.cell:nth-child(4) {
  --cell-color: #23F9B2;
}

.cell:nth-child(5) {
  --cell-color: #30F7C3;
}

.cell:nth-child(6) {
  --cell-color: #3DF5D4;
}

.cell:nth-child(7) {
  --cell-color: #45F4DE;
}

.cell:nth-child(8) {
  --cell-color: #53F1F0;
}

.cell:nth-child(9) {
  --cell-color: #60EFFF;
}


@-webkit-keyframes ripple {
  0% {
    background-color: transparent;
  }

  30% {
    background-color: var(--cell-color);
  }

  60% {
    background-color: transparent;
  }

  100% {
    background-color: transparent;
  }
}
@keyframes ripple {
  0% {
    background-color: transparent;
  }

  30% {
    background-color: var(--cell-color);
  }

  60% {
    background-color: transparent;
  }

  100% {
    background-color: transparent;
  }
}


/*squarercube1*/
.squarer1 {
  display: -webkit-box;
  display: -ms-flexbox;
  display: flex;
  -webkit-box-pack: center;
      -ms-flex-pack: center;
          justify-content: center;
  -webkit-box-align: center;
      -ms-flex-align: center;
          align-items: center;
  height: 100%;
  position:absolute;
right:10%;
  top:35%;


}

.cubess {
  position: relative;
  width: 50px;
  height: 50px;
  -webkit-transform-style: preserve-3d;
          transform-style: preserve-3d;
  -webkit-animation: rotate-cube 2s infinite;
          animation: rotate-cube 2s infinite;
}

.face1,
.face2,
.face3,
.face4,
.face5,
.face6 {
  position: absolute;
  width: 50px;
  height: 50px;
  background-color: transparent;
  border: 2px solid #00BFFF;
  -webkit-box-sizing: border-box;
          box-sizing: border-box;
}

.face1 {
  -webkit-transform: rotateY(0deg) translateZ(25px);
          transform: rotateY(0deg) translateZ(25px);
  -webkit-animation: change-color 2s infinite;
          animation: change-color 2s infinite;
}

.face2 {
  -webkit-transform: rotateX(90deg) translateZ(25px);
          transform: rotateX(90deg) translateZ(25px);
}

.face3 {
  -webkit-transform: rotateY(90deg) translateZ(25px);
          transform: rotateY(90deg) translateZ(25px);
  -webkit-animation: change-color 2s infinite;
          animation: change-color 2s infinite;
}

.face4 {
  -webkit-transform: rotateY(180deg) translateZ(25px);
          transform: rotateY(180deg) translateZ(25px);
  -webkit-animation: change-color 2s infinite;
          animation: change-color 2s infinite;
}

.face5 {
  -webkit-transform: rotateX(-90deg) translateZ(25px);
          transform: rotateX(-90deg) translateZ(25px);
}

.face6 {
  -webkit-transform: rotateY(-90deg) translateZ(25px);
          transform: rotateY(-90deg) translateZ(25px);
  -webkit-animation: change-color 2s infinite;
          animation: change-color 2s infinite;
}

@-webkit-keyframes rotate-cube {
  from {
    -webkit-transform: rotateX(0deg) rotateY(0deg);
            transform: rotateX(0deg) rotateY(0deg);
  }

  to {
    -webkit-transform: rotateX(360deg) rotateY(360deg);
            transform: rotateX(360deg) rotateY(360deg);
  }
}

@keyframes rotate-cube {
  from {
    -webkit-transform: rotateX(0deg) rotateY(0deg);
            transform: rotateX(0deg) rotateY(0deg);
  }

  to {
    -webkit-transform: rotateX(360deg) rotateY(360deg);
            transform: rotateX(360deg) rotateY(360deg);
  }
}

@-webkit-keyframes change-color {
  0% {
    background-color: #00BFFF;
  }

  25% {
    background-color: #FF1493;
  }

  50% {
    background-color: #32CD32;
  }

  75% {
    background-color: #FFA500;
  }

  100% {
    background-color: #00BFFF;
  }
}

@keyframes change-color {
  0% {
    background-color: #00BFFF;
  }

  25% {
    background-color: #FF1493;
  }

  50% {
    background-color: #32CD32;
  }

  75% {
    background-color: #FFA500;
  }

  100% {
    background-color: #00BFFF;
  }
}


/*statistics*/
.statistics {
    position: absolute;
    width: 75px;
    height: 100px;
    right:5%;
  bottom:-50%;
  }
  
  .statistics__bar {
    position: absolute;
    bottom: 0;
    width: 10px;
    height: 50%;
    background:whitesmoke;
    -webkit-transform-origin: center bottom;
        -ms-transform-origin: center bottom;
            transform-origin: center bottom;
    -webkit-box-shadow: 1px 1px 0 rgba(0, 0, 0, 0.2);
            box-shadow: 1px 1px 0 rgba(0, 0, 0, 0.2);
  }
  
  .statistics__bar:nth-child(1) {
    left: 0px;
    -webkit-transform: scale(1, 0.2);
        -ms-transform: scale(1, 0.2);
            transform: scale(1, 0.2);
    -webkit-animation: barUp1 4s infinite;
    animation: barUp1 4s infinite;
  }
  
  .statistics__bar:nth-child(2) {
    left: 15px;
    -webkit-transform: scale(1, 0.4);
        -ms-transform: scale(1, 0.4);
            transform: scale(1, 0.4);
    -webkit-animation: barUp2 4s infinite;
    animation: barUp2 4s infinite;
  }
  
  .statistics__bar:nth-child(3) {
    left: 30px;
    -webkit-transform: scale(1, 0.6);
        -ms-transform: scale(1, 0.6);
            transform: scale(1, 0.6);
    -webkit-animation: barUp3 4s infinite;
    animation: barUp3 4s infinite;
  }
  
  .statistics__bar:nth-child(4) {
    left: 45px;
    -webkit-transform: scale(1, 0.8);
        -ms-transform: scale(1, 0.8);
            transform: scale(1, 0.8);
    -webkit-animation: barUp4 4s infinite;
    animation: barUp4 4s infinite;
  }
  
  .statistics__bar:nth-child(5) {
    left: 60px;
    -webkit-transform: scale(1, 1);
        -ms-transform: scale(1, 1);
            transform: scale(1, 1);
    -webkit-animation: barUp5 4s infinite;
    animation: barUp5 4s infinite;
  }
  
  .statistics__ball {
    position: absolute;
    bottom: 10px;
    left: 0;
    width: 10px;
    height: 10px;
    background: rgb(44, 143, 255);
    border-radius: 50%;
    -webkit-animation: ball624 4s infinite;
    animation: ball624 4s infinite;
  }
  
  @-webkit-keyframes ball624 {
    0% {
      -webkit-transform: translate(0, 0);
              transform: translate(0, 0);
    }
  
    5% {
      -webkit-transform: translate(8px, -14px);
              transform: translate(8px, -14px);
    }
  
    10% {
      -webkit-transform: translate(15px, -10px);
              transform: translate(15px, -10px);
    }
  
    17% {
      -webkit-transform: translate(23px, -24px);
              transform: translate(23px, -24px);
    }
  
    20% {
      -webkit-transform: translate(30px, -20px);
              transform: translate(30px, -20px);
    }
  
    27% {
      -webkit-transform: translate(38px, -34px);
              transform: translate(38px, -34px);
    }
  
    30% {
      -webkit-transform: translate(45px, -30px);
              transform: translate(45px, -30px);
    }
  
    37% {
      -webkit-transform: translate(53px, -44px);
              transform: translate(53px, -44px);
    }
  
    40% {
      -webkit-transform: translate(60px, -40px);
              transform: translate(60px, -40px);
    }
  
    50% {
      -webkit-transform: translate(60px, 0);
              transform: translate(60px, 0);
    }
  
    57% {
      -webkit-transform: translate(53px, -14px);
              transform: translate(53px, -14px);
    }
  
    60% {
      -webkit-transform: translate(45px, -10px);
              transform: translate(45px, -10px);
    }
  
    67% {
      -webkit-transform: translate(37px, -24px);
              transform: translate(37px, -24px);
    }
  
    70% {
      -webkit-transform: translate(30px, -20px);
              transform: translate(30px, -20px);
    }
  
    77% {
      -webkit-transform: translate(22px, -34px);
              transform: translate(22px, -34px);
    }
  
    80% {
      -webkit-transform: translate(15px, -30px);
              transform: translate(15px, -30px);
    }
  
    87% {
      -webkit-transform: translate(7px, -44px);
              transform: translate(7px, -44px);
    }
  
    90% {
      -webkit-transform: translate(0, -40px);
              transform: translate(0, -40px);
    }
  
    100% {
      -webkit-transform: translate(0, 0);
              transform: translate(0, 0);
    }
  }
  
  @keyframes ball624 {
    0% {
      -webkit-transform: translate(0, 0);
              transform: translate(0, 0);
    }
  
    5% {
      -webkit-transform: translate(8px, -14px);
              transform: translate(8px, -14px);
    }
  
    10% {
      -webkit-transform: translate(15px, -10px);
              transform: translate(15px, -10px);
    }
  
    17% {
      -webkit-transform: translate(23px, -24px);
              transform: translate(23px, -24px);
    }
  
    20% {
      -webkit-transform: translate(30px, -20px);
              transform: translate(30px, -20px);
    }
  
    27% {
      -webkit-transform: translate(38px, -34px);
              transform: translate(38px, -34px);
    }
  
    30% {
      -webkit-transform: translate(45px, -30px);
              transform: translate(45px, -30px);
    }
  
    37% {
      -webkit-transform: translate(53px, -44px);
              transform: translate(53px, -44px);
    }
  
    40% {
      -webkit-transform: translate(60px, -40px);
              transform: translate(60px, -40px);
    }
  
    50% {
      -webkit-transform: translate(60px, 0);
              transform: translate(60px, 0);
    }
  
    57% {
      -webkit-transform: translate(53px, -14px);
              transform: translate(53px, -14px);
    }
  
    60% {
      -webkit-transform: translate(45px, -10px);
              transform: translate(45px, -10px);
    }
  
    67% {
      -webkit-transform: translate(37px, -24px);
              transform: translate(37px, -24px);
    }
  
    70% {
      -webkit-transform: translate(30px, -20px);
              transform: translate(30px, -20px);
    }
  
    77% {
      -webkit-transform: translate(22px, -34px);
              transform: translate(22px, -34px);
    }
  
    80% {
      -webkit-transform: translate(15px, -30px);
              transform: translate(15px, -30px);
    }
  
    87% {
      -webkit-transform: translate(7px, -44px);
              transform: translate(7px, -44px);
    }
  
    90% {
      -webkit-transform: translate(0, -40px);
              transform: translate(0, -40px);
    }
  
    100% {
      -webkit-transform: translate(0, 0);
              transform: translate(0, 0);
    }
  }
  
  @-webkit-keyframes barUp1 {
    0% {
      -webkit-transform: scale(1, 0.2);
              transform: scale(1, 0.2);
    }
  
    40% {
      -webkit-transform: scale(1, 0.2);
              transform: scale(1, 0.2);
    }
  
    50% {
      -webkit-transform: scale(1, 1);
              transform: scale(1, 1);
    }
  
    90% {
      -webkit-transform: scale(1, 1);
              transform: scale(1, 1);
    }
  
    100% {
      -webkit-transform: scale(1, 0.2);
              transform: scale(1, 0.2);
    }
  }
  
  @keyframes barUp1 {
    0% {
      -webkit-transform: scale(1, 0.2);
              transform: scale(1, 0.2);
    }
  
    40% {
      -webkit-transform: scale(1, 0.2);
              transform: scale(1, 0.2);
    }
  
    50% {
      -webkit-transform: scale(1, 1);
              transform: scale(1, 1);
    }
  
    90% {
      -webkit-transform: scale(1, 1);
              transform: scale(1, 1);
    }
  
    100% {
      -webkit-transform: scale(1, 0.2);
              transform: scale(1, 0.2);
    }
  }
  
  @-webkit-keyframes barUp2 {
    0% {
      -webkit-transform: scale(1, 0.4);
              transform: scale(1, 0.4);
    }
  
    40% {
      -webkit-transform: scale(1, 0.4);
              transform: scale(1, 0.4);
    }
  
    50% {
      -webkit-transform: scale(1, 0.8);
              transform: scale(1, 0.8);
    }
  
    90% {
      -webkit-transform: scale(1, 0.8);
              transform: scale(1, 0.8);
    }
  
    100% {
      -webkit-transform: scale(1, 0.4);
              transform: scale(1, 0.4);
    }
  }
  
  @keyframes barUp2 {
    0% {
      -webkit-transform: scale(1, 0.4);
              transform: scale(1, 0.4);
    }
  
    40% {
      -webkit-transform: scale(1, 0.4);
              transform: scale(1, 0.4);
    }
  
    50% {
      -webkit-transform: scale(1, 0.8);
              transform: scale(1, 0.8);
    }
  
    90% {
      -webkit-transform: scale(1, 0.8);
              transform: scale(1, 0.8);
    }
  
    100% {
      -webkit-transform: scale(1, 0.4);
              transform: scale(1, 0.4);
    }
  }
  
  @-webkit-keyframes barUp3 {
    0% {
      -webkit-transform: scale(1, 0.6);
              transform: scale(1, 0.6);
    }
  
    100% {
      -webkit-transform: scale(1, 0.6);
              transform: scale(1, 0.6);
    }
  }
  
  @keyframes barUp3 {
    0% {
      -webkit-transform: scale(1, 0.6);
              transform: scale(1, 0.6);
    }
  
    100% {
      -webkit-transform: scale(1, 0.6);
              transform: scale(1, 0.6);
    }
  }
  
  @-webkit-keyframes barUp4 {
    0% {
      -webkit-transform: scale(1, 0.8);
              transform: scale(1, 0.8);
    }
  
    40% {
      -webkit-transform: scale(1, 0.8);
              transform: scale(1, 0.8);
    }
  
    50% {
      -webkit-transform: scale(1, 0.4);
              transform: scale(1, 0.4);
    }
  
    90% {
      -webkit-transform: scale(1, 0.4);
              transform: scale(1, 0.4);
    }
  
    100% {
      -webkit-transform: scale(1, 0.8);
              transform: scale(1, 0.8);
    }
  }
  
  @keyframes barUp4 {
    0% {
      -webkit-transform: scale(1, 0.8);
              transform: scale(1, 0.8);
    }
  
    40% {
      -webkit-transform: scale(1, 0.8);
              transform: scale(1, 0.8);
    }
  
    50% {
      -webkit-transform: scale(1, 0.4);
              transform: scale(1, 0.4);
    }
  
    90% {
      -webkit-transform: scale(1, 0.4);
              transform: scale(1, 0.4);
    }
  
    100% {
      -webkit-transform: scale(1, 0.8);
              transform: scale(1, 0.8);
    }
  }
  
  @-webkit-keyframes barUp5 {
    0% {
      -webkit-transform: scale(1, 1);
              transform: scale(1, 1);
    }
  
    40% {
      -webkit-transform: scale(1, 1);
              transform: scale(1, 1);
    }
  
    50% {
      -webkit-transform: scale(1, 0.2);
              transform: scale(1, 0.2);
    }
  
    90% {
      -webkit-transform: scale(1, 0.2);
              transform: scale(1, 0.2);
    }
  
    100% {
      -webkit-transform: scale(1, 1);
              transform: scale(1, 1);
    }
  }
  
  @keyframes barUp5 {
    0% {
      -webkit-transform: scale(1, 1);
              transform: scale(1, 1);
    }
  
    40% {
      -webkit-transform: scale(1, 1);
              transform: scale(1, 1);
    }
  
    50% {
      -webkit-transform: scale(1, 0.2);
              transform: scale(1, 0.2);
    }
  
    90% {
      -webkit-transform: scale(1, 0.2);
              transform: scale(1, 0.2);
    }
  
    100% {
      -webkit-transform: scale(1, 1);
              transform: scale(1, 1);
    }
  }
 /*stics*/
 .pl,
.pl__worm {
  -webkit-animation-duration: 3s;
          animation-duration: 3s;
  -webkit-animation-iteration-count: infinite;
          animation-iteration-count: infinite;
          left:29%;
          top:10%;
          position:absolute;
}

.pl {
  -webkit-animation-name: bump9;
          animation-name: bump9;
  -webkit-animation-timing-function: linear;
          animation-timing-function: linear;
  width: 8em;
  height: 8em;
}

.pl__ring {
  stroke: hsla(var(--hue),10%,10%,0.1);
  -webkit-transition: stroke 0.3s;
  transition: stroke 0.3s;
}

.pl__worm {
  -webkit-animation-name: worm9;
          animation-name: worm9;
  -webkit-animation-timing-function: cubic-bezier(0.42,0.17,0.75,0.83);
          animation-timing-function: cubic-bezier(0.42,0.17,0.75,0.83);
}

/* Animations */
@-webkit-keyframes bump9 {
  from,
  42%,
  46%,
  51%,
  55%,
  59%,
  63%,
  67%,
  71%,
  74%,
  78%,
  81%,
  85%,
  88%,
  92%,
  to {
    -webkit-transform: translate(0,0);
            transform: translate(0,0);
  }

  44% {
    -webkit-transform: translate(1.33%,6.75%);
            transform: translate(1.33%,6.75%);
  }

  53% {
    -webkit-transform: translate(-16.67%,-0.54%);
            transform: translate(-16.67%,-0.54%);
  }

  61% {
    -webkit-transform: translate(3.66%,-2.46%);
            transform: translate(3.66%,-2.46%);
  }

  69% {
    -webkit-transform: translate(-0.59%,15.27%);
            transform: translate(-0.59%,15.27%);
  }

  76% {
    -webkit-transform: translate(-1.92%,-4.68%);
            transform: translate(-1.92%,-4.68%);
  }

  83% {
    -webkit-transform: translate(9.38%,0.96%);
            transform: translate(9.38%,0.96%);
  }

  90% {
    -webkit-transform: translate(-4.55%,1.98%);
            transform: translate(-4.55%,1.98%);
  }
}
@keyframes bump9 {
  from,
  42%,
  46%,
  51%,
  55%,
  59%,
  63%,
  67%,
  71%,
  74%,
  78%,
  81%,
  85%,
  88%,
  92%,
  to {
    -webkit-transform: translate(0,0);
            transform: translate(0,0);
  }

  44% {
    -webkit-transform: translate(1.33%,6.75%);
            transform: translate(1.33%,6.75%);
  }

  53% {
    -webkit-transform: translate(-16.67%,-0.54%);
            transform: translate(-16.67%,-0.54%);
  }

  61% {
    -webkit-transform: translate(3.66%,-2.46%);
            transform: translate(3.66%,-2.46%);
  }

  69% {
    -webkit-transform: translate(-0.59%,15.27%);
            transform: translate(-0.59%,15.27%);
  }

  76% {
    -webkit-transform: translate(-1.92%,-4.68%);
            transform: translate(-1.92%,-4.68%);
  }

  83% {
    -webkit-transform: translate(9.38%,0.96%);
            transform: translate(9.38%,0.96%);
  }

  90% {
    -webkit-transform: translate(-4.55%,1.98%);
            transform: translate(-4.55%,1.98%);
  }
}

@-webkit-keyframes worm9 {
  from {
    stroke-dashoffset: 10;
  }

  25% {
    stroke-dashoffset: 295;
  }

  to {
    stroke-dashoffset: 1165;
  }
}

@keyframes worm9 {
  from {
    stroke-dashoffset: 10;
  }

  25% {
    stroke-dashoffset: 295;
  }

  to {
    stroke-dashoffset: 1165;
  }
}


/*system.html*/

.system {
  display: block;
  width: 7em;
  height: 7em;
  overflow: visible;
  position:absolute;
  left:20%;
 bottom:-65%;
}

.system path.fill {
  fill: #2Af2;
  -webkit-animation: fill 4s ease-in-out infinite;
          animation: fill 4s ease-in-out infinite;
}

.system .dash path {
  stroke: #2AF;
  stroke-width: 1px;
  stroke-linecap: round;
  -webkit-animation: dashArray var(--sped, 2s) ease-in-out infinite,
    dashOffset var(--sped, 2s) linear infinite;
          animation: dashArray var(--sped, 2s) ease-in-out infinite,
    dashOffset var(--sped, 2s) linear infinite;
}

.system .dash path.aaa {
  stroke-width: 2px;
  stroke-linecap: butt;
  -webkit-clip-path: path('M 20.4603 48.5493 L 16.6461 46.9584 C 17.3209 48.3794 18.4917 49.5682 20.0447 50.2206 C 23.4007 51.6328 27.2707 50.0262 28.6694 46.6367 C 29.3464 44.9966 29.3509 43.1867 28.6806 41.5422 C 28.0103 39.8977 26.7434 38.6151 25.119 37.9315 C 23.5035 37.2544 21.7741 37.279 20.2547 37.8576 L 24.1961 39.5022 C 26.6719 40.5434 27.8427 43.4124 26.8104 45.9105 C 25.7803 48.4085 22.936 49.5905 20.4603 48.5493 Z');
          clip-path: path('M 20.4603 48.5493 L 16.6461 46.9584 C 17.3209 48.3794 18.4917 49.5682 20.0447 50.2206 C 23.4007 51.6328 27.2707 50.0262 28.6694 46.6367 C 29.3464 44.9966 29.3509 43.1867 28.6806 41.5422 C 28.0103 39.8977 26.7434 38.6151 25.119 37.9315 C 23.5035 37.2544 21.7741 37.279 20.2547 37.8576 L 24.1961 39.5022 C 26.6719 40.5434 27.8427 43.4124 26.8104 45.9105 C 25.7803 48.4085 22.936 49.5905 20.4603 48.5493 Z');
}

.system .dash path.big {
  stroke-width: 2px;
  -webkit-filter: drop-shadow(0 0 2px #2AF);
          filter: drop-shadow(0 0 2px #2AF);
}

@-webkit-keyframes dashArray {
  0% {
    stroke-dasharray: 0 1 359 0;
  }

  50% {
    stroke-dasharray: 0 359 1 0;
  }

  100% {
    stroke-dasharray: 359 1 0 0;
  }
}

@keyframes dashArray {
  0% {
    stroke-dasharray: 0 1 359 0;
  }

  50% {
    stroke-dasharray: 0 359 1 0;
  }

  100% {
    stroke-dasharray: 359 1 0 0;
  }
}

@-webkit-keyframes dashOffset {
  0% {
    stroke-dashoffset: -5;
  }

  100% {
    stroke-dashoffset: -365;
  }
}

@keyframes dashOffset {
  0% {
    stroke-dashoffset: -5;
  }

  100% {
    stroke-dashoffset: -365;
  }
}

@-webkit-keyframes fill {
  30%,
  55% {
    fill: #2AF0;
  }
}

@keyframes fill {
  30%,
  55% {
    fill: #2AF0;
  }
}


/*tube*/
.tube {
  display: -webkit-box;
  display: -ms-flexbox;
  display: flex;
  -webkit-box-align: center;
      -ms-flex-align: center;
          align-items: center;
  -webkit-box-pack: center;
      -ms-flex-pack: center;
          justify-content: center;
  -webkit-box-orient: horizontal;
  -webkit-box-direction: normal;
      -ms-flex-direction: row;
          flex-direction: row;
          position:absolute;
          right:-40%;
          bottom:-75%;
}

.slidetube {
  overflow: hidden;
  background-color: white;
  margin: 0 15px;
  height: 80px;
  width: 20px;
  border-radius: 30px;
  -webkit-box-shadow: 15px 15px 20px rgba(0, 0, 0, 0.1), -15px -15px 30px #fff,
    inset -5px -5px 10px rgba(0, 0, 255, 0.1),
    inset 5px 5px 10px rgba(0, 0, 0, 0.1);
          box-shadow: 15px 15px 20px rgba(0, 0, 0, 0.1), -15px -15px 30px #fff,
    inset -5px -5px 10px rgba(0, 0, 255, 0.1),
    inset 5px 5px 10px rgba(0, 0, 0, 0.1);
  position: relative;
}

.slidetube::before {
  content: "";
  position: absolute;
  top: 0;
  left: 0;
  height: 20px;
  width: 20px;
  border-radius: 100%;
  -webkit-box-shadow: inset 0px 0px 0px rgba(0, 0, 0, 0.3), 0px 420px 0 400px #2697f3,
    inset 0px 0px 0px rgba(0, 0, 0, 0.1);
          box-shadow: inset 0px 0px 0px rgba(0, 0, 0, 0.3), 0px 420px 0 400px #2697f3,
    inset 0px 0px 0px rgba(0, 0, 0, 0.1);
  -webkit-animation: animate_2 2.5s ease-in-out infinite;
          animation: animate_2 2.5s ease-in-out infinite;
  -webkit-animation-delay: calc(-0.5s * var(--i));
          animation-delay: calc(-0.5s * var(--i));
}

@-webkit-keyframes animate_2 {
  0% {
    -webkit-transform: translateY(250px);
            transform: translateY(250px);
    -webkit-filter: hue-rotate(0deg);
            filter: hue-rotate(0deg);
  }

  50% {
    -webkit-transform: translateY(0);
            transform: translateY(0);
  }

  100% {
    -webkit-transform: translateY(250px);
            transform: translateY(250px);
    -webkit-filter: hue-rotate(180deg);
            filter: hue-rotate(180deg);
  }
}

@keyframes animate_2 {
  0% {
    -webkit-transform: translateY(250px);
            transform: translateY(250px);
    -webkit-filter: hue-rotate(0deg);
            filter: hue-rotate(0deg);
  }

  50% {
    -webkit-transform: translateY(0);
            transform: translateY(0);
  }

  100% {
    -webkit-transform: translateY(250px);
            transform: translateY(250px);
    -webkit-filter: hue-rotate(180deg);
            filter: hue-rotate(180deg);
  }
}


/*waves
.waves{
            font-size: 7px;
            width: 10em;
            height: 10em;
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            transform: rotate(-135deg);
            animation: animate-rotate 10s infinite;
            
        }
        @keyframes animate-rotate {

            0%,23% {
                transform: rotate(calc(-135deg + 90deg * 0));
            }

            25%,47% {
                transform: rotate(calc(-135deg + 90deg * 1));
            }

            50%,73% {
                transform: rotate(calc(-135deg + 90deg * 2));
            }

            75%,97% {
                transform: rotate(calc(-135deg + 90deg * 3));
            }

            100% {
                transform: rotate(calc(-135deg + 90deg * 4));
            }
        }
        .waves span {
            position: relative;
        }
        .waves span::before,
        .waves span::after {
            content: '';
            position: absolute;
            box-sizing: border-box;
            border-style: none solid solid none;
            animation: 1.6s linear infinite;
            animation-name: animate-border-width, animate-border-color, animate-scale;
        }
        .waves span::after {
            animation-delay: -0.8s;
        }
        @keyframes animate-border-width {

            0%,100% {
                border-width: 0.1em;
            }
            25% {
                border-width: 1.5em;
            }
        }
        @keyframes animate-border-color {
            0%,25% {
                border-color: tomato;
            }
            50%,75% {
                border-color: gold;
            }
            100% {
                border-color: black;
            }
        }
        @keyframes animate-scale {
            from {
                width: 1%;
                height: 1%;
            }
            to {
                width: 100%;
                height: 100%;
            }
        }

*/
        /*wavespring*/


        .spring {
  position: absolute;
 
  height: 90%;
  display: -webkit-box;
  display: -ms-flexbox;
  display: flex;
  -webkit-box-pack: center;
      -ms-flex-pack: center;
          justify-content: center;
  -webkit-box-align: center;
      -ms-flex-align: center;
          align-items: center;
          left:70%;
        
          bottom:-95%;
          position:absolute;
}

.itemg {
  position: absolute;
  background-color: transparent;
  width: calc(var(--i) * 2.5vmin);
  aspect-ratio: 1;
  border-radius: 50%;
  border: .9vmin solid rgb(0, 200, 255);
  -webkit-transform-style: preserve-3d;
          transform-style: preserve-3d;
  -webkit-transform: rotateX(70deg) translateZ(50px);
          transform: rotateX(70deg) translateZ(50px);
  -webkit-animation: my-move 3s ease-in-out calc(var(--i) * 0.08s) infinite;
          animation: my-move 3s ease-in-out calc(var(--i) * 0.08s) infinite;
  -webkit-box-shadow: 0px 0px 15px rgb(124, 124, 124),
    inset 0px 0px 15px rgb(124, 124, 124);
          box-shadow: 0px 0px 15px rgb(124, 124, 124),
    inset 0px 0px 15px rgb(124, 124, 124);
}

@-webkit-keyframes my-move {
  0%,
  100% {
    -webkit-transform: rotateX(70deg) translateZ(50px) translateY(0px);
            transform: rotateX(70deg) translateZ(50px) translateY(0px);
    -webkit-filter: hue-rotate(0deg);
            filter: hue-rotate(0deg);
  }

  50% {
    -webkit-transform: rotateX(70deg) translateZ(50px) translateY(-50vmin);
            transform: rotateX(70deg) translateZ(50px) translateY(-50vmin);
    -webkit-filter: hue-rotate(180deg);
            filter: hue-rotate(180deg);
  }
}

@keyframes my-move {
  0%,
  100% {
    -webkit-transform: rotateX(70deg) translateZ(50px) translateY(0px);
            transform: rotateX(70deg) translateZ(50px) translateY(0px);
    -webkit-filter: hue-rotate(0deg);
            filter: hue-rotate(0deg);
  }

  50% {
    -webkit-transform: rotateX(70deg) translateZ(50px) translateY(-50vmin);
            transform: rotateX(70deg) translateZ(50px) translateY(-50vmin);
    -webkit-filter: hue-rotate(180deg);
            filter: hue-rotate(180deg);
  }
}


/*white*/
.whiter {
  width: 48px;
  height: 48px;
  position: absolute;
  right:40%;
 top:20%;
}
.whiter::before , .loader::after{
  content: '';
  position: absolute;
  left: 50%;
  top: 50%;
  -webkit-transform: translate(-50% , -50%);
      -ms-transform: translate(-50% , -50%);
          transform: translate(-50% , -50%);
  width: 48em;
  height: 48em;
  background-image:
    radial-gradient(circle 10px, #FFF 100%, transparent 0),
    radial-gradient(circle 10px, #FFF 100%, transparent 0),
    radial-gradient(circle 10px, #FFF 100%, transparent 0),
    radial-gradient(circle 10px, #FFF 100%, transparent 0),
    radial-gradient(circle 10px, #FFF 100%, transparent 0),
    radial-gradient(circle 10px, #FFF 100%, transparent 0),
    radial-gradient(circle 10px, #FFF 100%, transparent 0),
    radial-gradient(circle 10px, #FFF 100%, transparent 0);
  background-position: 0em -18em, 0em 18em, 18em 0em, -18em 0em,
                       13em -13em, -13em -13em, 13em 13em, -13em 13em;
    background-repeat: no-repeat;
  font-size: 0.5px;
  border-radius: 50%;
  -webkit-animation: blast 1s ease-in infinite;
          animation: blast 1s ease-in infinite;
}
.whiter::after {
  font-size: 1px;
  background: #fff;
  -webkit-animation: bounce 1s ease-in infinite;
          animation: bounce 1s ease-in infinite;
}

@-webkit-keyframes bounce {
  0% , 100%{ font-size: 0.75px }
  50% { font-size: 1.5px }
}

@keyframes bounce {
  0% , 100%{ font-size: 0.75px }
  50% { font-size: 1.5px }
}
@-webkit-keyframes blast {
  0% , 40% {
    font-size: 0.5px;
  }
  70% {
    opacity: 1;
    font-size: 4px;
  }
   100% {
     font-size: 6px;
    opacity: 0;
  }
}
@keyframes blast {
  0% , 40% {
    font-size: 0.5px;
  }
  70% {
    opacity: 1;
    font-size: 4px;
  }
   100% {
     font-size: 6px;
    opacity: 0;
  }
}

/*you


.absolute {
  position: absolute;
  margin-bottom:5%;
 bottom:30%;
  align-items: center;
  justify-content: center;
}

.inline-block {
  display: inline-block;
}

.you {
  display: -webkit-box;
  display: -ms-flexbox;
  display: flex;
  margin: 0.25em 0;
}

.w-2 {
  width: 0.5em;
}

.dashu {
  -webkit-animation: dashArray 2s ease-in-out infinite,
    dashOffset 2s linear infinite;
          animation: dashArray 2s ease-in-out infinite,
    dashOffset 2s linear infinite;
}

.spinu {
  -webkit-animation: spinDashArray 2s ease-in-out infinite,
    spin 8s ease-in-out infinite,
    dashOffset 2s linear infinite;
          animation: spinDashArray 2s ease-in-out infinite,
    spin 8s ease-in-out infinite,
    dashOffset 2s linear infinite;
  -webkit-transform-origin: center;
      -ms-transform-origin: center;
          transform-origin: center;
}


@-webkit-keyframes dashArray {
  0% {
    stroke-dasharray: 0 1 359 0;
  }
  50% {
    stroke-dasharray: 0 359 1 0;
  }
  100% {
    stroke-dasharray: 359 1 0 0;
  }
}


@keyframes dashArray {
  0% {
    stroke-dasharray: 0 1 359 0;
  }
  50% {
    stroke-dasharray: 0 359 1 0;
  }
  100% {
    stroke-dasharray: 359 1 0 0;
  }
}

@-webkit-keyframes spinDashArray {
  0% {
    stroke-dasharray: 270 90;
  }
  50% {
    stroke-dasharray: 0 360;
  }
  100% {
    stroke-dasharray: 270 90;
  }
}

@keyframes spinDashArray {
  0% {
    stroke-dasharray: 270 90;
  }
  50% {
    stroke-dasharray: 0 360;
  }
  100% {
    stroke-dasharray: 270 90;
  }
}

@-webkit-keyframes dashOffset {
  0% {
    stroke-dashoffset: 365;
  }
  100% {
    stroke-dashoffset: 5;
  }
}

@keyframes dashOffset {
  0% {
    stroke-dashoffset: 365;
  }
  100% {
    stroke-dashoffset: 5;
  }
}

@-webkit-keyframes spin {
  0% {
    rotate: 0deg;
  }
  12.5%,
  25% {
    rotate: 270deg;
  }
  37.5%,
  50% {
    rotate: 540deg;
  }
  62.5%,
  75% {
    rotate: 810deg;
  }
  87.5%,
  100% {
    rotate: 1080deg;
  }
}

@keyframes spin {
  0% {
    rotate: 0deg;
  }
  12.5%,
  25% {
    rotate: 270deg;
  }
  37.5%,
  50% {
    rotate: 540deg;
  }
  62.5%,
  75% {
    rotate: 810deg;
  }
  87.5%,
  100% {
    rotate: 1080deg;
  }
}
*/

        </style>
        </head>








<?php
include 'partials/header.php';

?>
    <section class="empty_page">
    </section>
    <div class="ninjer">
        <div class="ninjers"></div>
        <div class="ninjers"></div>
        <div class="ninjers"></div>
        <div class="ninjers"></div>
        <div class="ninjers"></div>
        <div class="ninjers"></div>
        <div class="ninjers"></div>
        <div class="ninjers"></div>
    </div>


    <svg xmlns="http://www.w3.org/2000/svg" height="200px" width="200px" viewBox="0 0 200 200" class="pencil">
        <defs>
            <clipPath id="pencil-eraser">
                <rect height="30" width="30" ry="5" rx="5"></rect>
            </clipPath>
        </defs>
        <circle transform="rotate(-113,100,100)" stroke-linecap="round" stroke-dashoffset="439.82" stroke-dasharray="439.82 439.82" stroke-width="2" stroke="currentColor" fill="none" r="70" class="pencil__stroke"></circle>
        <g transform="translate(100,100)" class="pencil__rotate">
            <g fill="none">
                <circle transform="rotate(-90)" stroke-dashoffset="402" stroke-dasharray="402.12 402.12" stroke-width="30" stroke="hsl(223,90%,50%)" r="64" class="pencil__body1"></circle>
                <circle transform="rotate(-90)" stroke-dashoffset="465" stroke-dasharray="464.96 464.96" stroke-width="10" stroke="hsl(223,90%,60%)" r="74" class="pencil__body2"></circle>
                <circle transform="rotate(-90)" stroke-dashoffset="339" stroke-dasharray="339.29 339.29" stroke-width="10" stroke="hsl(223,90%,40%)" r="54" class="pencil__body3"></circle>
            </g>
            <g transform="rotate(-90) translate(49,0)" class="pencil__eraser">
                <g class="pencil__eraser-skew">
                    <rect height="30" width="30" ry="5" rx="5" fill="hsl(223,90%,70%)"></rect>
                    <rect clip-path="url(#pencil-eraser)" height="30" width="5" fill="hsl(223,90%,60%)"></rect>
                    <rect height="20" width="30" fill="hsl(223,10%,90%)"></rect>
                    <rect height="20" width="15" fill="hsl(223,10%,70%)"></rect>
                    <rect height="20" width="5" fill="hsl(223,10%,80%)"></rect>
                    <rect height="2" width="30" y="6" fill="hsla(223,10%,10%,0.2)"></rect>
                    <rect height="2" width="30" y="13" fill="hsla(223,10%,10%,0.2)"></rect>
                </g>
            </g>
            <g transform="rotate(-90) translate(49,-30)" class="pencil__point">
                <polygon points="15 0,30 30,0 30" fill="hsl(33,90%,70%)"></polygon>
                <polygon points="15 0,6 30,0 30" fill="hsl(33,90%,50%)"></polygon>
                <polygon points="15 0,20 10,10 10" fill="hsl(223,10%,10%)"></polygon>
            </g>
        </g>
    </svg>


    <div class="pingpong">
        <div class="ballpong"></div>
        <div class="ballpong"></div>
        <div class="ballpong"></div>

        <div class="shadowpong"></div>
        <div class="shadowpong"></div>
        <div class="shadowpong"></div>
    </div>


    <div class="pyramid-loader">
        <div class="wrapper">
          <span class="side side1"></span>
          <span class="side side2"></span>
          <span class="side side3"></span>
          <span class="side side4"></span>
          <span class="shadow"></span>
        </div>  
      </div>

      <div class="spinner"></div>


      <div class="lamp">
        <div class="glass">
          <div class="lava">
            <div class="blob"></div>
            <div class="blob"></div>
            <div class="blob"></div>
            <div class="blob top"></div>
            <div class="blob bottom"></div>
          </div>
        </div>
      </div>
      
      <svg xmlns="http://www.w3.org/2000/svg" version="1.1">
        <defs>
          <filter id="goo">
            <feGaussianBlur in="SourceGraphic" stdDeviation="10" result="blur"></feGaussianBlur>
            <feColorMatrix in="blur" mode="matrix" values="1 0 0 0 0  0 1 0 0 0  0 0 1 0 0  0 0 0 18 -7" result="goo"></feColorMatrix>
            <feBlend in="SourceGraphic" in2="goo"></feBlend>
          </filter>
        </defs>
      </svg>

      <div class="ringerball"></div>


      <div class="svg-frame">
        <svg style="--i:0;--j:0;">
            <g id="out1">
                <path d="M72 172C72 116.772 116.772 72 172 72C227.228 72 272 116.772 272 172C272 227.228 227.228 272 172 272C116.772 272 72 227.228 72 172ZM197.322 172C197.322 158.015 185.985 146.678 172 146.678C158.015 146.678 146.678 158.015 146.678 172C146.678 185.985 158.015 197.322 172 197.322C185.985 197.322 197.322 185.985 197.322 172Z"></path>
                <path mask="url(#path-1-inside-1_111_3212)" stroke-miterlimit="16" stroke-width="2" stroke="#00FFFF" d="M72 172C72 116.772 116.772 72 172 72C227.228 72 272 116.772 272 172C272 227.228 227.228 272 172 272C116.772 272 72 227.228 72 172ZM197.322 172C197.322 158.015 185.985 146.678 172 146.678C158.015 146.678 146.678 158.015 146.678 172C146.678 185.985 158.015 197.322 172 197.322C185.985 197.322 197.322 185.985 197.322 172Z"></path>
            </g>
        </svg>
    
        <svg style="--i:1;--j:1;">
            <g id="out2">
                <mask fill="white" id="path-2-inside-2_111_3212">
                    <path d="M102.892 127.966C93.3733 142.905 88.9517 160.527 90.2897 178.19L94.3752 177.88C93.1041 161.1 97.3046 144.36 106.347 130.168L102.892 127.966Z"></path>
                    <path d="M93.3401 194.968C98.3049 211.971 108.646 226.908 122.814 237.541L125.273 234.264C111.814 224.163 101.99 209.973 97.2731 193.819L93.3401 194.968Z"></path>
                    <path d="M152.707 92.3592C140.33 95.3575 128.822 101.199 119.097 109.421L121.742 112.55C130.981 104.739 141.914 99.1897 153.672 96.3413L152.707 92.3592Z"></path>
                    <path d="M253.294 161.699C255.099 175.937 253.132 190.4 247.59 203.639L243.811 202.057C249.075 189.48 250.944 175.74 249.23 162.214L253.294 161.699Z"></path>
                    <path d="M172 90.0557C184.677 90.0557 197.18 92.9967 208.528 98.6474C219.875 104.298 229.757 112.505 237.396 122.621L234.126 125.09C226.869 115.479 217.481 107.683 206.701 102.315C195.921 96.9469 184.043 94.1529 172 94.1529V90.0557Z"></path>
                    <path d="M244.195 133.235C246.991 138.442 249.216 143.937 250.83 149.623L246.888 150.742C245.355 145.34 243.242 140.12 240.586 135.174L244.195 133.235Z"></path>
                    <path d="M234.238 225.304C223.932 237.338 210.358 246.126 195.159 250.604C179.961 255.082 163.79 255.058 148.606 250.534L149.775 246.607C164.201 250.905 179.563 250.928 194.001 246.674C208.44 242.42 221.335 234.071 231.126 222.639L234.238 225.304Z"></path>
                </mask>
                <path mask="url(#path-2-inside-2_111_3212)" fill="#00FFFF" d="M102.892 127.966L105.579 123.75L101.362 121.063L98.6752 125.28L102.892 127.966ZM90.2897 178.19L85.304 178.567L85.6817 183.553L90.6674 183.175L90.2897 178.19ZM94.3752 177.88L94.7529 182.866L99.7386 182.488L99.3609 177.503L94.3752 177.88ZM106.347 130.168L110.564 132.855L113.251 128.638L109.034 125.951L106.347 130.168ZM93.3401 194.968L91.9387 190.168L87.1391 191.569L88.5405 196.369L93.3401 194.968ZM122.814 237.541L119.813 241.54L123.812 244.541L126.813 240.542L122.814 237.541ZM125.273 234.264L129.272 237.265L132.273 233.266L128.274 230.265L125.273 234.264ZM97.2731 193.819L102.073 192.418L100.671 187.618L95.8717 189.02L97.2731 193.819ZM152.707 92.3592L157.567 91.182L156.389 86.3226L151.53 87.4998L152.707 92.3592ZM119.097 109.421L115.869 105.603L112.05 108.831L115.278 112.649L119.097 109.421ZM121.742 112.55L117.924 115.778L121.152 119.596L124.97 116.368L121.742 112.55ZM153.672 96.3413L154.849 101.201L159.708 100.023L158.531 95.1641L153.672 96.3413ZM253.294 161.699L258.255 161.07L257.626 156.11L252.666 156.738L253.294 161.699ZM247.59 203.639L245.66 208.251L250.272 210.182L252.203 205.569L247.59 203.639ZM243.811 202.057L239.198 200.126L237.268 204.739L241.88 206.669L243.811 202.057ZM249.23 162.214L248.601 157.253L243.641 157.882L244.269 162.842L249.23 162.214ZM172 90.0557V85.0557H167V90.0557H172ZM208.528 98.6474L206.299 103.123L206.299 103.123L208.528 98.6474ZM237.396 122.621L240.409 126.611L244.399 123.598L241.386 119.608L237.396 122.621ZM234.126 125.09L230.136 128.103L233.149 132.093L237.139 129.08L234.126 125.09ZM206.701 102.315L204.473 106.791L204.473 106.791L206.701 102.315ZM172 94.1529H167V99.1529H172V94.1529ZM244.195 133.235L248.601 130.87L246.235 126.465L241.83 128.83L244.195 133.235ZM250.83 149.623L252.195 154.433L257.005 153.067L255.64 148.257L250.83 149.623ZM246.888 150.742L242.078 152.107L243.444 156.917L248.254 155.552L246.888 150.742ZM240.586 135.174L238.22 130.768L233.815 133.134L236.181 137.539L240.586 135.174ZM234.238 225.304L238.036 228.556L241.288 224.759L237.491 221.506L234.238 225.304ZM195.159 250.604L196.572 255.4L196.572 255.4L195.159 250.604ZM148.606 250.534L143.814 249.107L142.386 253.899L147.178 255.326L148.606 250.534ZM149.775 246.607L151.203 241.816L146.411 240.388L144.983 245.18L149.775 246.607ZM194.001 246.674L195.415 251.47L195.415 251.47L194.001 246.674ZM231.126 222.639L234.379 218.841L230.581 215.589L227.329 219.386L231.126 222.639ZM98.6752 125.28C88.5757 141.13 83.8844 159.826 85.304 178.567L95.2754 177.812C94.0191 161.227 98.1709 144.681 107.109 130.653L98.6752 125.28ZM90.6674 183.175L94.7529 182.866L93.9976 172.895L89.912 173.204L90.6674 183.175ZM99.3609 177.503C98.1715 161.8 102.102 146.135 110.564 132.855L102.131 127.481C92.5071 142.585 88.0368 160.4 89.3895 178.258L99.3609 177.503ZM109.034 125.951L105.579 123.75L100.205 132.183L103.661 134.385L109.034 125.951ZM88.5405 196.369C93.8083 214.41 104.78 230.259 119.813 241.54L125.815 233.542C112.512 223.558 102.802 209.532 98.1397 193.566L88.5405 196.369ZM126.813 240.542L129.272 237.265L121.274 231.263L118.815 234.54L126.813 240.542ZM128.274 230.265C115.679 220.813 106.486 207.534 102.073 192.418L92.4735 195.221C97.493 212.412 107.948 227.513 122.272 238.263L128.274 230.265ZM95.8717 189.02L91.9387 190.168L94.7415 199.767L98.6745 198.619L95.8717 189.02ZM151.53 87.4998C138.398 90.681 126.188 96.8793 115.869 105.603L122.325 113.239C131.457 105.519 142.262 100.034 153.884 97.2187L151.53 87.4998ZM115.278 112.649L117.924 115.778L125.56 109.322L122.915 106.193L115.278 112.649ZM124.97 116.368C133.616 109.059 143.846 103.866 154.849 101.201L152.495 91.4818C139.981 94.5132 128.347 100.419 118.514 108.732L124.97 116.368ZM158.531 95.1641L157.567 91.182L147.848 93.5364L148.812 97.5185L158.531 95.1641ZM248.334 162.327C250.028 175.697 248.181 189.277 242.978 201.708L252.203 205.569C258.082 191.522 260.169 176.177 258.255 161.07L248.334 162.327ZM249.521 199.027L245.741 197.445L241.88 206.669L245.66 208.251L249.521 199.027ZM248.423 203.987C254.025 190.602 256.014 175.98 254.19 161.585L244.269 162.842C245.873 175.5 244.125 188.357 239.198 200.126L248.423 203.987ZM249.858 167.174L253.923 166.659L252.666 156.738L248.601 157.253L249.858 167.174ZM172 95.0557C183.903 95.0557 195.644 97.8172 206.299 103.123L210.757 94.1717C198.717 88.1761 185.45 85.0557 172 85.0557V95.0557ZM206.299 103.123C216.954 108.429 226.233 116.135 233.406 125.634L241.386 119.608C233.281 108.874 222.796 100.167 210.757 94.1717L206.299 103.123ZM234.383 118.631L231.113 121.1L237.139 129.08L240.409 126.611L234.383 118.631ZM238.116 122.077C230.393 111.849 220.403 103.552 208.93 97.8393L204.473 106.791C214.56 111.814 223.345 119.11 230.136 128.103L238.116 122.077ZM208.93 97.8393C197.458 92.1263 184.816 89.1529 172 89.1529V99.1529C183.269 99.1529 194.385 101.767 204.473 106.791L208.93 97.8393ZM177 94.1529V90.0557H167V94.1529H177ZM239.79 135.601C242.416 140.49 244.504 145.649 246.02 150.988L255.64 148.257C253.927 142.225 251.567 136.395 248.601 130.87L239.79 135.601ZM249.464 144.813L245.523 145.932L248.254 155.552L252.195 154.433L249.464 144.813ZM251.698 149.376C250.067 143.628 247.818 138.073 244.991 132.808L236.181 137.539C238.666 142.168 240.644 147.052 242.078 152.107L251.698 149.376ZM242.951 139.579L246.561 137.64L241.83 128.83L238.22 130.768L242.951 139.579ZM230.441 222.051C220.763 233.351 208.017 241.603 193.746 245.808L196.572 255.4C212.698 250.649 227.101 241.325 238.036 228.556L230.441 222.051ZM193.746 245.808C179.475 250.012 164.291 249.99 150.033 245.742L147.178 255.326C163.289 260.125 180.447 260.151 196.572 255.4L193.746 245.808ZM153.397 251.962L154.567 248.035L144.983 245.18L143.814 249.107L153.397 251.962ZM148.348 251.399C163.7 255.973 180.049 255.997 195.415 251.47L192.588 241.877C179.077 245.858 164.702 245.837 151.203 241.816L148.348 251.399ZM195.415 251.47C210.78 246.942 224.504 238.058 234.924 225.891L227.329 219.386C218.167 230.084 206.099 237.897 192.588 241.877L195.415 251.47ZM227.874 226.436L230.986 229.101L237.491 221.506L234.379 218.841L227.874 226.436Z"></path>
            </g>
        </svg>
    
        <svg style="--i:0;--j:2;">
            <g id="inner3">
                <path d="M195.136 135.689C188.115 131.215 179.948 128.873 171.624 128.946C163.299 129.019 155.174 131.503 148.232 136.099L148.42 136.382C155.307 131.823 163.368 129.358 171.627 129.286C179.886 129.213 187.988 131.537 194.954 135.975L195.136 135.689Z"></path>
                <path d="M195.136 208.311C188.115 212.784 179.948 215.127 171.624 215.054C163.299 214.981 155.174 212.496 148.232 207.901L148.42 207.618C155.307 212.177 163.368 214.642 171.627 214.714C179.886 214.786 187.988 212.463 194.954 208.025L195.136 208.311Z"></path>
                <path mask="url(#path-5-inside-3_111_3212)" fill="#00FFFF" d="M195.136 135.689L195.474 135.904L195.689 135.566L195.351 135.352L195.136 135.689ZM171.624 128.946L171.627 129.346L171.624 128.946ZM148.232 136.099L148.011 135.765L147.678 135.986L147.899 136.32L148.232 136.099ZM148.42 136.382L148.086 136.603L148.307 136.936L148.641 136.716L148.42 136.382ZM171.627 129.286L171.63 129.686L171.627 129.286ZM194.954 135.975L194.739 136.313L195.076 136.528L195.291 136.19L194.954 135.975ZM195.136 208.311L195.351 208.648L195.689 208.433L195.474 208.096L195.136 208.311ZM171.624 215.054L171.627 214.654L171.624 215.054ZM148.232 207.901L147.899 207.68L147.678 208.014L148.011 208.234L148.232 207.901ZM148.42 207.618L148.641 207.284L148.307 207.063L148.086 207.397L148.42 207.618ZM171.627 214.714L171.63 214.314L171.627 214.714ZM194.954 208.025L195.291 207.81L195.076 207.472L194.739 207.687L194.954 208.025ZM195.351 135.352C188.265 130.836 180.022 128.473 171.62 128.546L171.627 129.346C179.874 129.274 187.966 131.594 194.921 136.026L195.351 135.352ZM171.62 128.546C163.218 128.619 155.018 131.127 148.011 135.765L148.453 136.432C155.33 131.88 163.38 129.418 171.627 129.346L171.62 128.546ZM147.899 136.32L148.086 136.603L148.753 136.161L148.566 135.878L147.899 136.32ZM148.641 136.716C155.463 132.199 163.448 129.757 171.63 129.686L171.623 128.886C163.287 128.958 155.15 131.447 148.199 136.049L148.641 136.716ZM171.63 129.686C179.812 129.614 187.839 131.916 194.739 136.313L195.169 135.638C188.138 131.158 179.959 128.813 171.623 128.886L171.63 129.686ZM195.291 136.19L195.474 135.904L194.799 135.474L194.617 135.76L195.291 136.19ZM194.921 207.974C187.966 212.406 179.874 214.726 171.627 214.654L171.62 215.454C180.022 215.527 188.265 213.163 195.351 208.648L194.921 207.974ZM171.627 214.654C163.38 214.582 155.33 212.12 148.453 207.567L148.011 208.234C155.018 212.873 163.218 215.38 171.62 215.454L171.627 214.654ZM148.566 208.122L148.753 207.838L148.086 207.397L147.899 207.68L148.566 208.122ZM148.199 207.951C155.15 212.553 163.287 215.041 171.623 215.114L171.63 214.314C163.448 214.243 155.463 211.801 148.641 207.284L148.199 207.951ZM171.623 215.114C179.959 215.187 188.138 212.842 195.169 208.362L194.739 207.687C187.839 212.084 179.812 214.386 171.63 214.314L171.623 215.114ZM194.617 208.239L194.799 208.526L195.474 208.096L195.291 207.81L194.617 208.239Z"></path>
            </g>
            <path stroke="#00FFFF" d="M240.944 172C240.944 187.951 235.414 203.408 225.295 215.738C215.176 228.068 201.095 236.508 185.45 239.62C169.806 242.732 153.567 240.323 139.5 232.804C125.433 225.285 114.408 213.12 108.304 198.384C102.2 183.648 101.394 167.25 106.024 151.987C110.654 136.723 120.434 123.537 133.696 114.675C146.959 105.813 162.884 101.824 178.758 103.388C194.632 104.951 209.472 111.97 220.751 123.249" id="out3"></path>
        </svg>
    
        <svg style="--i:1;--j:3;">
            <g id="inner1">
                <path fill="#00FFFF" d="M145.949 124.51L148.554 129.259C156.575 124.859 165.672 122.804 174.806 123.331C183.94 123.858 192.741 126.944 200.203 132.236C207.665 137.529 213.488 144.815 217.004 153.261C220.521 161.707 221.59 170.972 220.09 179.997L224.108 180.665L224.102 180.699L229.537 181.607C230.521 175.715 230.594 169.708 229.753 163.795L225.628 164.381C224.987 159.867 223.775 155.429 222.005 151.179C218.097 141.795 211.628 133.699 203.337 127.818C195.045 121.937 185.266 118.508 175.118 117.923C165.302 117.357 155.525 119.474 146.83 124.037C146.535 124.192 146.241 124.349 145.949 124.51ZM224.638 164.522C224.009 160.091 222.819 155.735 221.082 151.563C217.246 142.352 210.897 134.406 202.758 128.634C194.62 122.862 185.021 119.496 175.06 118.922C165.432 118.367 155.841 120.441 147.311 124.914L148.954 127.91C156.922 123.745 165.876 121.814 174.864 122.333C184.185 122.87 193.166 126.019 200.782 131.421C208.397 136.822 214.339 144.257 217.928 152.877C221.388 161.188 222.526 170.276 221.23 179.173L224.262 179.677C224.998 174.671 225.35 169.535 224.638 164.522Z" clip-rule="evenodd" fill-rule="evenodd"></path>
                <path fill="#00FFFF" d="M139.91 220.713C134.922 217.428 130.469 213.395 126.705 208.758L130.983 205.286L130.985 205.288L134.148 202.721C141.342 211.584 151.417 217.642 162.619 219.839C173.821 222.036 185.438 220.232 195.446 214.742L198.051 219.491C197.759 219.651 197.465 219.809 197.17 219.963C186.252 225.693 173.696 227.531 161.577 225.154C154.613 223.789 148.041 221.08 142.202 217.234L139.91 220.713ZM142.752 216.399C148.483 220.174 154.934 222.833 161.769 224.173C173.658 226.504 185.977 224.704 196.689 219.087L195.046 216.09C185.035 221.323 173.531 222.998 162.427 220.82C151.323 218.643 141.303 212.747 134.01 204.122L131.182 206.5C134.451 210.376 138.515 213.607 142.752 216.399Z" clip-rule="evenodd" fill-rule="evenodd"></path>
            </g>
        </svg>
    
        <svg style="--i:2;--j:4;">
            <path fill="#00FFFF" d="M180.956 186.056C183.849 184.212 186.103 181.521 187.41 178.349C188.717 175.177 189.013 171.679 188.258 168.332C187.503 164.986 185.734 161.954 183.192 159.65C180.649 157.346 177.458 155.883 174.054 155.46C170.649 155.038 167.197 155.676 164.169 157.288C161.14 158.9 158.683 161.407 157.133 164.468C155.582 167.528 155.014 170.992 155.505 174.388C155.997 177.783 157.524 180.944 159.879 183.439L161.129 182.259C159.018 180.021 157.648 177.186 157.207 174.141C156.766 171.096 157.276 167.989 158.667 165.245C160.057 162.5 162.261 160.252 164.977 158.806C167.693 157.36 170.788 156.788 173.842 157.167C176.895 157.546 179.757 158.858 182.037 160.924C184.317 162.99 185.904 165.709 186.581 168.711C187.258 171.712 186.992 174.849 185.82 177.694C184.648 180.539 182.627 182.952 180.032 184.606L180.956 186.056Z" id="center1"></path>
            <path fill="#00FFFF" d="M172 166.445C175.068 166.445 177.556 168.932 177.556 172C177.556 175.068 175.068 177.556 172 177.556C168.932 177.556 166.444 175.068 166.444 172C166.444 168.932 168.932 166.445 172 166.445ZM172 177.021C174.773 177.021 177.021 174.773 177.021 172C177.021 169.227 174.773 166.979 172 166.979C169.227 166.979 166.979 169.227 166.979 172C166.979 174.773 169.227 177.021 172 177.021Z" id="center"></path>
        </svg>
    
    </div>



    <button>
        <div class="main">
          <div class="rings" id="ring1"></div>
          <div class="rings" id="ring2"></div>
          <div class="asteriods-large" id="asteriod1"></div>
          <div class="asteriods-large" id="asteriod2"></div>
          <div class="asteriods-large" id="asteriod3"></div>
          <div class="asteriods-large" id="asteriod4"></div>
          <div class="asteriods-large" id="asteriod5"></div>
          <div class="asteriods-small" id="asteriod6"></div>
          <div class="asteriods-small" id="asteriod7"></div>
          <div class="asteriods-small" id="asteriod8"></div>
          <div class="asteriods-small" id="asteriod9"></div>
          <div class="asteriods-small" id="asteriod10"></div>
          <div id="saturn"></div>
          <div id="explore">Explore</div>
      
        </div>
      </button>


      <div id="wifi-searcher">
        <svg class="circle-outer" viewBox="0 0 86 86">
            <circle class="back" cx="43" cy="43" r="40"></circle>
            <circle class="front" cx="43" cy="43" r="40"></circle>
            <circle class="new" cx="43" cy="43" r="40"></circle>
        </svg>
        <svg class="circle-middle" viewBox="0 0 60 60">
            <circle class="back" cx="30" cy="30" r="27"></circle>
            <circle class="front" cx="30" cy="30" r="27"></circle>
        </svg>
        <svg class="circle-inner" viewBox="0 0 34 34">
            <circle class="back" cx="17" cy="17" r="14"></circle>
            <circle class="front" cx="17" cy="17" r="14"></circle>
        </svg>
        <div class="text" data-text="Searching"></div>
    </div>

    <div class="uni">
        <div class="sunny"></div>
        <div class="earthy">
          <div class="moony"></div>
        </div>
      </div>


      <div class="solarpanel">
        <div class="card"></div>
        <div class="card"></div>
        <div class="card"></div>
        <div class="card"></div>
        <div class="card"></div>
        <div class="card"></div>
        <div class="card"></div>
        <div class="card"></div>
        <div class="card"></div> 
        <div class="card"></div>
        <div class="card"></div>
        <div class="card"></div> 
        <div class="card"></div>
        <div class="card"></div>
        <div class="card"></div> 
      </div>


      <div class="box-of-star1">
        <div class="star star-position1"></div>
        <div class="star star-position2"></div>
        <div class="star star-position3"></div>
        <div class="star star-position4"></div>
        <div class="star star-position5"></div>
        <div class="star star-position6"></div>
        <div class="star star-position7"></div>
      </div>
      <div class="box-of-star2">
        <div class="star star-position1"></div>
        <div class="star star-position2"></div>
        <div class="star star-position3"></div>
        <div class="star star-position4"></div>
        <div class="star star-position5"></div>
        <div class="star star-position6"></div>
        <div class="star star-position7"></div>
      </div>
      <div class="box-of-star3">
        <div class="star star-position1"></div>
        <div class="star star-position2"></div>
        <div class="star star-position3"></div>
        <div class="star star-position4"></div>
        <div class="star star-position5"></div>
        <div class="star star-position6"></div>
        <div class="star star-position7"></div>
      </div>
      <div class="box-of-star4">
        <div class="star star-position1"></div>
        <div class="star star-position2"></div>
        <div class="star star-position3"></div>
        <div class="star star-position4"></div>
        <div class="star star-position5"></div>
        <div class="star star-position6"></div>
        <div class="star star-position7"></div>
      </div>
      <div data-js="astro" class="astronaut">
        <div class="head"></div>
        <div class="arm arm-left"></div>
        <div class="arm arm-right"></div>
        <div class="body">
          <div class="panel"></div>
        </div>
        <div class="leg leg-left"></div>
        <div class="leg leg-right"></div>
        <div class="schoolbag"></div>
      </div>



      
    <!--<svg class="gegga">
        <defs>
            <filter id="gegga">
                <feGaussianBlur in="SourceGraphic" stdDeviation="7" result="blur"></feGaussianBlur>
                <feColorMatrix in="blur" mode="matrix" values="1 0 0 0 0 0 1 0 0 0 0 0 1 0 0 0 0 0 20 -10" result="inreGegga"></feColorMatrix>
                <feComposite in="SourceGraphic" in2="inreGegga" operator="atop"></feComposite>
            </filter>
        </defs>
    </svg>
    <svg class="snurra" width="200" height="200" viewBox="0 0 200 200">
        <defs>
            <linearGradient id="linjärGradient">
                <stop class="stopp1" offset="0"></stop>
                <stop class="stopp2" offset="1"></stop>
            </linearGradient>
            <linearGradient y2="160" x2="160" y1="40" x1="40" gradientUnits="userSpaceOnUse" id="gradient" xlink:href="#linjärGradient"></linearGradient>
        </defs>
        <path class="halvan" d="m 164,100 c 0,-35.346224 -28.65378,-64 -64,-64 -35.346224,0 -64,28.653776 -64,64 0,35.34622 28.653776,64 64,64 35.34622,0 64,-26.21502 64,-64 0,-37.784981 -26.92058,-64 -64,-64 -37.079421,0 -65.267479,26.922736 -64,64 1.267479,37.07726 26.703171,65.05317 64,64 37.29683,-1.05317 64,-64 64,-64"></path>
        <circle class="strecken" cx="100" cy="100" r="64"></circle>
    </svg>
    <svg class="skugga" width="200" height="200" viewBox="0 0 200 200">
        <path class="halvan" d="m 164,100 c 0,-35.346224 -28.65378,-64 -64,-64 -35.346224,0 -64,28.653776 -64,64 0,35.34622 28.653776,64 64,64 35.34622,0 64,-26.21502 64,-64 0,-37.784981 -26.92058,-64 -64,-64 -37.079421,0 -65.267479,26.922736 -64,64 1.267479,37.07726 26.703171,65.05317 64,64 37.29683,-1.05317 64,-64 64,-64"></path>
        <circle class="strecken" cx="100" cy="100" r="64"></circle>
    </svg>
-->

    <div class="special1-1">
        <div class="special1-2"></div>
        <div class="special1-3"></div>
        <div class="special1-4"></div>
      </div>


      <div class="sphere">
        <div class="dott"></div>
        <div class="dott"></div>
        <div class="dott"></div>
      </div>


      <div class="spinners">
        <div class="spinnersin"></div>
    </div>
      

    <div class="spinners1"></div>

    <div class="squarer">
        <div class="cell d-0"></div>
        <div class="cell d-1"></div>
        <div class="cell d-2"></div>
      
        <div class="cell d-1"></div>
        <div class="cell d-2"></div>
        
        
        <div class="cell d-2"></div>
        <div class="cell d-3"></div>
        
        
        <div class="cell d-3"></div>
        <div class="cell d-4"></div>
        
        
      </div>


      <div class="squarer1">
        <div class="cubess">
          <div class="face1"></div>
          <div class="face2"></div>
          <div class="face3"></div>
          <div class="face4"></div>
          <div class="face5"></div>
          <div class="face6"></div>
        </div>
      </div>



      <div class="statistics">
    <div class="statistics__bar"></div>
    <div class="statistics__bar"></div>
    <div class="statistics__bar"></div>
    <div class="statistics__bar"></div>
    <div class="statistics__bar"></div>
    <div class="statistics__ball"></div>
  </div>


  <svg class="pl" viewBox="0 0 128 128" width="128px" height="128px" xmlns="http://www.w3.org/2000/svg">
        <defs>
            <linearGradient id="pl-grad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stop-color="hsl(193,90%,55%)"></stop>
                <stop offset="100%" stop-color="hsl(223,90%,55%)"></stop>
            </linearGradient>
        </defs>
        <circle class="pl__ring" r="56" cx="64" cy="64" fill="none" stroke="hsla(0,10%,10%,0.1)" stroke-width="16" stroke-linecap="round"></circle>
        <path class="pl__worm" d="M92,15.492S78.194,4.967,66.743,16.887c-17.231,17.938-28.26,96.974-28.26,96.974L119.85,59.892l-99-31.588,57.528,89.832L97.8,19.349,13.636,88.51l89.012,16.015S81.908,38.332,66.1,22.337C50.114,6.156,36,15.492,36,15.492a56,56,0,1,0,56,0Z" fill="none" stroke="url(#pl-grad)" stroke-width="16" stroke-linecap="round" stroke-linejoin="round" stroke-dasharray="44 1111" stroke-dashoffset="10"></path>
    </svg>
    

    <svg viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg" class="system">
        <g class="dash">
          <path style="--sped: 4s;" pathLength="360" d="M 31.9463 1 C 15.6331 1 2.2692 13.6936 1 29.8237 L 17.644 36.7682 C 19.0539 35.794 20.7587 35.2264 22.5909 35.2264 C 22.7563 35.2264 22.9194 35.231 23.0803 35.2399 L 30.4828 24.412 L 30.4828 24.2601 C 30.4828 17.7446 35.7359 12.4423 42.1933 12.4423 C 48.6507 12.4423 53.9038 17.7446 53.9038 24.2601 C 53.9038 30.7756 48.6507 36.08 42.1933 36.08 C 42.104 36.08 42.0168 36.0778 41.9275 36.0755 L 31.3699 43.6747 C 31.3766 43.8155 31.3811 43.9562 31.3811 44.0947 C 31.3811 48.9881 27.4374 52.9675 22.5909 52.9675 C 18.3367 52.9675 14.7773 49.902 13.9729 45.8443 L 2.068 40.8772 C 5.7548 54.0311 17.7312 63.6748 31.9463 63.6748 C 49.0976 63.6748 63 49.6428 63 32.3374 C 63 15.0297 49.0976 1 31.9463 1 Z" class="big"></path>
          <path pathLength="360" d="M 20.4603 48.5493 L 16.6461 46.9584 C 17.3209 48.3794 18.4917 49.5682 20.0447 50.2206 C 23.4007 51.6328 27.2707 50.0262 28.6694 46.6367 C 29.3464 44.9966 29.3509 43.1867 28.6806 41.5422 C 28.0103 39.8977 26.7434 38.6151 25.119 37.9315 C 23.5035 37.2544 21.7741 37.279 20.2547 37.8576 L 24.1961 39.5022 C 26.6719 40.5434 27.8427 43.4124 26.8104 45.9105 C 25.7803 48.4085 22.936 49.5905 20.4603 48.5493 Z" class="aaa"></path>
          <path pathLength="360" d="M 49.9968 24.2603 C 49.9968 19.9188 46.4954 16.384 42.1943 16.384 C 37.8908 16.384 34.3894 19.9188 34.3894 24.2603 C 34.3894 28.6017 37.8908 32.1343 42.1943 32.1343 C 46.4954 32.1343 49.9968 28.6017 49.9968 24.2603 Z"></path>
          <path pathLength="360" d="M 36.3446 24.2469 C 36.3446 20.9802 38.97 18.3324 42.2054 18.3324 C 45.4431 18.3324 48.0685 20.9802 48.0685 24.2469 C 48.0685 27.5135 45.4431 30.1613 42.2054 30.1613 C 38.97 30.1613 36.3446 27.5135 36.3446 24.2469 Z"></path>
        </g>
        <path pathLength="360" d="M 31.9463 1 C 15.6331 1 2.2692 13.6936 1 29.8237 L 17.644 36.7682 C 19.0539 35.794 20.7587 35.2264 22.5909 35.2264 C 22.7563 35.2264 22.9194 35.231 23.0803 35.2399 L 30.4828 24.412 L 30.4828 24.2601 C 30.4828 17.7446 35.7359 12.4423 42.1933 12.4423 C 48.6507 12.4423 53.9038 17.7446 53.9038 24.2601 C 53.9038 30.7756 48.6507 36.08 42.1933 36.08 C 42.104 36.08 42.0168 36.0778 41.9275 36.0755 L 31.3699 43.6747 C 31.3766 43.8155 31.3811 43.9562 31.3811 44.0947 C 31.3811 48.9881 27.4374 52.9675 22.5909 52.9675 C 18.3367 52.9675 14.7773 49.902 13.9729 45.8443 L 2.068 40.8772 C 5.7548 54.0311 17.7312 63.6748 31.9463 63.6748 C 49.0976 63.6748 63 49.6428 63 32.3374 C 63 15.0297 49.0976 1 31.9463 1 Z" fill="#212121"></path>
        <path class="fill" pathLength="360" d="M 31.9463 1 C 15.6331 1 2.2692 13.6936 1 29.8237 L 17.644 36.7682 C 19.0539 35.794 20.7587 35.2264 22.5909 35.2264 C 22.7563 35.2264 22.9194 35.231 23.0803 35.2399 L 30.4828 24.412 L 30.4828 24.2601 C 30.4828 17.7446 35.7359 12.4423 42.1933 12.4423 C 48.6507 12.4423 53.9038 17.7446 53.9038 24.2601 C 53.9038 30.7756 48.6507 36.08 42.1933 36.08 C 42.104 36.08 42.0168 36.0778 41.9275 36.0755 L 31.3699 43.6747 C 31.3766 43.8155 31.3811 43.9562 31.3811 44.0947 C 31.3811 48.9881 27.4374 52.9675 22.5909 52.9675 C 18.3367 52.9675 14.7773 49.902 13.9729 45.8443 L 2.068 40.8772 C 5.7548 54.0311 17.7312 63.6748 31.9463 63.6748 C 49.0976 63.6748 63 49.6428 63 32.3374 C 63 15.0297 49.0976 1 31.9463 1 Z"></path>
      </svg>


      <section class="tube">

<div class="slidetube" style="--i:0">
</div>
<div class="slidetube" style="--i:1">
</div>
<div class="slidetube" style="--i:2">
</div>
<div class="slidetube" style="--i:3">
</div>
<div class="slidetube" style="--i:4">
</div>
</section>



<div class="waves">
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
    </div>


    <div class="spring">
        <div class="itemg" style="--i:0;"></div>
        <div class="itemg" style="--i:1;"></div>
        <div class="itemg" style="--i:2;"></div>
        <div class="itemg" style="--i:3;"></div>
        <div class="itemg" style="--i:4;"></div>
        <div class="itemg" style="--i:5;"></div>
        <div class="itemg" style="--i:6;"></div>
        <div class="itemg" style="--i:7;"></div>
        <div class="itemg" style="--i:8;"></div>
        <div class="itemg" style="--i:9;"></div>
        <div class="itemg" style="--i:10;"></div>
        <div class="itemg" style="--i:11;"></div>
        <div class="itemg" style="--i:12;"></div>
        <div class="itemg" style="--i:13;"></div>
        <div class="itemg" style="--i:14;"></div>
        <div class="itemg" style="--i:15;"></div>
        <div class="itemg" style="--i:16;"></div>
        <div class="itemg" style="--i:17;"></div>
        <div class="itemg" style="--i:18;"></div>
        <div class="itemg" style="--i:19;"></div>
        <div class="itemg" style="--i:20;"></div>
      </div>



      <div class="whiter"></div>


      <!--<div class="you">
        <svg height="0" width="0" viewBox="0 0 64 64" class="absolute">
          <defs class="s-xJBuHA073rTt" xmlns="http://www.w3.org/2000/svg">
            <linearGradient class="s-xJBuHA073rTt" gradientUnits="userSpaceOnUse" y2="2" x2="0" y1="62" x1="0" id="b">
              <stop class="s-xJBuHA073rTt" stop-color="#973BED"></stop>
              <stop class="s-xJBuHA073rTt" stop-color="#007CFF" offset="1"></stop>
            </linearGradient>
            <linearGradient class="s-xJBuHA073rTt" gradientUnits="userSpaceOnUse" y2="0" x2="0" y1="64" x1="0" id="c">
              <stop class="s-xJBuHA073rTt" stop-color="#FFC800"></stop>
              <stop class="s-xJBuHA073rTt" stop-color="#F0F" offset="1"></stop>
              <animateTransform repeatCount="indefinite" keySplines=".42,0,.58,1;.42,0,.58,1;.42,0,.58,1;.42,0,.58,1;.42,0,.58,1;.42,0,.58,1;.42,0,.58,1;.42,0,.58,1" keyTimes="0; 0.125; 0.25; 0.375; 0.5; 0.625; 0.75; 0.875; 1" dur="8s" values="0 32 32;-270 32 32;-270 32 32;-540 32 32;-540 32 32;-810 32 32;-810 32 32;-1080 32 32;-1080 32 32" type="rotate" attributeName="gradientTransform"></animateTransform>
            </linearGradient>
            <linearGradient class="s-xJBuHA073rTt" gradientUnits="userSpaceOnUse" y2="2" x2="0" y1="62" x1="0" id="d">
              <stop class="s-xJBuHA073rTt" stop-color="#00E0ED"></stop>
              <stop class="s-xJBuHA073rTt" stop-color="#00DA72" offset="1"></stop>
            </linearGradient>
          </defs>
        </svg>
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 64 64" height="64" width="64" class="inline-block">
          <path stroke-linejoin="round" stroke-linecap="round" stroke-width="8" stroke="url(#b)" d="M 54.722656,3.9726563 A 2.0002,2.0002 0 0 0 54.941406,4 h 5.007813 C 58.955121,17.046124 49.099667,27.677057 36.121094,29.580078 a 2.0002,2.0002 0 0 0 -1.708985,1.978516 V 60 H 29.587891 V 31.558594 A 2.0002,2.0002 0 0 0 27.878906,29.580078 C 14.900333,27.677057 5.0448787,17.046124 4.0507812,4 H 9.28125 c 1.231666,11.63657 10.984383,20.554048 22.6875,20.734375 a 2.0002,2.0002 0 0 0 0.02344,0 c 11.806958,0.04283 21.70649,-9.003371 22.730469,-20.7617187 z" class="dashu" id="y" pathLength="360"></path>
        </svg>
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" style="--rotation-duration:0ms; --rotation-direction:normal;" viewBox="0 0 64 64" height="64" width="64" class="inline-block">
          <path stroke-linejoin="round" stroke-linecap="round" stroke-width="10" stroke="url(#c)" d="M 32 32
              m 0 -27
              a 27 27 0 1 1 0 54
              a 27 27 0 1 1 0 -54" class="spinu" id="o" pathLength="360"></path>
        </svg>
        <div class="w-2"></div>
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" style="--rotation-duration:0ms; --rotation-direction:normal;" viewBox="0 0 64 64" height="64" width="64" class="inline-block">
          <path stroke-linejoin="round" stroke-linecap="round" stroke-width="8" stroke="url(#d)" d="M 4,4 h 4.6230469 v 25.919922 c -0.00276,11.916203 9.8364941,21.550422 21.7500001,21.296875 11.616666,-0.240651 21.014356,-9.63894 21.253906,-21.25586 a 2.0002,2.0002 0 0 0 0,-0.04102 V 4 H 56.25 v 25.919922 c 0,14.33873 -11.581192,25.919922 -25.919922,25.919922 a 2.0002,2.0002 0 0 0 -0.0293,0 C 15.812309,56.052941 3.998433,44.409961 4,29.919922 Z" class="dashu" id="u" pathLength="360"></path>
        </svg>
      </div>-->

    <?php
include 'partials/footer.php';

?>

</html>