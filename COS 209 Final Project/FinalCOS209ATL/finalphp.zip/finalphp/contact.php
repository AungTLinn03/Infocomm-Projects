<!DOCTYPE html>

<head>
    <style>

        /*artgalllery*/
        


        .box{
  
    width: 200px;
    height: 200px;
    transform-style: preserve-3d;
    animation: animate 20s linear infinite;
    display: flex;
    justify-content: center;
    align-items: center;
  left:40%;
bottom:35%;
   margin-top:-40%;
   position: absolute;
   
}
@keyframes animate {
                0%{
                    transform: perspective(1000px) rotateX(0deg) rotateY(35deg);
                }
                100%{
                    transform: perspective(1000px) rotateX(360deg) rotateY(35deg);
                }
}
.box span{
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    transform-origin: center;
    transform-style: preserve-3d;
    transform: rotateX(calc(var(--i) * 45deg)) translateZ(300px) ;

}
.box span img {
    position: absolute;
    top: 0 ;
    left: 0;
    width: 100%;
    height: 100%;
    object-fit: cover;
}


/*another art */



</style>
        </head>




<?php
include 'partials/header.php';

?>

    <section class="empty_page">
     
    </section>

    <div class="box">
    <span style="--i:1;"><img src= "../finalphp/imagess/SRK1.jpg"></span>
    <span style="--i:2;"><img src= "../finalphp/imagess/Afghan.jpg"></span>
    <span style="--i:3;"><img src= "../finalphp/imagess/realart.jpg"></span>
    <span style="--i:4;"><img src= "../finalphp/imagess/mafia1.jpg"></span>
    <span style="--i:5;"><img src= "../finalphp/imagess/modernart.jpeg"></span>
    <span style="--i:6;"><img src= "../finalphp/imagess/messi.jpg"></span>
    <span style="--i:7;"><img src= "../finalphp/imagess/oldbeard.jpg"></span>
    <span style="--i:8;"><img src= "../finalphp/imagess/tateism.jpg"></span>
   </div>




  <?php
include 'partials/footer.php';

?>

</html>
   