<!DOCTYPE html>

<head>
    <style>
        


        
        .cmmin{
            position: absolute;
            width: 300px;
            height: 300px;
           left:0%;
           align-items:center;
        


        }
        .cmmin::before {
            position: absolute;
            content: "";
            width: 50px;
            height: 10px;
            left: 50%;
            top: 100%;
            transform: translateX(-50%);
            background: #555;
            border-radius: 50%;
            animation: shadow-animate 1s infinite;
        }
        .cmmin .ball {
            position: relative;
            margin: 0 auto;
            width: 50px;
            height: 50px;
            top: 0;
            background: #5cff5c;
            border-radius: 50%;
            box-shadow: 0 0 10px #5cff5c, 0 0 30px #5cff5c;
            animation: ball-animate 1s infinite;
        }
        @keyframes ball-animate {
            5% {
                width: 50px;
                height: 50px;
            }
            20% {
                height: 60px;
            }
            30% {
                width: 45px;
                height: 60px;
            }
            50% {
                width: 57px;
                height: 35px;
                transform: translateY(275px);
            }
            75% {
                width: 50px;
                height: 50px;
            }
        }
        @keyframes shadow-animate {
            25% {
                width: 50px;
                height: 10px;
            }
            50% {
                width: 57px;
                height: 10px;
            }
            75% {
                width: 50px;
                height: 10px;
            }
        }


/*greencube*/
        .cube-loader {
            
            margin-top:10%;
            margin-left:47.5%;
            position:relative;
            width:75px;
/* u can choose any size */
  width: 75px;
  height: 75px;
  -webkit-transform-style: preserve-3d;
          transform-style: preserve-3d;
  -webkit-transform: rotateX(-30deg);
          transform: rotateX(-30deg);
  -webkit-animation: animate 4s linear infinite;
          animation: animate 4s linear infinite;
}

@-webkit-keyframes animate {
  0% {
    -webkit-transform: rotateX(-30deg) rotateY(0);
            transform: rotateX(-30deg) rotateY(0);
  }

  100% {
    -webkit-transform: rotateX(-30deg) rotateY(360deg);
            transform: rotateX(-30deg) rotateY(360deg);
  }
}

@keyframes animate {
  0% {
    -webkit-transform: rotateX(-30deg) rotateY(0);
            transform: rotateX(-30deg) rotateY(0);
  }

  100% {
    -webkit-transform: rotateX(-30deg) rotateY(360deg);
            transform: rotateX(-30deg) rotateY(360deg);
  }
}

.cube-loader .cube-wrapper {
  position: absolute;
  width: 100%;
  height: 100%;
  /* top: 0;
  left: 0; */
  -webkit-transform-style: preserve-3d;
          transform-style: preserve-3d;
}

.cube-loader .cube-wrapper .cube-span {
  position: absolute;
  width: 100%;
  height: 100%;
  /* top: 0;
  left: 0; */
                                     /* width 75px / 2 = 37.5px */
  -webkit-transform: rotateY(calc(90deg * var(--i))) translateZ(37.5px);
          transform: rotateY(calc(90deg * var(--i))) translateZ(37.5px);
  background: -webkit-gradient(
    linear,
    left top, left bottom,
    from(hsl(330, 3.13%, 25.1%)),
    color-stop(5.5%, hsl(177.27, 21.71%, 32.06%)),
    color-stop(12.1%, hsl(176.67, 34.1%, 36.88%)),
    color-stop(19.6%, hsl(176.61, 42.28%, 40.7%)),
    color-stop(27.9%, hsl(176.63, 48.32%, 43.88%)),
    color-stop(36.6%, hsl(176.66, 53.07%, 46.58%)),
    color-stop(45.6%, hsl(176.7, 56.94%, 48.91%)),
    color-stop(54.6%, hsl(176.74, 62.39%, 50.91%)),
    color-stop(63.4%, hsl(176.77, 69.86%, 52.62%)),
    color-stop(71.7%, hsl(176.8, 76.78%, 54.08%)),
    color-stop(79.4%, hsl(176.83, 83.02%, 55.29%)),
    color-stop(86.2%, hsl(176.85, 88.44%, 56.28%)),
    color-stop(91.9%, hsl(176.86, 92.9%, 57.04%)),
    color-stop(96.3%, hsl(176.88, 96.24%, 57.59%)),
    color-stop(99%, hsl(176.88, 98.34%, 57.93%)),
    to(hsl(176.89, 99.07%, 58.04%))
  );
  background: linear-gradient(
    to bottom,
    hsl(330, 3.13%, 25.1%) 0%,
    hsl(177.27, 21.71%, 32.06%) 5.5%,
    hsl(176.67, 34.1%, 36.88%) 12.1%,
    hsl(176.61, 42.28%, 40.7%) 19.6%,
    hsl(176.63, 48.32%, 43.88%) 27.9%,
    hsl(176.66, 53.07%, 46.58%) 36.6%,
    hsl(176.7, 56.94%, 48.91%) 45.6%,
    hsl(176.74, 62.39%, 50.91%) 54.6%,
    hsl(176.77, 69.86%, 52.62%) 63.4%,
    hsl(176.8, 76.78%, 54.08%) 71.7%,
    hsl(176.83, 83.02%, 55.29%) 79.4%,
    hsl(176.85, 88.44%, 56.28%) 86.2%,
    hsl(176.86, 92.9%, 57.04%) 91.9%,
    hsl(176.88, 96.24%, 57.59%) 96.3%,
    hsl(176.88, 98.34%, 57.93%) 99%,
    hsl(176.89, 99.07%, 58.04%) 100%
  );
}

.cube-top {
  position: absolute;
  width: 75px;
  height: 75px;
  background: hsl(330, 3.13%, 25.1%) 0%;
                      /* width 75px / 2 = 37.5px */
  -webkit-transform: rotateX(90deg) translateZ(37.5px);
          transform: rotateX(90deg) translateZ(37.5px);
  -webkit-transform-style: preserve-3d;
          transform-style: preserve-3d;
}

.cube-top::before {
  content: '';
  position: absolute;
/* u can choose any size */
  width: 75px;
  height: 75px;
  background: hsl(176.61, 42.28%, 40.7%) 19.6%;
  -webkit-transform: translateZ(-90px);
          transform: translateZ(-90px);
  -webkit-filter: blur(10px);
          filter: blur(10px);
  -webkit-box-shadow: 0 0 10px #323232,
              0 0 20px hsl(176.61, 42.28%, 40.7%) 19.6%,
              0 0 30px #323232,
              0 0 40px hsl(176.61, 42.28%, 40.7%) 19.6%;
          box-shadow: 0 0 10px #323232,
              0 0 20px hsl(176.61, 42.28%, 40.7%) 19.6%,
              0 0 30px #323232,
              0 0 40px hsl(176.61, 42.28%, 40.7%) 19.6%;
}



/*balling*/
.ckar-center {
  position: absolute;
  top: 50%;
  left: 0;
  z-index: 10;
  -webkit-transform: translateY(-50%);
      -ms-transform: translateY(-50%);
          transform: translateY(-50%);
  width: 100%;
  margin: 0 auto;
  text-align: center;
  -webkit-transition: all 500ms linear;
  transition: all 500ms linear;
  display: flex;
            align-items: center;
            justify-content: center;
            position:absolute;
            bottom:-30%;
            left:10%;
}

.ckar-path {
  position: relative;
  width: 238px;
  height: 76px;
  border-radius: 35px;
  margin: 0 auto;
  text-align: center;
  background-color: #e6e6e6;
  -webkit-box-shadow: inset -2px 20px 10px 0 rgba(0,0,0,.06),
		inset -2px 30px 10px 0 rgba(0,0,0,.04);
          box-shadow: inset -2px 20px 10px 0 rgba(0,0,0,.06),
		inset -2px 30px 10px 0 rgba(0,0,0,.04);
  border: 3px groove rgba(225,225,225,0.07);
  overflow: hidden;
  -webkit-transition: all 300ms linear;
  transition: all 300ms linear;
}

.globe {
  position: relative;
  width: 66px;
  height: 66px;
  overflow: hidden;
  margin-top: 2px;
  margin-left: 2px;
  border-radius: 50%;
  -webkit-box-shadow: 0 10px 40px rgba(0,0,0,0.65);
          box-shadow: 0 10px 40px rgba(0,0,0,0.65);
  -webkit-animation: rotateBall 4s ease infinite;
          animation: rotateBall 4s ease infinite;
  -webkit-transition: all 300ms linear;
  transition: all 300ms linear;
}

@-webkit-keyframes rotateBall {
  0% {
    -webkit-transform: translateX(0);
            transform: translateX(0);
  }

  50% {
    -webkit-transform: translateX(162px);
            transform: translateX(162px);
  }

  100% {
    -webkit-transform: translateX(0);
            transform: translateX(0);
  }
}

@keyframes rotateBall {
  0% {
    -webkit-transform: translateX(0);
            transform: translateX(0);
  }

  50% {
    -webkit-transform: translateX(162px);
            transform: translateX(162px);
  }

  100% {
    -webkit-transform: translateX(0);
            transform: translateX(0);
  }
}

.globe:after {
  position: absolute;
  width: 5px;
  height: 12px;
  background-color: rgba(255, 255, 255, 0.1);
  content: '';
  left: 40px;
  top: 15px;
  border-radius: 50%;
  z-index: 2;
  -webkit-box-shadow: 0 0 14px 7px rgba(255, 255, 255, 0.1);
          box-shadow: 0 0 14px 7px rgba(255, 255, 255, 0.1);
}

.globe:before {
  position: absolute;
  width: 100%;
  height: 100%;
  content: '';
  left: 0;
  top: 0;
  border-radius: 50%;
  z-index: 1;
  -webkit-box-shadow: inset 0 0 15px #1a252f;
          box-shadow: inset 0 0 15px #1a252f;
  opacity: 0.4;
  -webkit-transition: all 300ms linear;
  transition: all 300ms linear;
}

.globe .wrapper {
  position: absolute;
  width: 528px;
  height: 528px;
  top: 0;
  left: -462px;
  -webkit-animation: moveBall 4s ease infinite;
          animation: moveBall 4s ease infinite;
}

@-webkit-keyframes moveBall {
  0% {
    left: -462px;
  }

  50% {
    left: 0;
  }

  100% {
    left: -462px;
  }
}

@keyframes moveBall {
  0% {
    left: -462px;
  }

  50% {
    left: 0;
  }

  100% {
    left: -462px;
  }
}

.globe .wrapper span {
  position: absolute;
  width: 33px;
  height: 528px;
  top: 0;
  left: 0;
  background-color: cyan;
  -webkit-box-shadow: inset 0 0 25px #5c487c;
          box-shadow: inset 0 0 25px #5c487c;
}

.globe .wrapper span:nth-child(2) {
  left: 33px;
  background-color: white;
}

.globe .wrapper span:nth-child(3) {
  left: 66px;
}

.globe .wrapper span:nth-child(4) {
  left: 99px;
  background-color: white;
}

.globe .wrapper span:nth-child(5) {
  left: 132px;
}

.globe .wrapper span:nth-child(6) {
  left: 165px;
  background-color: white;
}

.globe .wrapper span:nth-child(7) {
  left: 198px;
}

.globe .wrapper span:nth-child(8) {
  left: 231px;
  background-color: white;
}

.globe .wrapper span:nth-child(9) {
  left: 264px;
}

.globe .wrapper span:nth-child(10) {
  left: 297px;
  background-color: palevioletred;
}

.globe .wrapper span:nth-child(11) {
  left: 330px;
}

.globe .wrapper span:nth-child(12) {
  left: 363px;
  background-color: palevioletred;
}

.globe .wrapper span:nth-child(13) {
  left: 396px;
}

.globe .wrapper span:nth-child(14) {
  left: 429px;
  background-color: palevioletred;
}

.globe .wrapper span:nth-child(15) {
  left: 462px;
}

.globe .wrapper span:nth-child(16) {
  left: 495px;
  background-color: palevioletred;
}

#switch,
#circle {
  cursor: pointer;
  -webkit-transition: all 300ms linear;
  transition: all 300ms linear;
}

#switch {
  width: 70px;
  height: 8px;
  margin: 0 auto;
  text-align: center;
  border: 2px solid white;
  border-radius: 27px;
  background: #000;
  position: relative;
  display: inline-block;
  margin-top: 40px;
  margin-bottom: 20px;
}

#circle {
  position: absolute;
  top: -11px;
  left: 5px;
  width: 26px;
  height: 26px;
  border-radius: 50%;
  -webkit-box-shadow: 0 4px 4px rgba(0,0,0,0.25), 0 0 0 1px rgba(26,53,71,0.07);
          box-shadow: 0 4px 4px rgba(0,0,0,0.25), 0 0 0 1px rgba(26,53,71,0.07);
  background: #000;
}

.switched {
  border-color: #000 !important;
  background: #8167a9 !important;
}

.switched #circle {
  left: 35px;
  background: #fff;
}

.ckar-center p span {
  position: relative;
  padding: 4px 10px;
  margin: 0 5px;
}

.ckar-center p span:before {
  position: absolute;
  content: '';
  width: 100%;
  height: 100%;
  border-radius: 4px;
  background-color: #8167a9;
  -webkit-box-shadow: 0 2px 4px rgba(0,0,0,0.25);
          box-shadow: 0 2px 4px rgba(0,0,0,0.25);
  left: 0;
  top: 0;
  z-index: -1;
  -webkit-transition: all 300ms linear;
  transition: all 300ms linear;
}

.ckar-center p span:after {
  position: absolute;
  content: '';
  width: calc(100% - 10px);
  height: 2px;
  border-radius: 4px;
  background-color: #fff;
  left: 5px;
  top: 50%;
  z-index: 1;
  -webkit-transition: all 300ms linear;
  transition: all 300ms linear;
}

.ckar-center p span:nth-child(2):after {
  opacity: 0;
}


/*barball*/

.silicon{
position: absolute;
  width: 120px;
  height: 90px;
  margin-left:85%;
  bottom:-30%;
  
}

.silicon:before {
  content: "";
  position: absolute;
  bottom: 30px;
  left: 50px;
  height: 30px;
  width: 30px;
  border-radius: 50%;
  background:fuchsia ;
  -webkit-animation: loading-bounce 0.5s ease-in-out infinite alternate;
          animation: loading-bounce 0.5s ease-in-out infinite alternate;
}

.silicon:after {
  content: "";
  position: absolute;
  right: 0;
  top: 0;
  height: 7px;
  width: 45px;
  border-radius: 4px;
  -webkit-box-shadow: 0 5px 0 lawngreen, -35px 50px 0 lawngreen, -70px 95px 0 lawngreen;
          box-shadow: 0 5px 0 lawngreen, -35px 50px 0 lawngreen, -70px 95px 0 lawngreen;
  -webkit-animation: loading-step 1s ease-in-out infinite;
          animation: loading-step 1s ease-in-out infinite;
}

@-webkit-keyframes loading-bounce {
  0% {
    -webkit-transform: scale(1, 0.7);
            transform: scale(1, 0.7);
  }

  40% {
    -webkit-transform: scale(0.8, 1.2);
            transform: scale(0.8, 1.2);
  }

  60% {
    -webkit-transform: scale(1, 1);
            transform: scale(1, 1);
  }

  100% {
    bottom: 140px;
  }
}

@keyframes loading-bounce {
  0% {
    -webkit-transform: scale(1, 0.7);
            transform: scale(1, 0.7);
  }

  40% {
    -webkit-transform: scale(0.8, 1.2);
            transform: scale(0.8, 1.2);
  }

  60% {
    -webkit-transform: scale(1, 1);
            transform: scale(1, 1);
  }

  100% {
    bottom: 140px;
  }
}

@-webkit-keyframes loading-step {
  0% {
    -webkit-box-shadow: 0 10px 0 rgba(0, 0, 0, 0),
            0 10px 0 Deepskyblue,
            -35px 50px 0 Deepskyblue,
            -70px 90px 0 Deepskyblue;
            box-shadow: 0 10px 0 rgba(0, 0, 0, 0),
            0 10px 0 Deepskyblue,
            -35px 50px 0 Deepskyblue,
            -70px 90px 0 Deepskyblue;
  }

  100% {
    -webkit-box-shadow: 0 10px 0 Deepskyblue,
            -35px 50px 0 Deepskyblue,
            -70px 90px 0 Deepskyblue,
            -70px 90px 0 rgba(0, 0, 0, 0);
            box-shadow: 0 10px 0 Deepskyblue,
            -35px 50px 0 Deepskyblue,
            -70px 90px 0 Deepskyblue,
            -70px 90px 0 rgba(0, 0, 0, 0);
  }
}

@keyframes loading-step {
  0% {
    -webkit-box-shadow: 0 10px 0 rgba(0, 0, 0, 0),
            0 10px 0 Deepskyblue,
            -35px 50px 0 Deepskyblue,
            -70px 90px 0 Deepskyblue;
            box-shadow: 0 10px 0 rgba(0, 0, 0, 0),
            0 10px 0 Deepskyblue,
            -35px 50px 0 Deepskyblue,
            -70px 90px 0 Deepskyblue;
  }

  100% {
    -webkit-box-shadow: 0 10px 0 Deepskyblue,
            -35px 50px 0 Deepskyblue,
            -70px 90px 0 Deepskyblue,
            -70px 90px 0 rgba(0, 0, 0, 0);
            box-shadow: 0 10px 0 Deepskyblue,
            -35px 50px 0 Deepskyblue,
            -70px 90px 0 Deepskyblue,
            -70px 90px 0 rgba(0, 0, 0, 0);
  }
}


/*bouncing ball*/

.ball {
 position: absolute;
 height: 15px;
 width: 15px;
 background-color: rgb(255, 44, 44);
 border-radius: 50%;
 -webkit-animation: bounce 0.5s ease-in-out infinite both;
         animation: bounce 0.5s ease-in-out infinite both;
         
       margin-left:5%;
       bottom:-50%;
}

@-webkit-keyframes bounce {
 0%, 100% {
  -webkit-transform: translate(0px, 0px);
          transform: translate(0px, 0px);
 }

 50% {
  -webkit-transform: translate(0px, 50px) scale(1, 0.77);
          transform: translate(0px, 50px) scale(1, 0.77);
 }
}

@keyframes bounce {
 0%, 100% {
  -webkit-transform: translate(0px, 0px);
          transform: translate(0px, 0px);
 }

 50% {
  -webkit-transform: translate(0px, 50px) scale(1, 0.77);
          transform: translate(0px, 50px) scale(1, 0.77);
 }
}


/*breakbar*/
.sitiner {
  position: absolute;
  top: 20%;
  left: 50%;
  -webkit-transform: translate(-50%, -50%);
      -ms-transform: translate(-50%, -50%);
          transform: translate(-50%, -50%);
  display: -webkit-box;
  display: -ms-flexbox;
  display: flex;
            align-items: center;
            justify-content: center;
          
            
}

.dash {
  margin: 0 15px;
  width: 35px;
  height: 15px;
  border-radius: 8px;
  background: rgb(82, 159, 246);
  -webkit-box-shadow: rgb(82, 159, 246) 0 0 15px 0;
          box-shadow: rgb(82, 159, 246) 0 0 15px 0;
}

.first {
  margin-right: -18px;
  -webkit-transform-origin: center left;
      -ms-transform-origin: center left;
          transform-origin: center left;
  -webkit-animation: spin 3s linear infinite;
          animation: spin 3s linear infinite;  
}

.seconde {
  -webkit-transform-origin: center right;
      -ms-transform-origin: center right;
          transform-origin: center right;
  -webkit-animation: spin2 3s linear infinite;
          animation: spin2 3s linear infinite;
  -webkit-animation-delay: .2s;
          animation-delay: .2s;
}

.third {
  -webkit-transform-origin: center right;
      -ms-transform-origin: center right;
          transform-origin: center right;
  -webkit-animation: spin3 3s linear infinite;
          animation: spin3 3s linear infinite;
  -webkit-animation-delay: .3s;
          animation-delay: .3s;
}

.fourth {
  -webkit-transform-origin: center right;
      -ms-transform-origin: center right;
          transform-origin: center right;
  -webkit-animation: spin4 3s linear infinite;
          animation: spin4 3s linear infinite;
  -webkit-animation-delay: .4s;
          animation-delay: .4s;
}

@-webkit-keyframes spin {
  0% {
    -webkit-transform: rotate(0deg);
            transform: rotate(0deg);
  }
  25% {
    -webkit-transform: rotate(360deg);
            transform: rotate(360deg);
  }
  30% {
    -webkit-transform: rotate(370deg);
            transform: rotate(370deg);
  }
  35% {
    -webkit-transform: rotate(360deg);
            transform: rotate(360deg);
  }
  100% {
    -webkit-transform: rotate(360deg);
            transform: rotate(360deg);
  }
}

@keyframes spin {
  0% {
    -webkit-transform: rotate(0deg);
            transform: rotate(0deg);
  }
  25% {
    -webkit-transform: rotate(360deg);
            transform: rotate(360deg);
  }
  30% {
    -webkit-transform: rotate(370deg);
            transform: rotate(370deg);
  }
  35% {
    -webkit-transform: rotate(360deg);
            transform: rotate(360deg);
  }
  100% {
    -webkit-transform: rotate(360deg);
            transform: rotate(360deg);
  }
}

@-webkit-keyframes spin2 {
  0% {
    -webkit-transform: rotate(0deg);
            transform: rotate(0deg);
  }
  20% {
    -webkit-transform: rotate(0deg);
            transform: rotate(0deg);
  }
  30% {
    -webkit-transform: rotate(-180deg);
            transform: rotate(-180deg);
  }
  35% {
    -webkit-transform: rotate(-190deg);
            transform: rotate(-190deg);
  }
  40% {
    -webkit-transform: rotate(-180deg);
            transform: rotate(-180deg);
  }
  78% {
    -webkit-transform: rotate(-180deg);
            transform: rotate(-180deg);
  }
  95% {
    -webkit-transform: rotate(-360deg);
            transform: rotate(-360deg);
  }
  98% {
    -webkit-transform: rotate(-370deg);
            transform: rotate(-370deg);
  }
  100% {
    -webkit-transform: rotate(-360deg);
            transform: rotate(-360deg);
  }
}

@keyframes spin2 {
  0% {
    -webkit-transform: rotate(0deg);
            transform: rotate(0deg);
  }
  20% {
    -webkit-transform: rotate(0deg);
            transform: rotate(0deg);
  }
  30% {
    -webkit-transform: rotate(-180deg);
            transform: rotate(-180deg);
  }
  35% {
    -webkit-transform: rotate(-190deg);
            transform: rotate(-190deg);
  }
  40% {
    -webkit-transform: rotate(-180deg);
            transform: rotate(-180deg);
  }
  78% {
    -webkit-transform: rotate(-180deg);
            transform: rotate(-180deg);
  }
  95% {
    -webkit-transform: rotate(-360deg);
            transform: rotate(-360deg);
  }
  98% {
    -webkit-transform: rotate(-370deg);
            transform: rotate(-370deg);
  }
  100% {
    -webkit-transform: rotate(-360deg);
            transform: rotate(-360deg);
  }
}

@-webkit-keyframes spin3 {
  0% {
    -webkit-transform: rotate(0deg);
            transform: rotate(0deg);
  }
  27% {
    -webkit-transform: rotate(0deg);
            transform: rotate(0deg);  
  }
  40% {
    -webkit-transform: rotate(180deg);
            transform: rotate(180deg);
  }
  45% {
    -webkit-transform: rotate(190deg);
            transform: rotate(190deg);
  }
  50% {
    -webkit-transform: rotate(180deg);
            transform: rotate(180deg);
  }
  62% {
    -webkit-transform: rotate(180deg);
            transform: rotate(180deg);
  }
  75% {
    -webkit-transform: rotate(360deg);
            transform: rotate(360deg);
  }
  80% {
    -webkit-transform: rotate(370deg);
            transform: rotate(370deg);
  }
  85% {
    -webkit-transform: rotate(360deg);
            transform: rotate(360deg);
  }
  100% {
    -webkit-transform: rotate(360deg);
            transform: rotate(360deg);
  }
}

@keyframes spin3 {
  0% {
    -webkit-transform: rotate(0deg);
            transform: rotate(0deg);
  }
  27% {
    -webkit-transform: rotate(0deg);
            transform: rotate(0deg);  
  }
  40% {
    -webkit-transform: rotate(180deg);
            transform: rotate(180deg);
  }
  45% {
    -webkit-transform: rotate(190deg);
            transform: rotate(190deg);
  }
  50% {
    -webkit-transform: rotate(180deg);
            transform: rotate(180deg);
  }
  62% {
    -webkit-transform: rotate(180deg);
            transform: rotate(180deg);
  }
  75% {
    -webkit-transform: rotate(360deg);
            transform: rotate(360deg);
  }
  80% {
    -webkit-transform: rotate(370deg);
            transform: rotate(370deg);
  }
  85% {
    -webkit-transform: rotate(360deg);
            transform: rotate(360deg);
  }
  100% {
    -webkit-transform: rotate(360deg);
            transform: rotate(360deg);
  }
}

@-webkit-keyframes spin4 {
  0% {
    -webkit-transform: rotate(0deg);
            transform: rotate(0deg);
  }
  38% {
    -webkit-transform: rotate(0deg);
            transform: rotate(0deg);
  }
  60% {
    -webkit-transform: rotate(-360deg);
            transform: rotate(-360deg);
  }
  65% {
    -webkit-transform: rotate(-370deg);
            transform: rotate(-370deg);
  }
  75% {
    -webkit-transform: rotate(-360deg);
            transform: rotate(-360deg);
  }
  100% {
    -webkit-transform: rotate(-360deg);
            transform: rotate(-360deg);
  }
}

@keyframes spin4 {
  0% {
    -webkit-transform: rotate(0deg);
            transform: rotate(0deg);
  }
  38% {
    -webkit-transform: rotate(0deg);
            transform: rotate(0deg);
  }
  60% {
    -webkit-transform: rotate(-360deg);
            transform: rotate(-360deg);
  }
  65% {
    -webkit-transform: rotate(-370deg);
            transform: rotate(-370deg);
  }
  75% {
    -webkit-transform: rotate(-360deg);
            transform: rotate(-360deg);
  }
  100% {
    -webkit-transform: rotate(-360deg);
            transform: rotate(-360deg);
  }
}



/*butterfly*/
.commer {
    --sizeLoader: 60px;
    --sizeLoaderHalf: calc(var(--sizeLoader) / 2);
    --stepBtf: calc(var(--sizeLoader) / 10);

    display:-webkit-box;

    display:-ms-flexbox;

    display:flex;
    position: absolute;
    -webkit-box-orient: horizontal;
    -webkit-box-direction: normal;
        -ms-flex-direction: row;
            flex-direction: row;
    -webkit-box-pack: center;
        -ms-flex-pack: center;
            justify-content: center;
    -webkit-box-align: center;
        -ms-flex-align: center;
            align-items: center;

    width: var(--sizeLoader);
    height: var(--sizeLoader);

    display: flex;
            align-items: center;
            justify-content: center;
           
            left:82%;
            top:20%;
  
          
          
}

.commer:hover{
    cursor: progress;
}

.commer[anim1]{
    -webkit-animation: anim1 0.3s alternate ease-in-out infinite;
            animation: anim1 0.3s alternate ease-in-out infinite;
}

.commer:not([anim1]){
    right: var(--sizeLoaderHalf);
    -webkit-transform-origin: center right;
        -ms-transform-origin: center right;
            transform-origin: center right;
    -webkit-animation: moveAround 2s linear infinite;
            animation: moveAround 2s linear infinite;
}

.commer[showShadow]{
  -webkit-filter: drop-shadow(0 10px 10px #060606de);
          filter: drop-shadow(0 10px 10px #060606de);
}

.commer svg:nth-child(1){
    position: relative;
    height: 100%;
    left: 2%;

    -webkit-transform-origin: center right;

        -ms-transform-origin: center right;

            transform-origin: center right;
    -webkit-animation: wing 0.5s ease-in-out infinite;
            animation: wing 0.5s ease-in-out infinite;

}

.commer svg:nth-child(2){
    height: 50%;
}

.commer svg:nth-child(3){
    position: relative;
    height: 100%;
    left: -2%;

    -webkit-transform-origin: center left;

        -ms-transform-origin: center left;

            transform-origin: center left;
    -webkit-animation: wing 0.5s ease-in-out infinite;
            animation: wing 0.5s ease-in-out infinite;
}

@-webkit-keyframes wing{
    0% {
        -webkit-transform: rotateY(0deg);
                transform: rotateY(0deg);
    }
    50% {
        -webkit-transform: rotateY(60deg);
                transform: rotateY(60deg);
    }
    100% {
        -webkit-transform: rotateY(0deg);
                transform: rotateY(0deg);
    }
}

@keyframes wing{
    0% {
        -webkit-transform: rotateY(0deg);
                transform: rotateY(0deg);
    }
    50% {
        -webkit-transform: rotateY(60deg);
                transform: rotateY(60deg);
    }
    100% {
        -webkit-transform: rotateY(0deg);
                transform: rotateY(0deg);
    }
}

@-webkit-keyframes moveAround{
    0% {
        -webkit-transform: rotate(0deg);
                transform: rotate(0deg);
    }
    100% {
        -webkit-transform: rotate(360deg);
                transform: rotate(360deg);
    }
}

@keyframes moveAround{
    0% {
        -webkit-transform: rotate(0deg);
                transform: rotate(0deg);
    }
    100% {
        -webkit-transform: rotate(360deg);
                transform: rotate(360deg);
    }
}

@-webkit-keyframes anim1{
    from{
      -webkit-transform: translateY(0px);
              transform: translateY(0px);
    }
    to{
      -webkit-transform: translateY(var(--stepBtf));
              transform: translateY(var(--stepBtf));
    }
}

@keyframes anim1{
    from{
      -webkit-transform: translateY(0px);
              transform: translateY(0px);
    }
    to{
      -webkit-transform: translateY(var(--stepBtf));
              transform: translateY(var(--stepBtf));
    }
}
/*circles*/
.circle1{
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100px;
            width: 100px;
            border-radius: 50%;
            border: 3px solid #fe444425;
            border-top: 3px solid red;
            animation: ani 3s linear infinite;
            top:15%;
            left:5%;
            position:absolute;
        }
        .circle2 {
            width: 30px;
            height: 30px;
            border-radius: 50%;
            border: 3px solid #fee84422;
            border-top: 3px solid #f9ce24;
            animation: ani 2s linear infinite;
        }
        @keyframes ani {
            0%{
                transform: rotate(0deg);
            }
            100%{
                transform: rotate(360deg);
            }
        }

        /*collide.html*/
        
        .collide {
  width: 6em;
  height: 6em;
  font-size: 10px;
  position: absolute;
  display: -webkit-box;
  display: -ms-flexbox;
  display: flex;
  -webkit-box-align: center;
      -ms-flex-align: center;
          align-items: center;
  -webkit-box-pack: center;
      -ms-flex-pack: center;
          justify-content: center;
          top:30%;
          left:25%;
          
}

.collide .face {
  position: absolute;
  border-radius: 50%;
  border-style: solid;
  -webkit-animation: animate023845 3s linear infinite;
          animation: animate023845 3s linear infinite;
}

.collide .face:nth-child(1) {
  width: 100%;
  height: 100%;
  color: gold;
  border-color: currentColor transparent transparent currentColor;
  border-width: 0.2em 0.2em 0em 0em;
  --deg: -45deg;
  -webkit-animation-direction: normal;
          animation-direction: normal;
}

.collide .face:nth-child(2) {
  width: 70%;
  height: 70%;
  color: lime;
  border-color: currentColor currentColor transparent transparent;
  border-width: 0.2em 0em 0em 0.2em;
  --deg: -135deg;
  animation-direction: reverse;
}

.collide .face .circle {
  position: absolute;
  width: 50%;
  height: 0.1em;
  top: 50%;
  left: 50%;
  background-color: transparent;
  -webkit-transform: rotate(var(--deg));
      -ms-transform: rotate(var(--deg));
          transform: rotate(var(--deg));
  -webkit-transform-origin: left;
      -ms-transform-origin: left;
          transform-origin: left;
}

.collide .face .circle::before {
  position: absolute;
  top: -0.5em;
  right: -0.5em;
  content: '';
  width: 1em;
  height: 1em;
  background-color: currentColor;
  border-radius: 50%;
  -webkit-box-shadow: 0 0 2em,
                0 0 4em,
                0 0 6em,
                0 0 8em,
                0 0 10em,
                0 0 0 0.5em rgba(255, 255, 0, 0.1);
          box-shadow: 0 0 2em,
                0 0 4em,
                0 0 6em,
                0 0 8em,
                0 0 10em,
                0 0 0 0.5em rgba(255, 255, 0, 0.1);
}

@-webkit-keyframes animate023845 {
  to {
    -webkit-transform: rotate(1turn);
            transform: rotate(1turn);
  }
}

@keyframes animate023845 {
  to {
    -webkit-transform: rotate(1turn);
            transform: rotate(1turn);
  }
}

/*cubedes*/
.cubedescon{
  transform-style: preserve-3d;
  width: 9em;
  height: 9em;
 
  animation: rotate 15s infinite linear;
  perspective: 300px;
  perspective-origin: center center;
  position:absolute;
  bottom:-30%;
  left:15%;
 
}
.sides{
  position: absolute;
  width: 9em;
  height: 9em;
  border-radius: 10%;
  animation: chcol 3s 1s infinite linear;
  transform-style: preserve-3d;
}
.side-1{ transform: translateZ(-50px) rotateY(180deg); }
.side-2{ transform: translateZ(50px); }
.side-3{ transform: translateX(-50px) rotateY(270deg); }
.side-4{ transform: translateX(50px) rotateY(90deg); }
.side-5{ transform: translateY(-50px) rotateX(90deg); }
.side-6{ transform: translateY(50px) rotateX(270deg); }

.sides:before,.sides:after{
  position: absolute;
  content: '';
  display: block;
  left: 0;
  top: 0;
  right: 0;
  bottom: 0;
  margin: auto;
}
.sides:before{
  transform: translateZ(50px);
  width: 50%;
  height: 50%;
  border-radius: 10%;
  outline:2px dotted rgba(255,0,255,.6);
  outline-offset:10px;
  animation: chcol 7s 2s ease infinite;
}
.sides:after{
  transform: translateZ(80px) ;
  width: 25%;
  height: 25%;
  border-radius: 10%;
  animation: chcol 2s 3s ease infinite;
}

@keyframes rotate {
  100% {
    transform: rotateX(360deg) rotateY(-360deg) rotateZ(360deg);
  }
}
@keyframes chcol{
  0%{ 
    box-shadow: inset 0 0 50px #F900F3; 
    border: 1px solid #F900F3;
  }
  25%{ 
    box-shadow: inset 0 0 150px #00B7F7; 
    border: 1px solid #00B7F7;
  }
  75%{ 
    box-shadow: inset 0 0 30px #A000F4; 
    border: 1px solid #A000F4;
  }
  100%{
    box-shadow: none;
    border: 1px solid transparent;
    content: none;
  }
}

/*dancings*/
.dancer {
  width: 60px;
  height: 60px;
 position:absolute;
  border-radius: 10%;
  -webkit-animation: dice3 7s ease-in-out infinite;
          animation: dice3 7s ease-in-out infinite;
  -webkit-filter: drop-shadow(2px 3px 40px #444);
          filter: drop-shadow(2px 3px 40px #444);
        display: flex;
            align-items: center;
            justify-content: center;
          bottom: 75px;
          margin-left: 85%;
          
            
}

@-webkit-keyframes dice3 {
  from, to {
    -webkit-transform: translateX(-50px) rotateX(0deg);
            transform: translateX(-50px) rotateX(0deg);
  }

  25% {
    background: #db4437;
  }

  50% {
    background: #f4b400;
    -webkit-transform: translateX(50px) rotate(360deg);
            transform: translateX(50px) rotate(360deg);
  }

  75% {
    background: #0f9d58;
  }
}

@keyframes dice3 {
  from, to {
    -webkit-transform: translateX(-50px) rotateX(0deg);
            transform: translateX(-50px) rotateX(0deg);
  }

  25% {
    background: #db4437;
  }

  50% {
    background: #f4b400;
    -webkit-transform: translateX(50px) rotate(360deg);
            transform: translateX(50px) rotate(360deg);
  }

  75% {
    background: #0f9d58;
  }
}
/*dice

.cont{
  position: absolute;
  top: 1em;
  bottom: 1em;
  left: 1em;
  right: 1em;
  margin: auto;
  width: 100px;
  height: 100px;
  transform-style: preserve-3d;
  animation: rotate 15s infinite linear;
}
.lol{
  width: 100px;
  height: 100px;
  position: absolute;
  overflow: hidden;
  background:whitesmoke;
  border: 1px solid #ffffff;
  border-radius: 5%;
  perspective:500px;
  perspective-origin: center center;
  
  margin-right:80%;
}
.first { transform: translateZ(-50px); }
.sixth { transform: translateZ(50px); }
.second { transform: translateY(-50px) rotateX(90deg); }
.third { transform: translateY(50px) rotateX(90deg); }
.fourth { transform: translateX(-50px) rotateY(90deg); }
.fifth { transform: translateX(50px) rotateY(90deg); }
.lol span{
  position: absolute;
  top: 37%;
  left: 37%;
  width: 25%;
  height: 25%;
  border-radius: 50%;
  background: #fff;
}
.second span {background: #F0EA60;}
.third span {background: #ee6352;}
.fourth span {background: #4F7CAC;}
.fifth span {background: #48BF84;}
.sixth span {background: #E5A532;}
.lol span:before, .lol span:after {
    content: "";
    position: absolute;
    width: 100%;
    height: 100%;
    border-radius: 50%;
}
.second span{ left: 15%;}
.second span+ span{left: 60%;}
.second span:before, .second span:after {background: #F0EA60; left:0;}
.second span:before {top:-120%;}
.second span:after {top:120%;}
.third span{top:15%; left: 15%;}
.third span + span {top:65%;}
.third span:before {background: #ee6352; right: -190%;}
.third span + span:after{background: #ee6352; right: -95%; bottom:100%}
.fourth span{left: 15%;}
.fourth span:before {background: #4F7CAC; right: -165%;}
.fifth span{ left: 15%; top:15%}
.fifth span+ span{left: 60%;}
.fifth span:after  {background: #48BF84; left:0;}
.fifth span:after {top:185%;}
.sixth.lol span:before, .sixth.lol span:after {
    background: #E5A532;
    left: 0%;
}
.sixth.lol span:before{top:-120%} 
.sixth.lol span:after{top:120%}
@keyframes rotate {
  100% {
    transform: rotateX(360deg) rotateY(360deg) rotateZ(360deg);
  }
}
*/



/*earth*
#earth {
background-image: url('https://encrypted-tbn3.google.com/images?q=tbn:ANd9GcTQqoB4xBnIkmUg5pxDyYW2h0Q1pRTsbQBOfhg-E-y4iLFicsyi');
  width: 70px;
  height: 70px;
  
  box-shadow: inset 16px 0 40px 3px rgba(0,0,0,0.9),
    inset -3px 0 5px 2px rgba(255,255,255,0.16);
  background-size: 190px;
  margin: 80px auto;
  border-radius: 50%;
 
  animation-name: move,scale,rotate;
  animation-duration: 4s,4s,4s;
  animation-iteration-count: infinite,infinite,infinite;
  animation-timing-function: ease-in-out,linear,linear;
  right:-45%;
  position: relative;
  top:40%;
}

@keyframes move {
  0%   { left: 200px;  }  
  70%  { left: -200px; }
  100% { left: 200px;  }
}

@keyframes scale {
  0%  { transform: scale(1);   }
  32% { transform: scale(0.4); animation-timing-function:  ease-in; }
  70% { transform: scale(1); animation-timing-function:  ease-in;  }
  75% { transform: scale(1.2);  animation-timing-function:  ease-in-out; }
  86% { transform: scale(2);  }  
  98% { transform: scale(1.2); }
  100%{ transform: scale(1); }
}
 
@keyframes rotate {
  0% { background-position: 0px; }
  100% { background-position: 190px; }
}
*/

/*efectation*/

.effectation {
  position: absolute;
  top: 80%;
  left: 15%;
  width: 200px;
  height: 200px;
  margin-top: -100px;
  margin-left: -100px;
  -webkit-perspective: 600px;
          perspective: 600px;
  -webkit-transform-style: perserve-3d;
          transform-style: perserve-3d;
          display: flex;
            align-items: center;
            justify-content: center;
            
            
            
}

.dot {
  position: absolute;
  top: 50%;
  left: 50%;
  width: 100px;
  height: 100px;
  margin-top: -50px;
  margin-left: -50px;
  border-radius: 100px;
  border: 20px solid #1e3f57;
  -webkit-transform-style: perserve-3d;
          transform-style: perserve-3d;
  -webkit-transform: scale(0) rotateX(60deg);
          transform: scale(0) rotateX(60deg);
  -webkit-animation: dot 3s cubic-bezier(.67,.08,.46,1.5) infinite;
          animation: dot 3s cubic-bezier(.67,.08,.46,1.5) infinite;
}

.dot:nth-child(2) {
  -webkit-animation-delay: 200ms;
          animation-delay: 200ms;
}

.dot:nth-child(3) {
  -webkit-animation-delay: 400ms;
          animation-delay: 400ms;
}

.dot:nth-child(4) {
  -webkit-animation-delay: 600ms;
          animation-delay: 600ms;
}

.dot:nth-child(5) {
  -webkit-animation-delay: 800ms;
          animation-delay: 800ms;
}

.dot:nth-child(6) {
  -webkit-animation-delay: 1000ms;
          animation-delay: 1000ms;
}

.dot:nth-child(7) {
  -webkit-animation-delay: 1200ms;
          animation-delay: 1200ms;
}

.dot:nth-child(8) {
  -webkit-animation-delay: 1400ms;
          animation-delay: 1400ms;
}

@-webkit-keyframes dot {
  0% {
    opacity: 0;
    border-color: #6bb2cd;
    -webkit-transform: rotateX(60deg) rotateY(45deg) translateZ(-100px) scale(0.1);
            transform: rotateX(60deg) rotateY(45deg) translateZ(-100px) scale(0.1);
  }

  40% {
    opacity: 1;
    -webkit-transform: rotateX(0deg) rotateY(20deg) translateZ(0) scale(1);
            transform: rotateX(0deg) rotateY(20deg) translateZ(0) scale(1);
  }

  100% {
    opacity: 0;
    -webkit-transform: rotateX(60deg) rotateY(-45deg) translateZ(-100px) scale(0.1);
            transform: rotateX(60deg) rotateY(-45deg) translateZ(-100px) scale(0.1);
  }
}

@keyframes dot {
  0% {
    opacity: 0;
    border-color: #6bb2cd;
    -webkit-transform: rotateX(60deg) rotateY(45deg) translateZ(-100px) scale(0.1);
            transform: rotateX(60deg) rotateY(45deg) translateZ(-100px) scale(0.1);
  }

  40% {
    opacity: 1;
    -webkit-transform: rotateX(0deg) rotateY(20deg) translateZ(0) scale(1);
            transform: rotateX(0deg) rotateY(20deg) translateZ(0) scale(1);
  }

  100% {
    opacity: 0;
    -webkit-transform: rotateX(60deg) rotateY(-45deg) translateZ(-100px) scale(0.1);
            transform: rotateX(60deg) rotateY(-45deg) translateZ(-100px) scale(0.1);
  }
}

/*game*/
.gamer {
  position:absolute;
  height: 40px;
  width: 6px;
  color: #FFF;
  -webkit-animation: paddles 0.75s ease-out infinite;
          animation: paddles 0.75s ease-out infinite;
          display: flex;
            align-items: center;
            justify-content: center;
          
           
          left:18%;
          top:50%;
            
}

.gamer:before {
  content: "";
  position: absolute;
  margin: 0 auto;
  left: 0;
  right: 0;
  top: 15px;
  width: 12px;
  height: 12px;
  background-color: greenyellow;
  border-radius: 50%;
  -webkit-animation: ballbounce 0.6s ease-out infinite;
          animation: ballbounce 0.6s ease-out infinite;
}

@-webkit-keyframes paddles {
  0% {
    -webkit-box-shadow: -25px -10px, 25px 10px;
            box-shadow: -25px -10px, 25px 10px
  }

  50% {
    -webkit-box-shadow: -25px 8px, 25px -10px;
            box-shadow: -25px 8px, 25px -10px
  }

  100% {
    -webkit-box-shadow: -25px -10px, 25px 10px;
            box-shadow: -25px -10px, 25px 10px
  }
}

@keyframes paddles {
  0% {
    -webkit-box-shadow: -25px -10px, 25px 10px;
            box-shadow: -25px -10px, 25px 10px
  }

  50% {
    -webkit-box-shadow: -25px 8px, 25px -10px;
            box-shadow: -25px 8px, 25px -10px
  }

  100% {
    -webkit-box-shadow: -25px -10px, 25px 10px;
            box-shadow: -25px -10px, 25px 10px
  }
}

@-webkit-keyframes ballbounce {
  0% {
    -webkit-transform: translateX(-20px) scale(1, 1.2);
            transform: translateX(-20px) scale(1, 1.2)
  }

  25% {
    -webkit-transform: scale(1.2, 1);
            transform: scale(1.2, 1)
  }

  50% {
    -webkit-transform: translateX(15px) scale(1, 1.2);
            transform: translateX(15px) scale(1, 1.2)
  }

  75% {
    -webkit-transform: scale(1.2, 1);
            transform: scale(1.2, 1)
  }

  100% {
    -webkit-transform: translateX(-20px);
            transform: translateX(-20px)
  }
}

@keyframes ballbounce {
  0% {
    -webkit-transform: translateX(-20px) scale(1, 1.2);
            transform: translateX(-20px) scale(1, 1.2)
  }

  25% {
    -webkit-transform: scale(1.2, 1);
            transform: scale(1.2, 1)
  }

  50% {
    -webkit-transform: translateX(15px) scale(1, 1.2);
            transform: translateX(15px) scale(1, 1.2)
  }

  75% {
    -webkit-transform: scale(1.2, 1);
            transform: scale(1.2, 1)
  }

  100% {
    -webkit-transform: translateX(-20px);
            transform: translateX(-20px)
  }
}

/*indexer*/
.indexer {
    font-size: 10px;
    width: 40em;
    height: 40em;
    position: absolute;
   left:35%;
   top:50%;
    height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;

    overflow: hidden;
}
.sun {
    position: absolute;
    top: 15em;
    left: 15em;
    width: 10em;
    height: 10em;
    background-color: yellow;
    border-radius: 50%;
    box-shadow: 0 0 3em white;
}
.earth,.moon,.mars {
    position: absolute;
    border-style: solid;
    border-color: white transparent transparent transparent;
    border-width: 0.1em 0.1em 0 0;
    border-radius: 50%;
}
.earth {
    top: 4em;
    left: 4em;
    width: 32em;
    height: 32em; 
    animation: orbit 36.5s linear infinite;   
}
.moon {
    top: 0;
    right: 0;
    width: 8em;
    height: 8em; 
    animation: orbit 2.7s linear infinite;
}
.mars {
    top: 11em;
    left: 11em;
    width: 18em;
    height: 18em;
    animation: orbit 68.7s linear infinite;
}
.earth::before,
.moon::before,
.mars::before {
    content: '';
    position: absolute;
    border-radius: 50%;
}
.earth::before {
    top: 2.8em;
    right: 2.8em;
    width: 3em;
    height: 3em;
    background-color: aqua;    
}
.moon::before {
    top: 0.8em;
    right: 0.2em;
    width: 1.2em;
    height: 1.2em;
    background-color: silver;
}
.mars::before {
    top: 1.5em;
    right: 1.5em;
    width: 2em;
    height: 2em;
    background-color: red;
}
@keyframes orbit {
    to {
        transform: rotate(360deg);
    }
}
.star {
    position: absolute;
    background-color: white;
    border-radius: 50%;
}
.planet-name {
    display: none;
    position: absolute;
    color: white;
    font-size: 1.2em;
}
.sun:hover::after,
.earth:hover::after,
.moon:hover::after,
.mars:hover::after {
    content: attr(data-name);
    position: absolute;
    color: white;
    font-size: 1.2em;
    top: -1.5em; /* change bottom to top and adjust the value */
    left: 50%;
    transform: translateX(-50%);
}

/*jelly*/

.jelly {
  width: 12em;
  height: 3em;
  position:absolute;
  overflow: hidden;
  border-bottom: 3px solid white;
  /*-webkit-filter: url(goo);
          filter: url(goo);*/
          display: flex;
            align-items: center;
            justify-content: center;
           
            
            
           bottom:-90%;
            right:5%;
}

.jelly::before {
  content: '';
  width: 22em;
  height: 18em;
  background: #f00;
  position: absolute;
  border-radius: 50%;
  left: -2em;
  bottom: -18em;
  -webkit-animation: wee1 2s linear infinite;
          animation: wee1 2s linear infinite;
}

.jelly::after {
  content: '';
  width: 16em;
  height: 12em;
  background: #0ff;
  position: absolute;
  border-radius: 50%;
  left: -4em;
  bottom: -12em;
  -webkit-animation: wee2 2s linear infinite 0.75s;
          animation: wee2 2s linear infinite 0.75s;
}

@-webkit-keyframes wee1 {
  0% {
    -webkit-transform: translateX(-10em) rotate(0deg);
            transform: translateX(-10em) rotate(0deg);
  }

  100% {
    -webkit-transform: translateX(7em) rotate(180deg);
            transform: translateX(7em) rotate(180deg);
  }
}

@keyframes wee1 {
  0% {
    -webkit-transform: translateX(-10em) rotate(0deg);
            transform: translateX(-10em) rotate(0deg);
  }

  100% {
    -webkit-transform: translateX(7em) rotate(180deg);
            transform: translateX(7em) rotate(180deg);
  }
}

@-webkit-keyframes wee2 {
  0% {
    -webkit-transform: translateX(-8em) rotate(0deg);
            transform: translateX(-8em) rotate(0deg);
  }

  100% {
    -webkit-transform: translateX(8em) rotate(180deg);
            transform: translateX(8em) rotate(180deg);
  }
}

@keyframes wee2 {
  0% {
    -webkit-transform: translateX(-8em) rotate(0deg);
            transform: translateX(-8em) rotate(0deg);
  }

  100% {
    -webkit-transform: translateX(8em) rotate(180deg);
            transform: translateX(8em) rotate(180deg);
  }
}



/*heart*/
.heart {
  position: absolute;
  top: 50%;
  left: 90%;
  -webkit-transform: translate(-50%, -50%);
      -ms-transform: translate(-50%, -50%);
          transform: translate(-50%, -50%);
          display: flex;
            align-items: center;
            justify-content: center;
            
}

.heart .preloader {
  -webkit-animation: rotate 2.3s cubic-bezier(0.75, 0, 0.5, 1) infinite;
          animation: rotate 2.3s cubic-bezier(0.75, 0, 0.5, 1) infinite;
}

@-webkit-keyframes rotate {
  50% {
    -webkit-transform: rotate(360deg);
            transform: rotate(360deg);
  }

  100% {
    -webkit-transform: rotate(720deg);
            transform: rotate(720deg);
  }
}

@keyframes rotate {
  50% {
    -webkit-transform: rotate(360deg);
            transform: rotate(360deg);
  }

  100% {
    -webkit-transform: rotate(720deg);
            transform: rotate(720deg);
  }
}

.preloader span {
  --c: rgb(190, 30, 205);
  position: absolute;
  display: block;
  height: 64px;
  width: 64px;
  background: var(--c);
  border: 1px solid var(--c);
  border-radius: 100%;
}

.preloader span:nth-child(1) {
  -webkit-transform: translate(-28px, -28px);
      -ms-transform: translate(-28px, -28px);
          transform: translate(-28px, -28px);
  -webkit-animation: shape_1 2.3s cubic-bezier(0.75, 0, 0.5, 1) infinite;
          animation: shape_1 2.3s cubic-bezier(0.75, 0, 0.5, 1) infinite;
}

@-webkit-keyframes shape_1 {
  60% {
    -webkit-transform: scale(0.4);
            transform: scale(0.4);
  }
}

@keyframes shape_1 {
  60% {
    -webkit-transform: scale(0.4);
            transform: scale(0.4);
  }
}

.preloader span:nth-child(2) {
  -webkit-transform: translate(28px, -28px);
      -ms-transform: translate(28px, -28px);
          transform: translate(28px, -28px);
  -webkit-animation: shape_2 2.3s cubic-bezier(0.75, 0, 0.5, 1) infinite;
          animation: shape_2 2.3s cubic-bezier(0.75, 0, 0.5, 1) infinite;
}

@-webkit-keyframes shape_2 {
  40% {
    -webkit-transform: scale(0.4);
            transform: scale(0.4);
  }
}

@keyframes shape_2 {
  40% {
    -webkit-transform: scale(0.4);
            transform: scale(0.4);
  }
}

.preloader span:nth-child(3) {
  position: relative;
  border-radius: 0px;
  -webkit-transform: scale(0.98) rotate(-45deg);
      -ms-transform: scale(0.98) rotate(-45deg);
          transform: scale(0.98) rotate(-45deg);
  -webkit-animation: shape_3 2.3s cubic-bezier(0.75, 0, 0.5, 1) infinite;
          animation: shape_3 2.3s cubic-bezier(0.75, 0, 0.5, 1) infinite;
}

@-webkit-keyframes shape_3 {
  50% {
    border-radius: 100%;
    -webkit-transform: scale(0.5) rotate(-45deg);
            transform: scale(0.5) rotate(-45deg);
  }

  100% {
    -webkit-transform: scale(0.98) rotate(-45deg);
            transform: scale(0.98) rotate(-45deg);
  }
}

@keyframes shape_3 {
  50% {
    border-radius: 100%;
    -webkit-transform: scale(0.5) rotate(-45deg);
            transform: scale(0.5) rotate(-45deg);
  }

  100% {
    -webkit-transform: scale(0.98) rotate(-45deg);
            transform: scale(0.98) rotate(-45deg);
  }
}

.shadow {
  position: relative;
  top: 30px;
  left: 50%;
  -webkit-transform: translateX(-50%);
      -ms-transform: translateX(-50%);
          transform: translateX(-50%);
  display: block;
  height: 16px;
  width: 64px;
  border-radius: 50%;
  
  
  -webkit-animation: shadow 2.3s cubic-bezier(0.75, 0, 0.5, 1) infinite;
          animation: shadow 2.3s cubic-bezier(0.75, 0, 0.5, 1) infinite;
}

@-webkit-keyframes shadow {
  50% {
    -webkit-transform: translateX(-50%) scale(0.5);
            transform: translateX(-50%) scale(0.5);
    border-color: #f2f2f2;
  }
}

@keyframes shadow {
  50% {
    -webkit-transform: translateX(-50%) scale(0.5);
            transform: translateX(-50%) scale(0.5);
    border-color: #f2f2f2;
  }
}


/*maths*/

.maths {
  position: absolute;
  top: 34%;
  left: 50%;
}

.squaremaths {
  width: 8px;
  height: 30px;
  background: rgb(98, 248, 71);
  border-radius: 10px;
  display: block;
  /*margin:10px;*/
  -webkit-animation: turn 2.5s ease infinite;
  animation: turn 2.5s ease infinite;
  -webkit-box-shadow: rgb(71, 195, 248) 0px 1px 15px 0px;
          box-shadow: rgb(71, 195, 248) 0px 1px 15px 0px;
}

.topmaths {
  position: absolute;
  left: 40%;
  top: 50%;
  -webkit-transform: rotate(90deg);
  -ms-transform: rotate(90deg);
      transform: rotate(90deg);
}

.bottommaths {
  position: absolute;
  left: 40%;
  top: 50%;
  -webkit-transform: rotate(-90deg);
  -ms-transform: rotate(-90deg);
      transform: rotate(-90deg);
}

.leftmaths {
  position: absolute;
  left: 40%;
  top: 50%;
}

.rightmaths {
  position: absolute;
  left: 40%;
  top: 50%;
  -webkit-transform: rotate(-180deg);
  -ms-transform: rotate(-180deg);
      transform: rotate(-180deg);
}

@-webkit-keyframes turn {
  0% {
    -webkit-transform: translateX(0) translateY(0) rotate(0);
            transform: translateX(0) translateY(0) rotate(0);
  }

  50% {
    -webkit-transform: translateX(400%) translateY(100%) rotate(90deg);
            transform: translateX(400%) translateY(100%) rotate(90deg);
  }

  100% {
    -webkit-transform: translateX(0) translateY(0) rotate(0);
            transform: translateX(0) translateY(0) rotate(0);
  }
}

@keyframes turn {
  0% {
    -webkit-transform: translateX(0) translateY(0) rotate(0);
            transform: translateX(0) translateY(0) rotate(0);
  }

  70% {
    -webkit-transform: translateX(400%) translateY(100%) rotate(90deg);
            transform: translateX(400%) translateY(100%) rotate(90deg);
  }

  100% {
    -webkit-transform: translateX(0) translateY(0) rotate(0);
            transform: translateX(0) translateY(0) rotate(0);
  }
}

/*motioncicrlce*/
.motionc {
  width: 150px;
  height: 150px;
  border-left: 5px solid #38ff8e;
  border-radius: 50%;
  -webkit-animation: right5231 0.9s linear infinite;
          animation: right5231 0.9s linear infinite;
          display: flex;
            align-items: center;
            justify-content: center;
            position:absolute;
            left:45%;
            bottom:-35%;
            

}

.motionc::before,
  .loader::after {
  content: "";
  width: 120px;
  height: 120px;
  display: block;
  position: absolute;
  top: calc(50% - 60px);
  left: calc(50% - 60px);
  border-right: 5px solid #ffbe0b;
  border-radius: 50%;
  -webkit-animation: left036 0.9s linear infinite;
          animation: left036 0.9s linear infinite;
}

.motionc::after {
  width: 90px;
  height: 90px;
  top: calc(50% - 45px);
  left: calc(50% - 45px);
  border: 0;
  border-top: 5px solid #ff086e;
  -webkit-animation: none;
          animation: none;
}

@-webkit-keyframes right5231 {
  from {
    -webkit-transform: rotate(0deg);
            transform: rotate(0deg);
  }

  to {
    -webkit-transform: rotate(360deg);
            transform: rotate(360deg);
  }
}

@keyframes right5231 {
  from {
    -webkit-transform: rotate(0deg);
            transform: rotate(0deg);
  }

  to {
    -webkit-transform: rotate(360deg);
            transform: rotate(360deg);
  }
}

@-webkit-keyframes left036 {
  from {
    -webkit-transform: rotate(720deg);
            transform: rotate(720deg);
  }

  to {
    -webkit-transform: rotate(0deg);
            transform: rotate(0deg);
  }
}

@keyframes left036 {
  from {
    -webkit-transform: rotate(720deg);
            transform: rotate(720deg);
  }

  to {
    -webkit-transform: rotate(0deg);
            transform: rotate(0deg);
  }
}


    </style>
</head>





    
 
       


   
   










<?php 
include 'partials/header.php';
?>

    <section class="empty_page">  
    </section>
    <div class="cmmin">
        <div class="ball"></div>
    </div>

    <div class="cube-loader">
            <div class="cube-top"></div>
            <div class="cube-wrapper">
              <span style="--i:0" class="cube-span"></span>
              <span style="--i:1" class="cube-span"></span>
              <span style="--i:2" class="cube-span"></span>
              <span style="--i:3" class="cube-span"></span>
            </div>
          </div>
          
    <div class="section-center">
        <div class="section-path">
          <div class="globe">
            <div class="wrapper">
              <span></span>
              <span></span>
              <span></span>
              <span></span>
              <span></span>
              <span></span>
              <span></span>
              <span></span>
              <span></span>
              <span></span>
              <span></span>
              <span></span>
              <span></span>
              <span></span>
              <span></span>
              <span></span>
            </div>
          </div>
        </div>
       </div>

       <div class="silicon"></div>

       <section class="area">
        <div class="ball"></div>
      </section>

      <div class="sitiner">
        <div class="dash first"></div>
        <div class="dash seconde"></div>
        <div class="dash third"></div>
        <div class="dash fourth"></div>
      </div>

      <div class="commer">
        <svg viewBox="0 0 18.528 35.424" version="1.1" y="0" x="0" height="369" width="193" xmlns="http://www.w3.org/2000/svg">
        <path d="M3.358 35.05c.435-.175.646-.408.861-.95.374-.94.698-1.52 1.145-2.05.78-.92 1.757-1.638 2.666-1.957.603-.212.9-.204 1.505.041.843.343 1.597.25 2.062-.254.95-1.029 3.95-6.873 5.841-11.376.869-2.07.831-1.882.797-3.962-.034-2.106-.024-2.064-.927-3.887-1.639-3.31-4.426-6.582-7.147-8.392C8.71 1.298 6.715.504 5.296.328c-.718-.09-2.465-.001-3.183.16C.943.752.279 1.268.279 1.917c0 .119.437 1.136.97 2.26.533 1.126 1.044 2.291 1.135 2.591.334 1.106.776 3.567.945 5.27.065.652.357 1.286.751 1.633.419.367 1.351.786 1.964.883.286.044.534.096.553.115.018.018-.129.128-.327.244-.761.446-1.432 1.439-1.74 2.574-.216.802-.194 2.914.045 4.121.24 1.212.575 2.318 1.031 3.403.46 1.092.535 1.458.439 2.135-.223 1.575-1.958 4.03-3.489 4.937-.693.41-.885.587-1.066.98-.173.375-.185.535-.069.953.223.802 1.206 1.326 1.937 1.033z" fill="#000"></path>
        </svg>
        <svg viewBox="0 0 2.4 14.4" version="1.1" y="0" x="0" height="150" width="25" xmlns="http://www.w3.org/2000/svg">
        <path d="M2.2 13c0 .641-.447 1.16-1 1.16-.553 0-1-.519-1-1.16V1.4C.2.759.647.24 1.2.24c.553 0 1 .519 1 1.16z" fill="#000"></path>
        </svg>
        <svg viewBox="0 0 18.528 35.424" version="1.1" y="0" x="0" height="369" width="193" xmlns="http://www.w3.org/2000/svg">
        <path d="M15.105 35.155c-.42-.196-.627-.482-.902-1.253-.544-1.517-2.145-3.126-3.636-3.652-.69-.243-.887-.242-1.486.01-.617.26-1.342.278-1.798.045-.555-.283-1.76-2.262-3.476-5.708C2.628 22.232.984 18.575.455 17.144c-.236-.637-.237-.655-.237-2.485 0-2.164.01-2.209.9-4.013 1.011-2.049 2.53-4.189 4.185-5.9C7.679 2.293 9.783.995 12.49.313c.782-.197 1.554-.236 2.695-.137 1.619.14 2.38.38 2.882.909.21.22.246.321.243.684-.002.373-.122.67-.959 2.395-1.277 2.63-1.59 3.806-2.035 7.63-.111.951-.316 1.426-.809 1.87-.52.47-1.306.807-2.165.928l-.391.054.35.224c.897.574 1.58 1.674 1.834 2.956.193.969.12 2.791-.164 4.15-.222 1.061-.696 2.518-1.12 3.443-.336.735-.411 1.584-.203 2.3.505 1.738 2.056 3.692 3.736 4.705.693.417.938.83.874 1.476-.104 1.071-1.193 1.706-2.153 1.256z" fill="#000"></path>
        </svg>
    </div>

    <div class="container">
        <div class="circle1">
            <div class="circle2"></div>
        </div>
    </div>

    <div class="collide">
        <div class="face">
            <div class="circle"></div>
        </div>
        <div class="face">
            <div class="circle"></div>
        </div>
    </div>

    <div class="cubedescon">
  <div class="sides side-1"></div>
  <div class="sides side-2"></div>
  <div class="sides side-3"></div>
  <div class="sides side-4"></div>
  <div class="sides side-5"></div>
  <div class="sides side-6"></div>
</div>

<div class="dancer"></div>

<div class="cont">
  <div class="first lol"><span></span></div>
  <div class="second lol"><span></span><span></span></div>
  <div class="third lol"><span></span><span></span></div>
  <div class="fourth lol"><span></span></div>
  <div class="fifth lol"><span></span><span></span></div>
  <div class="sixth lol"><span></span></div>
</div>


<div id="earth"></div>

<div class="effectation">
        <div class="dot"></div>
        <div class="dot"></div>
        <div class="dot"></div>
        <div class="dot"></div>
        <div class="dot"></div>
        <div class="dot"></div>
        <div class="dot"></div>
        <div class="dot"></div>
      </div>



      <div class="gamer"></div>


      <div class="indexer">
    <div class="sun">
      <div class="planet-name" data-name="Sun">Sun</div>
    </div>
    <div class="earth">
      <div class="planet-name" data-name="Earth">Earth</div>
      <div class="moon">
        <div class="planet-name" data-name="Moon">Moon</div>
      </div>
    </div>
    <div class="mars">
      <div class="planet-name" data-name="Mars">Mars</div>
    </div>
  </div>
  <script>
    function createStars() {
      const container = document.querySelector('.indexer');
      for (let i = 0; i < 1000; i++) { // Increase the number of stars to 1000
        const star = document.createElement('div');
        star.className = 'star';
        star.style.width = '1px';
        star.style.height = '1px';
        star.style.top = Math.random() * 100 + '%';
        star.style.left = Math.random() * 100 + '%';
        indexer.appendChild(star);
      }
    }
    createStars();
  </script>


<svg style="position: absolute; width: 0; height: 0;">
        <filter id="goo">
        <feGaussianBlur in="SourceGraphic" stdDeviation="12"></feGaussianBlur>
        <feColorMatrix values="0 0 0 0 0 
                  0 0 0 0 0 
                  0 0 0 0 0 
                  0 0 0 48 -7"></feColorMatrix>
      </filter>
      </svg>
      
      <div class="jelly"></div>


      <div class="heart">
        <div class="preloader">
          <span></span>
          <span></span>
          <span></span>
        </div>
        <div class="shadow"></div>
      </div>


      <div class="maths">
        <div class="topmaths">
          <div class="squaremaths">
            <div class="squaremaths">
              <div class="squaremaths">
                <div class="squaremaths">
                  <div class="squaremaths"><div class="squaremaths">
                  </div></div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="bottommaths">
          <div class="squaremaths">
            <div class="squaremaths">
              <div class="squaremaths">
                <div class="squaremaths">
                  <div class="squaremaths"><div class="squaremaths">
                  </div></div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="leftmaths">
          <div class="squaremaths">
            <div class="squaremaths">
              <div class="squaremaths">
                <div class="squaremaths">
                  <div class="squaremaths"><div class="squaremaths">
                  </div></div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="rightmaths">
          <div class="squaremaths">
            <div class="squaremaths">
              <div class="squaremaths">
                <div class="squaremaths">
                  <div class="squaremaths"><div class="squaremaths">
                  </div></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>


      <div class="motionc"></div>



    <?php
    include 'partials/footer.php';
    ?>

</html>



