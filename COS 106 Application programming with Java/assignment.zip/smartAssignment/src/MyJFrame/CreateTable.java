/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MyJFrame;

import javax.swing.JOptionPane;
import java.sql.*;
import java.util.Arrays;


/**
 *
 * @author User
 */
public class CreateTable extends javax.swing.JFrame {
Connection conn=null;
Statement stmt=null;
ResultSet rs=null;
    /**
     * Creates new form CreateTable
     */
    public CreateTable() {
        initComponents();
        clearPanels();
    }
    
    private String[] DataOne(){
        String kName1=txtcol1.getText();
        String ktype1=combo1.getSelectedItem().toString();
        String Non1;
        String Primary1;
        if(cbnull1.isSelected()==true)
        {
            Non1="NUll";
        }
        else
        {
            Non1="NOT NULL";
        }
        if(cbpr1.isSelected()==true)
        {
            Primary1="PRIMARY KEY";
        }
        else{
            Primary1="";
        }
        String[]Data={kName1,ktype1,Non1,Primary1};
        return Data;
    
}
   private String[] Datatwo(){
        String kName2=txtcol2.getText();
        String ktype2=combo2.getSelectedItem().toString();
        String Non2;
        String Primary2;
        if(cbnull2.isSelected()==true)
        {
            Non2="NUll";
        }
        else
        {
            Non2="NOT NULL";
        }
        if(cbpr2.isSelected()==true)
        {
            Primary2="PRIMARY KEY";
        }
        else{
            Primary2="";
        }
        int messi=4;
        String[] previousData=DataOne();
        String[]currentData={kName2,ktype2,Non2,Primary2};
        
        String[] resultData=new String[previousData.length+currentData.length];
        System.arraycopy(previousData,0,resultData,0,previousData.length);
        System.arraycopy(currentData,0,resultData,messi,currentData.length);
        System.out.println("2 check"+Arrays.toString(resultData));
        return resultData;
   }
   
   private String[] Datathree(){
        String kName3=txtcol3.getText();
        String ktype3=combo3.getSelectedItem().toString();
        String Non3;
        String Primary3;
        if(cbnull3.isSelected()==true)
        {
            Non3="NUll";
        }
        else
        {
            Non3="NOT NULL";
        }
        if(cbpr3.isSelected()==true)
        {
            Primary3="PRIMARY KEY";
        }
        else{
            Primary3="";
        }
        int SRK=8;
        String[] previousData=Datatwo();
        String[]currentData={kName3,ktype3,Non3,Primary3};
        
        String[] resultData=new String[previousData.length+currentData.length];
        System.out.println("3 length chekck"+resultData.length);
        System.arraycopy(previousData,0,resultData,0,previousData.length);
        System.arraycopy(currentData,0,resultData,SRK,currentData.length);
         System.out.println("3 check"+Arrays.toString(resultData));
        return resultData;
   }
   private String[] Datafour(){
        String kName4=txtcol4.getText();
        String ktype4=combo4.getSelectedItem().toString();
        String Non4;
        String Primary4;
        if(cbnull4.isSelected()==true)
        {
            Non4="NUll";
        }
        else
        {
            Non4="NOT NULL";
        }
        if(cbpr4.isSelected()==true)
        {
            Primary4="PRIMARY KEY";
        }
        else{
            Primary4="";
        }
        int BBK=12;
        String[] previousData=Datathree();
        String[]currentData={kName4,ktype4,Non4,Primary4};
        
        String[] resultData=new String[previousData.length+currentData.length];
        System.arraycopy(previousData,0,resultData,0,previousData.length);
        System.arraycopy(currentData,0,resultData,BBK,currentData.length);
         System.out.println("4 check"+Arrays.toString(resultData));
        return resultData;
   }
   
    private String[] Datafive(){
        String kName5=txtcol5.getText();
        String ktype5=combo5.getSelectedItem().toString();
        String Non5;
        String Primary5;
        if(cbnull5.isSelected()==true)
        {
            Non5="NUll";
        }
        else
        {
            Non5="NOT NULL";
        }
        if(cbpr5.isSelected()==true)
        {
            Primary5="PRIMARY KEY";
        }
        else{
            Primary5="";
        }
        int Neymar=16;
        String[] previousData=Datafour();
        String[]currentData={kName5,ktype5,Non5,Primary5};
        
        String[] resultData=new String[previousData.length+currentData.length];
        System.arraycopy(previousData,0,resultData,0,previousData.length);
        System.arraycopy(currentData,0,resultData,Neymar,currentData.length);
         System.out.println("4 check"+Arrays.toString(resultData));
        return resultData;
   }
    private String[] Datasix(){
        String kName6=txtcol6.getText();
        String ktype6=combo6.getSelectedItem().toString();
        String Non6;
        String Primary6;
        if(cbnull6.isSelected()==true)
        {
            Non6="NUll";
        }
        else
        {
            Non6="NOT NULL";
        }
        if(cbpr6.isSelected()==true)
        {
            Primary6="PRIMARY KEY";
        }
        else{
            Primary6="";
        }
        int Suarez=20;
        String[] previousData=Datafive();
        String[]currentData={kName6,ktype6,Non6,Primary6};
        
        String[] resultData=new String[previousData.length+currentData.length];
        System.arraycopy(previousData,0,resultData,0,previousData.length);
        System.arraycopy(currentData,0,resultData,Suarez,currentData.length);
         System.out.println("5 check"+Arrays.toString(resultData));
        return resultData;
   }
     private String[] Dataseven(){
        String kName7=txtcol7.getText();
        String ktype7=combo7.getSelectedItem().toString();
        String Non7;
        String Primary7;
        if(cbnull7.isSelected()==true)
        {
            Non7="NUll";
        }
        else
        {
            Non7="NOT NULL";
        }
        if(cbpr7.isSelected()==true)
        {
            Primary7="PRIMARY KEY";
        }
        else{
            Primary7="";
        }
        int Ronaldo=24;
        String[] previousData=Datasix();
        String[]currentData={kName7,ktype7,Non7,Primary7};
        
        String[] resultData=new String[previousData.length+currentData.length];
        System.arraycopy(previousData,0,resultData,0,previousData.length);
        System.arraycopy(currentData,0,resultData,Ronaldo,currentData.length);
         System.out.println("6 check"+Arrays.toString(resultData));
        return resultData;
   }
   
   private String[] Dataeight(){
        String kName8=txtcol8.getText();
        String ktype8=combo8.getSelectedItem().toString();
        String Non8;
        String Primary8;
        if(cbnull8.isSelected()==true)
        {
            Non8="NUll";
        }
        else
        {
            Non8="NOT NULL";
        }
        if(cbpr8.isSelected()==true)
        {
            Primary8="PRIMARY KEY";
        }
        else{
            Primary8="";
        }
        int Benzema=28;
        String[] previousData=Dataseven();
        String[]currentData={kName8,ktype8,Non8,Primary8};
        
        String[] resultData=new String[previousData.length+currentData.length];
        System.arraycopy(previousData,0,resultData,0,previousData.length);
        System.arraycopy(currentData,0,resultData,Benzema,currentData.length);
         System.out.println("7 check"+Arrays.toString(resultData));
        return resultData;
   }
   private String[] Datanine(){
        String kName9=txtcol9.getText();
        String ktype9=combo9.getSelectedItem().toString();
        String Non9;
        String Primary9;
        if(cbnull9.isSelected()==true)
        {
            Non9="NUll";
        }
        else
        {
            Non9="NOT NULL";
        }
        if(cbpr9.isSelected()==true)
        {
            Primary9="PRIMARY KEY";
        }
        else{
            Primary9="";
        }
        int Lewandoski=32;
        String[] previousData=Dataeight();
        String[]currentData={kName9,ktype9,Non9,Primary9};
        
        String[] resultData=new String[previousData.length+currentData.length];
        System.arraycopy(previousData,0,resultData,0,previousData.length);
        System.arraycopy(currentData,0,resultData,Lewandoski,currentData.length);
         System.out.println("8 check"+Arrays.toString(resultData));
        return resultData;
   }
   private String[] Dataten(){
        String kName10=txtcol10.getText();
        String ktype10=combo10.getSelectedItem().toString();
        String Non10;
        String Primary10;
        if(cbnull10.isSelected()==true)
        {
            Non10="NUll";
        }
        else
        {
            Non10="NOT NULL";
        }
        if(cbpr10.isSelected()==true)
        {
            Primary10="PRIMARY KEY";
        }
        else{
            Primary10="";
        }
        int Kreethi=36;
        String[] previousData=Datanine();
        String[]currentData={kName10,ktype10,Non10,Primary10};
        
        String[] resultData=new String[previousData.length+currentData.length];
        System.arraycopy(previousData,0,resultData,0,previousData.length);
        System.arraycopy(currentData,0,resultData,Kreethi,4);
        System.out.println("9 check "+Arrays.toString(resultData));
        return resultData;
   }
   
   
   
    
    public void clearPanels(){
        panel1.setVisible(false);
        panel2.setVisible(false);
        panel3.setVisible(false);
        panel4.setVisible(false);
        panel5.setVisible(false);
        panel6.setVisible(false);
        panel7.setVisible(false);
        panel8.setVisible(false);
        panel9.setVisible(false);
        panel10.setVisible(false);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        txxtab = new javax.swing.JTextField();
        cmbTableColumnCount = new javax.swing.JComboBox<>();
        jLabel2 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        panel1 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        txtcol1 = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        combo1 = new javax.swing.JComboBox<>();
        cbnull1 = new javax.swing.JCheckBox();
        cbpr1 = new javax.swing.JCheckBox();
        panel2 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        txtcol2 = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        combo2 = new javax.swing.JComboBox<>();
        cbnull2 = new javax.swing.JCheckBox();
        cbpr2 = new javax.swing.JCheckBox();
        panel4 = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        txtcol4 = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        combo4 = new javax.swing.JComboBox<>();
        cbnull4 = new javax.swing.JCheckBox();
        cbpr4 = new javax.swing.JCheckBox();
        panel3 = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        txtcol3 = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        combo3 = new javax.swing.JComboBox<>();
        cbnull3 = new javax.swing.JCheckBox();
        cbpr3 = new javax.swing.JCheckBox();
        panel5 = new javax.swing.JPanel();
        jLabel11 = new javax.swing.JLabel();
        txtcol5 = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        combo5 = new javax.swing.JComboBox<>();
        cbnull5 = new javax.swing.JCheckBox();
        cbpr5 = new javax.swing.JCheckBox();
        panel7 = new javax.swing.JPanel();
        jLabel13 = new javax.swing.JLabel();
        txtcol7 = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        combo7 = new javax.swing.JComboBox<>();
        cbnull7 = new javax.swing.JCheckBox();
        cbpr7 = new javax.swing.JCheckBox();
        panel8 = new javax.swing.JPanel();
        jLabel17 = new javax.swing.JLabel();
        txtcol8 = new javax.swing.JTextField();
        jLabel18 = new javax.swing.JLabel();
        combo8 = new javax.swing.JComboBox<>();
        cbnull8 = new javax.swing.JCheckBox();
        cbpr8 = new javax.swing.JCheckBox();
        panel9 = new javax.swing.JPanel();
        jLabel19 = new javax.swing.JLabel();
        txtcol9 = new javax.swing.JTextField();
        jLabel20 = new javax.swing.JLabel();
        combo9 = new javax.swing.JComboBox<>();
        cbnull9 = new javax.swing.JCheckBox();
        cbpr9 = new javax.swing.JCheckBox();
        panel10 = new javax.swing.JPanel();
        jLabel21 = new javax.swing.JLabel();
        txtcol10 = new javax.swing.JTextField();
        jLabel22 = new javax.swing.JLabel();
        combo10 = new javax.swing.JComboBox<>();
        cbnull10 = new javax.swing.JCheckBox();
        cbpr10 = new javax.swing.JCheckBox();
        panel6 = new javax.swing.JPanel();
        jLabel15 = new javax.swing.JLabel();
        txtcol6 = new javax.swing.JTextField();
        jLabel16 = new javax.swing.JLabel();
        combo6 = new javax.swing.JComboBox<>();
        cbnull6 = new javax.swing.JCheckBox();
        cbpr6 = new javax.swing.JCheckBox();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setText("TABLE NAME");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(43, 26, -1, 20));
        getContentPane().add(txxtab, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 26, 113, -1));

        cmbTableColumnCount.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "SELECT", "2", "3", "4", "5", "6", "7", "8", "9", "10" }));
        getContentPane().add(cmbTableColumnCount, new org.netbeans.lib.awtextra.AbsoluteConstraints(444, 26, 97, -1));

        jLabel2.setText("NO. OF COLUMNS");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(306, 29, -1, -1));

        jButton1.setText("CREATE");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(684, 25, -1, -1));

        jButton2.setText("SET");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(575, 25, 73, -1));

        jLabel3.setText("COLUMN NAME 1");

        jLabel4.setText("DATA TYPE");

        combo1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "INT", "FLOAT", "DOUBLE", "VARCHAR(20)", "NCHAR(20)", "BIT", "CHAR(20)", "DECIMAL", "TEXT" }));

        cbnull1.setText("NULL");

        cbpr1.setText("PRIMARY KEY");

        javax.swing.GroupLayout panel1Layout = new javax.swing.GroupLayout(panel1);
        panel1.setLayout(panel1Layout);
        panel1Layout.setHorizontalGroup(
            panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel1Layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addComponent(jLabel3)
                .addGap(33, 33, 33)
                .addComponent(txtcol1, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(43, 43, 43)
                .addComponent(jLabel4)
                .addGap(26, 26, 26)
                .addComponent(combo1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30)
                .addComponent(cbnull1, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(cbpr1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        panel1Layout.setVerticalGroup(
            panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel1Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addGroup(panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(txtcol1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4)
                    .addComponent(combo1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cbnull1)
                    .addComponent(cbpr1))
                .addContainerGap(17, Short.MAX_VALUE))
        );

        getContentPane().add(panel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 70, -1, -1));

        jLabel5.setText("COLUMN NAME 2");

        jLabel6.setText("DATA TYPE");

        combo2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "INT", "FLOAT", "DOUBLE", "VARCHAR(20)", "NCHAR(20)", "BIT", "CHAR(20)", "DECIMAL", "TEXT" }));

        cbnull2.setText("NULL");

        cbpr2.setText("PRIMARY KEY");

        javax.swing.GroupLayout panel2Layout = new javax.swing.GroupLayout(panel2);
        panel2.setLayout(panel2Layout);
        panel2Layout.setHorizontalGroup(
            panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel5)
                .addGap(33, 33, 33)
                .addComponent(txtcol2, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(43, 43, 43)
                .addComponent(jLabel6)
                .addGap(26, 26, 26)
                .addComponent(combo2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(40, 40, 40)
                .addComponent(cbnull2, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(cbpr2, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27))
        );
        panel2Layout.setVerticalGroup(
            panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel2Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addGroup(panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(txtcol2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6)
                    .addComponent(combo2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cbnull2)
                    .addComponent(cbpr2))
                .addContainerGap(21, Short.MAX_VALUE))
        );

        getContentPane().add(panel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 130, -1, -1));

        jLabel7.setText("COLUMN NAME 4");

        jLabel8.setText("DATA TYPE");

        combo4.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "INT", "FLOAT", "DOUBLE", "VARCHAR(20)", "NCHAR(20)", "BIT", "CHAR(20)", "DECIMAL", "TEXT" }));

        cbnull4.setText("NULL");

        cbpr4.setText("PRIMARY KEY");

        javax.swing.GroupLayout panel4Layout = new javax.swing.GroupLayout(panel4);
        panel4.setLayout(panel4Layout);
        panel4Layout.setHorizontalGroup(
            panel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel4Layout.createSequentialGroup()
                .addContainerGap(21, Short.MAX_VALUE)
                .addComponent(jLabel7)
                .addGap(33, 33, 33)
                .addComponent(txtcol4, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(39, 39, 39)
                .addComponent(jLabel8)
                .addGap(18, 18, 18)
                .addComponent(combo4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(40, 40, 40)
                .addComponent(cbnull4, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(cbpr4, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30))
        );
        panel4Layout.setVerticalGroup(
            panel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel4Layout.createSequentialGroup()
                .addGroup(panel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panel4Layout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addGroup(panel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel7)
                            .addComponent(txtcol4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel8)
                            .addComponent(combo4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(cbnull4)))
                    .addGroup(panel4Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(cbpr4, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(21, Short.MAX_VALUE))
        );

        getContentPane().add(panel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(43, 266, 720, 60));

        jLabel9.setText("COLUMN NAME 3");

        jLabel10.setText("DATA TYPE");

        combo3.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "INT", "FLOAT", "DOUBLE", "VARCHAR(20)", "NCHAR(20)", "BIT", "CHAR(20)", "DECIMAL", "TEXT" }));

        cbnull3.setText("NULL");

        cbpr3.setText("PRIMARY KEY");

        javax.swing.GroupLayout panel3Layout = new javax.swing.GroupLayout(panel3);
        panel3.setLayout(panel3Layout);
        panel3Layout.setHorizontalGroup(
            panel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel9)
                .addGap(34, 34, 34)
                .addComponent(txtcol3, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42)
                .addComponent(jLabel10)
                .addGap(18, 18, 18)
                .addComponent(combo3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(38, 38, 38)
                .addComponent(cbnull3, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(cbpr3, javax.swing.GroupLayout.DEFAULT_SIZE, 126, Short.MAX_VALUE)
                .addGap(28, 28, 28))
        );
        panel3Layout.setVerticalGroup(
            panel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel3Layout.createSequentialGroup()
                .addGap(4, 4, 4)
                .addGroup(panel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(txtcol3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel10)
                    .addComponent(combo3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cbnull3)
                    .addComponent(cbpr3, javax.swing.GroupLayout.DEFAULT_SIZE, 37, Short.MAX_VALUE))
                .addContainerGap(21, Short.MAX_VALUE))
        );

        getContentPane().add(panel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 200, -1, -1));

        jLabel11.setText("COLUMN NAME 5");

        jLabel12.setText("DATA TYPE");

        combo5.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "INT", "FLOAT", "DOUBLE", "VARCHAR(20)", "NCHAR(20)", "BIT", "CHAR(20)", "DECIMAL", "TEXT" }));

        cbnull5.setText("NULL");

        cbpr5.setText("PRIMARY KEY");

        javax.swing.GroupLayout panel5Layout = new javax.swing.GroupLayout(panel5);
        panel5.setLayout(panel5Layout);
        panel5Layout.setHorizontalGroup(
            panel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel5Layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addComponent(jLabel11)
                .addGap(26, 26, 26)
                .addComponent(txtcol5, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(43, 43, 43)
                .addComponent(jLabel12)
                .addGap(18, 18, 18)
                .addComponent(combo5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(40, 40, 40)
                .addComponent(cbnull5, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(cbpr5)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        panel5Layout.setVerticalGroup(
            panel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel5Layout.createSequentialGroup()
                .addContainerGap(20, Short.MAX_VALUE)
                .addGroup(panel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel11)
                        .addComponent(txtcol5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel12)
                        .addComponent(combo5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(cbnull5))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panel5Layout.createSequentialGroup()
                        .addComponent(cbpr5)
                        .addContainerGap())))
        );

        getContentPane().add(panel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 320, 680, 50));

        jLabel13.setText("COLUMN NAME 7");

        jLabel14.setText("DATA TYPE");

        combo7.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "INT", "FLOAT", "DOUBLE", "VARCHAR(20)", "NCHAR(20)", "BIT", "CHAR(20)", "DECIMAL", "TEXT" }));

        cbnull7.setText("NULL");

        cbpr7.setText("PRIMARY KEY");

        javax.swing.GroupLayout panel7Layout = new javax.swing.GroupLayout(panel7);
        panel7.setLayout(panel7Layout);
        panel7Layout.setHorizontalGroup(
            panel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel7Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel13)
                .addGap(33, 33, 33)
                .addComponent(txtcol7, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(43, 43, 43)
                .addComponent(jLabel14)
                .addGap(18, 18, 18)
                .addComponent(combo7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(40, 40, 40)
                .addComponent(cbnull7, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(cbpr7))
        );
        panel7Layout.setVerticalGroup(
            panel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel7Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel13)
                    .addComponent(txtcol7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel14)
                    .addComponent(combo7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cbnull7)
                    .addComponent(cbpr7))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        getContentPane().add(panel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(48, 438, -1, -1));

        jLabel17.setText("COLUMN NAME 8");

        jLabel18.setText("DATA TYPE");

        combo8.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "INT", "FLOAT", "DOUBLE", "VARCHAR(20)", "NCHAR(20)", "BIT", "CHAR(20)", "DECIMAL", "TEXT" }));

        cbnull8.setText("NULL");

        cbpr8.setText("PRIMARY KEY");

        javax.swing.GroupLayout panel8Layout = new javax.swing.GroupLayout(panel8);
        panel8.setLayout(panel8Layout);
        panel8Layout.setHorizontalGroup(
            panel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel8Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel17)
                .addGap(33, 33, 33)
                .addComponent(txtcol8, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(43, 43, 43)
                .addComponent(jLabel18)
                .addGap(18, 18, 18)
                .addComponent(combo8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(40, 40, 40)
                .addComponent(cbnull8, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(cbpr8))
        );
        panel8Layout.setVerticalGroup(
            panel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel8Layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addGroup(panel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel17)
                    .addComponent(txtcol8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel18)
                    .addComponent(combo8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cbnull8)
                    .addComponent(cbpr8))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        getContentPane().add(panel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(43, 491, -1, -1));

        jLabel19.setText("COLUMN NAME 9");

        jLabel20.setText("DATA TYPE");

        combo9.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "INT", "FLOAT", "DOUBLE", "VARCHAR(20)", "NCHAR(20)", "BIT", "CHAR(20)", "DECIMAL", "TEXT" }));

        cbnull9.setText("NULL");

        cbpr9.setText("PRIMARY KEY");

        javax.swing.GroupLayout panel9Layout = new javax.swing.GroupLayout(panel9);
        panel9.setLayout(panel9Layout);
        panel9Layout.setHorizontalGroup(
            panel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel9Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel19)
                .addGap(33, 33, 33)
                .addComponent(txtcol9, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(43, 43, 43)
                .addComponent(jLabel20)
                .addGap(18, 18, 18)
                .addComponent(combo9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(40, 40, 40)
                .addComponent(cbnull9, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(cbpr9))
        );
        panel9Layout.setVerticalGroup(
            panel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel9Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel19)
                    .addComponent(txtcol9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel20)
                    .addComponent(combo9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cbnull9)
                    .addComponent(cbpr9))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        getContentPane().add(panel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(43, 546, -1, -1));

        jLabel21.setText("COLUMN NAME 10");

        jLabel22.setText("DATA TYPE");

        combo10.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "INT", "FLOAT", "DOUBLE", "VARCHAR(20)", "NCHAR(20)", "BIT", "CHAR(20)", "DECIMAL", "TEXT" }));
        combo10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                combo10ActionPerformed(evt);
            }
        });

        cbnull10.setText("NULL");

        cbpr10.setText("PRIMARY KEY");
        cbpr10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbpr10ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panel10Layout = new javax.swing.GroupLayout(panel10);
        panel10.setLayout(panel10Layout);
        panel10Layout.setHorizontalGroup(
            panel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel10Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel21)
                .addGap(33, 33, 33)
                .addComponent(txtcol10, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(43, 43, 43)
                .addComponent(jLabel22)
                .addGap(18, 18, 18)
                .addComponent(combo10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(40, 40, 40)
                .addComponent(cbnull10, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(cbpr10)
                .addGap(18, 18, 18))
        );
        panel10Layout.setVerticalGroup(
            panel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel10Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel21)
                    .addComponent(txtcol10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel22)
                    .addComponent(combo10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cbnull10)
                    .addComponent(cbpr10))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        getContentPane().add(panel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(43, 594, 677, -1));

        jLabel15.setText("COLUMN NAME 6");

        jLabel16.setText("DATA TYPE");

        combo6.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "INT", "FLOAT", "DOUBLE", "VARCHAR(20)", "NCHAR(20)", "BIT", "CHAR(20)", "DECIMAL", "TEXT" }));

        cbnull6.setText("NULL");

        cbpr6.setText("PRIMARY KEY");

        javax.swing.GroupLayout panel6Layout = new javax.swing.GroupLayout(panel6);
        panel6.setLayout(panel6Layout);
        panel6Layout.setHorizontalGroup(
            panel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel6Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel15)
                .addGap(33, 33, 33)
                .addComponent(txtcol6, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(43, 43, 43)
                .addComponent(jLabel16)
                .addGap(18, 18, 18)
                .addComponent(combo6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(40, 40, 40)
                .addComponent(cbnull6, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(cbpr6)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        panel6Layout.setVerticalGroup(
            panel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel6Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(panel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel15)
                    .addComponent(txtcol6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel16)
                    .addComponent(combo6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cbnull6)
                    .addComponent(cbpr6))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        getContentPane().add(panel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(43, 380, -1, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void cbpr10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbpr10ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cbpr10ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
      if(cmbTableColumnCount.getSelectedIndex() != 0){
         int index = cmbTableColumnCount.getSelectedIndex()+1;
        if(index == 2){
        panel1.setVisible(true);
        panel2.setVisible(true);
        panel3.setVisible(false);
        panel4.setVisible(false);
        panel5.setVisible(false);
        panel6.setVisible(false);
        panel7.setVisible(false);
        panel8.setVisible(false);
        panel9.setVisible(false);
        panel10.setVisible(false);
        }else if(index == 3){
          panel1.setVisible(true);
        panel2.setVisible(true);
        panel3.setVisible(true);
        panel4.setVisible(false);
        panel5.setVisible(false);
        panel6.setVisible(false);
        panel7.setVisible(false);
        panel8.setVisible(false);
        panel9.setVisible(false);
        panel10.setVisible(false);          
        }
        if(index==4){
            panel1.setVisible(true);
            panel2.setVisible(true);
            panel3.setVisible(true);
            panel4.setVisible(true);
            panel5.setVisible(false);
            panel6.setVisible(false);
            panel7.setVisible(false);
            panel8.setVisible(false);
            panel9.setVisible(false);
            panel10.setVisible(false);
        }
        if(index==5){
            panel1.setVisible(true);
            panel2.setVisible(true);
            panel3.setVisible(true);
            panel4.setVisible(true);
            panel5.setVisible(true);
            panel6.setVisible(false);
            panel7.setVisible(false);
            panel8.setVisible(false);
            panel9.setVisible(false);
            panel10.setVisible(false);
        }
        if(index==6){
            panel1.setVisible(true);
            panel2.setVisible(true);
            panel3.setVisible(true);
            panel4.setVisible(true);
            panel5.setVisible(true);
            panel6.setVisible(true);
            panel7.setVisible(false);
            panel8.setVisible(false);
            panel9.setVisible(false);
            panel10.setVisible(false);
        }
        if(index==7)
        {
            panel1.setVisible(true);
            panel2.setVisible(true);
            panel3.setVisible(true);
            panel4.setVisible(true);
            panel5.setVisible(true);
            panel6.setVisible(true);
            panel7.setVisible(true);
            panel8.setVisible(false);
            panel9.setVisible(false);
            panel10.setVisible(false);
        }
        if(index==8)
        {
            panel1.setVisible(true);
            panel2.setVisible(true);
            panel3.setVisible(true);
            panel4.setVisible(true);
            panel5.setVisible(true);
            panel6.setVisible(true);
            panel7.setVisible(true);
            panel8.setVisible(true);
            panel9.setVisible(false);
            panel10.setVisible(false);
        }
        if(index==9){
            panel1.setVisible(true);
            panel2.setVisible(true);
            panel3.setVisible(true);
            panel4.setVisible(true);
            panel5.setVisible(true);
            panel6.setVisible(true);
            panel7.setVisible(true);
            panel8.setVisible(true);
            panel9.setVisible(true);
            panel10.setVisible(false);
            
        }
        if(index==10){
            panel1.setVisible(true);
            panel2.setVisible(true);
            panel3.setVisible(true);
            panel4.setVisible(true);
            panel5.setVisible(true);
            panel6.setVisible(true);
            panel7.setVisible(true);
            panel8.setVisible(true);
            panel9.setVisible(true);
            panel10.setVisible(true);
        }
          
      }else{
          JOptionPane.showMessageDialog(this,"Please select a number of column first");
      }
    }//GEN-LAST:event_jButton2ActionPerformed
private void panelfirstrow(){
    
    txtcol1.setText("");
        combo1.setSelectedIndex(0);
         cbnull1.setSelected(false);
         cbpr1.setSelected(false);
     }
private void panelsecondrow(){
    txtcol2.setText("");
    combo2.setSelectedIndex(0);
    cbnull2.setSelected(false);
    cbpr2.setSelected(false);
    
}
private void panelthirdrow(){
    txtcol3.setText("");
    combo3.setSelectedIndex(0);
    cbnull3.setSelected(false);
    cbpr3.setSelected(false);
    
}
private void panelfourthrow(){
    txtcol4.setText("");
    combo4.setSelectedIndex(0);
    cbnull4.setSelected(false);
    cbpr4.setSelected(false);
}
private void panelfifthrow(){
    txtcol5.setText("");
    combo5.setSelectedIndex(0);
    cbnull5.setSelected(false);
    cbpr5.setSelected(false);
}
private void panelsixthrow(){
    txtcol6.setText("");
    combo6.setSelectedIndex(0);
    cbnull6.setSelected(false);
    cbpr6.setSelected(false);
}
private void panelseventhrow(){
    txtcol7.setText("");
    combo7.setSelectedIndex(0);
    cbnull7.setSelected(false);
    cbpr7.setSelected(false);
}
private void paneleighthrow(){
    txtcol8.setText("");
    combo8.setSelectedIndex(0);
    cbnull8.setSelected(false);
    cbpr8.setSelected(false);
}
private void panelninthrow(){
    txtcol9.setText("");
    combo9.setSelectedIndex(0);
    cbnull9.setSelected(false);
    cbpr9.setSelected(false);
}
private void paneltenthrow(){
    txtcol10.setText("");
    combo10.setSelectedIndex(0);
    cbnull10.setSelected(false);
    cbpr10.setSelected(false);
}
private void shut(){
    panelfirstrow();
    panelsecondrow();
    panelthirdrow();
    panelfourthrow();
    panelfifthrow();
    panelsixthrow();
    panelseventhrow();
    paneleighthrow();
    panelninthrow();
    paneltenthrow();
    
    
}
    
    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
 int index=Integer.parseInt(cmbTableColumnCount.getSelectedItem().toString()); 
 
           String tablemm=txxtab.getText(); 
           //System.out.println("10 "+index+Arrays.toString(Datatwo()));
           
           if(txxtab.getText().equals(""))
           {
               JOptionPane.showMessageDialog(this,"Please Enter your name kindley");
 }
           else{
              
               if(index>0)
               {
                   switch(index)
                   {
                       /*case 1:
                           try{
                               JOptionPane.showMessageDialog(null,"Congratulation for successful table built!");
                               Class.forName("com.mysql.jdbc.Driver");
                               Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/testDb","root","root");
                               String sql="create table testDb."+txxtab.getText()+"("+""+datamm[0]+""+datamm[1]+""+datamm[2]+""+datamm[3]+")";
                               
                               PreparedStatement pstmt=conn.prepareStatement(sql);
                               pstmt.execute();
                           }
                           catch(Exception e)
                           {
                               JOptionPane.showMessageDialog(null,e);
                           }
                           break;*/
                       case 2:
                           try{
                               JOptionPane.showMessageDialog(null,"Congratulation for successful table built!");
                               Class.forName("com.mysql.jdbc.Driver");//intialize
                               conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/testDb","root","root");//connecting database and java
                               stmt = conn.createStatement();
                               //String sql="create table testDb."+txxtab.getText()+"("+""+Datatwo()[0]+""+Datatwo()[1]+""+Datatwo()[2]+""+Datatwo()[3]+","+Datatwo()[4]+""+Datatwo()[5]+""+Datatwo()[6]+""+Datatwo()[7]+")";
                               String sql="create table "+txxtab.getText()+"("+Datatwo()[0]+" "+Datatwo()[1]+" "+Datatwo()[2]+" "+Datatwo()[3]+","+Datatwo()[4]+" "+Datatwo()[5]+" "+Datatwo()[6]+" "+Datatwo()[7]+")";
                               System.out.println("2 check"+sql);
                               stmt.execute(sql); 
                               JOptionPane.showMessageDialog(this,"Successfully created");
//                               PreparedStatement pstmt=conn.prepareStatement(sql);
//                               pstmt.execute();
                           }
                           catch(Exception e)
                           {
                               JOptionPane.showMessageDialog(null,e);
                           }
                           break;
                   
                   
                   case 3:
                   try{
                               JOptionPane.showMessageDialog(null,"Congratulation for successful table built!");
                               Class.forName("com.mysql.jdbc.Driver");//intialize
                               conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/testDb","root","root");//connecting database and java
                               stmt = conn.createStatement();
                               //String sql="create table testDb."+txxtab.getText()+"("+""+Datatwo()[0]+""+Datatwo()[1]+""+Datatwo()[2]+""+Datatwo()[3]+","+Datatwo()[4]+""+Datatwo()[5]+""+Datatwo()[6]+""+Datatwo()[7]+")";
                               String sql="create table "+txxtab.getText()+"("
                + ""+Datathree()[0]+" "+Datathree()[1]+" "+Datathree()[2]+" "+Datathree()[3]+","
                + ""+Datathree()[4]+" "+Datathree()[5]+" "+Datathree()[6]+" "+Datathree()[7]+" ,"+Datathree()[8]+" "+Datathree()[9]+" "+Datathree()[10]+" "+Datathree()[11]+")";
                               stmt.execute(sql); 
                               JOptionPane.showMessageDialog(this,"Successfully created");
//                               PreparedStatement pstmt=conn.prepareStatement(sql);
//                               pstmt.execute();
                           }
                           catch(Exception e)
                           {
                               JOptionPane.showMessageDialog(null,e);
                           }
                           break;
                           
                           
                   case 4:
                       try{
                               JOptionPane.showMessageDialog(null,"Congratulation for successful table built!");
                               Class.forName("com.mysql.jdbc.Driver");//intialize
                               conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/testDb","root","root");//connecting database and java
                               stmt = conn.createStatement();
                               //String sql="create table testDb."+txxtab.getText()+"("+""+Datatwo()[0]+""+Datatwo()[1]+""+Datatwo()[2]+""+Datatwo()[3]+","+Datatwo()[4]+""+Datatwo()[5]+""+Datatwo()[6]+""+Datatwo()[7]+")";
                               String sql="create table "+txxtab.getText()+"("
                + ""+Datafour()[0]+" "+Datafour()[1]+" "+Datafour()[2]+" "+Datafour()[3]+","
                + ""+Datafour()[4]+" "+Datafour()[5]+" "+Datafour()[6]+" "+Datafour()[7]+" ,"+Datafour()[8]+" "+Datafour()[9]+" "+Datafour()[10]+" "+Datafour()[11]+""
                                       + ", "+Datafour()[12]+" "+Datafour()[13]+" "+Datafour()[14]+" "+Datafour()[15]+")";
                               stmt.execute(sql); 
                               JOptionPane.showMessageDialog(this,"Successfully created");
//                               PreparedStatement pstmt=conn.prepareStatement(sql);
//                               pstmt.execute();
                           }
                           catch(Exception e)
                           {
                               JOptionPane.showMessageDialog(null,e);
                           }
                           break;
                           
                   case 5:
                       try{
                               JOptionPane.showMessageDialog(null,"Congratulation for successful table built!");
                               Class.forName("com.mysql.jdbc.Driver");//intialize
                               conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/testDb","root","root");//connecting database and java
                               stmt = conn.createStatement();
                               //String sql="create table testDb."+txxtab.getText()+"("+""+Datatwo()[0]+""+Datatwo()[1]+""+Datatwo()[2]+""+Datatwo()[3]+","+Datatwo()[4]+""+Datatwo()[5]+""+Datatwo()[6]+""+Datatwo()[7]+")";
                               String sql="create table "+txxtab.getText()+"("
                + ""+Datafive()[0]+" "+Datafive()[1]+" "+Datafive()[2]+" "+Datafive()[3]+","
                + ""+Datafive()[4]+" "+Datafive()[5]+" "+Datafive()[6]+" "+Datafive()[7]+" ,"+Datafive()[8]+" "+Datafive()[9]+" "+Datafive()[10]+" "+Datafive()[11]+""
                                       + ", "+Datafive()[12]+" "+Datafive()[13]+" "+Datafive()[14]+" "+Datafive()[15]+","+Datafive()[16]+" "+Datafive()[17]+" "+Datafive()[18]+" "+Datafive()[19]+")";
                               stmt.execute(sql); 
                               JOptionPane.showMessageDialog(this,"Successfully created");
//                               PreparedStatement pstmt=conn.prepareStatement(sql);
//                               pstmt.execute();
                           }
                           catch(Exception e)
                           {
                               JOptionPane.showMessageDialog(null,e);
                           }
                           break;
                           
                           case 6:
                       try{
                               JOptionPane.showMessageDialog(null,"Congratulation for successful table built!");
                               Class.forName("com.mysql.jdbc.Driver");//intialize
                               conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/testDb","root","root");//connecting database and java
                               stmt = conn.createStatement();
                               //String sql="create table testDb."+txxtab.getText()+"("+""+Datatwo()[0]+""+Datatwo()[1]+""+Datatwo()[2]+""+Datatwo()[3]+","+Datatwo()[4]+""+Datatwo()[5]+""+Datatwo()[6]+""+Datatwo()[7]+")";
                               String sql="create table "+txxtab.getText()+"("
                + ""+Datasix()[0]+" "+Datasix()[1]+" "+Datasix()[2]+" "+Datasix()[3]+","
                + ""+Datasix()[4]+" "+Datasix()[5]+" "+Datasix()[6]+" "+Datasix()[7]+" ,"+Datasix()[8]+" "+Datasix()[9]+" "+Datasix()[10]+" "+Datasix()[11]+""
                                       + ", "+Datasix()[12]+" "+Datasix()[13]+" "+Datasix()[14]+" "+Datasix()[15]+" ,"+Datasix()[16]+" "+Datasix()[17]+" "+Datasix()[18]+" "+Datasix()[19]+","+Datasix()[20]+" "+Datasix()[21]+" "+Datasix()[22]+" "+Datasix()[23]+")";
                               stmt.execute(sql); 
                               JOptionPane.showMessageDialog(this,"Successfully created");
//                               PreparedStatement pstmt=conn.prepareStatement(sql);
//                               pstmt.execute();
                           }
                           catch(Exception e)
                           {
                               JOptionPane.showMessageDialog(null,e);
                           }
                           break;
                           
                           case 7:
                               try{
                               JOptionPane.showMessageDialog(null,"Congratulation for successful table built!");
                               Class.forName("com.mysql.jdbc.Driver");//intialize
                               conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/testDb","root","root");//connecting database and java
                               stmt = conn.createStatement();
                               //String sql="create table testDb."+txxtab.getText()+"("+""+Datatwo()[0]+""+Datatwo()[1]+""+Datatwo()[2]+""+Datatwo()[3]+","+Datatwo()[4]+""+Datatwo()[5]+""+Datatwo()[6]+""+Datatwo()[7]+")";
                               String sql="create table "+txxtab.getText()+"("
                + ""+Dataseven()[0]+" "+Dataseven()[1]+" "+Dataseven()[2]+" "+Dataseven()[3]+","
                + ""+Dataseven()[4]+" "+Dataseven()[5]+" "+Dataseven()[6]+" "+Dataseven()[7]+" ,"+Dataseven()[8]+" "+Dataseven()[9]+" "+Dataseven()[10]+" "+Dataseven()[11]+""
                                       + ", "+Dataseven()[12]+" "+Dataseven()[13]+" "+Dataseven()[14]+" "+Dataseven()[15]+" ,"+Dataseven()[16]+" "+Dataseven()[17]+" "+Dataseven()[18]+" "+Dataseven()[19]+","+Dataseven()[20]+" "+Dataseven()[21]+" "+Dataseven()[22]+" "+Dataseven()[23]+""
                                       + ","+Dataseven()[24]+" "+Dataseven()[25]+" "+Dataseven()[26]+" "+Dataseven()[27]+")";
                               stmt.execute(sql); 
                               JOptionPane.showMessageDialog(this,"Successfully created");
//                               PreparedStatement pstmt=conn.prepareStatement(sql);
//                               pstmt.execute();
                           }
                           catch(Exception e)
                           {
                               JOptionPane.showMessageDialog(null,e);
                           }
                           break;
                           
                           case 8:
                               try{
                               JOptionPane.showMessageDialog(null,"Congratulation for successful table built!");
                               Class.forName("com.mysql.jdbc.Driver");//intialize
                               conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/testDb","root","root");//connecting database and java
                               stmt = conn.createStatement();
                               //String sql="create table testDb."+txxtab.getText()+"("+""+Datatwo()[0]+""+Datatwo()[1]+""+Datatwo()[2]+""+Datatwo()[3]+","+Datatwo()[4]+""+Datatwo()[5]+""+Datatwo()[6]+""+Datatwo()[7]+")";
                               String sql="create table "+txxtab.getText()+"("
                + ""+Dataeight()[0]+" "+Dataeight()[1]+" "+Dataeight()[2]+" "+Dataeight()[3]+","
                + ""+Dataeight()[4]+" "+Dataeight()[5]+" "+Dataeight()[6]+" "+Dataeight()[7]+" ,"+Dataeight()[8]+" "+Dataeight()[9]+" "+Dataeight()[10]+" "+Dataeight()[11]+""
                                       + ", "+Dataeight()[12]+" "+Dataeight()[13]+" "+Dataeight()[14]+" "+Dataeight()[15]+" ,"+Dataeight()[16]+" "+Dataeight()[17]+" "+Dataeight()[18]+" "+Dataeight()[19]+","+Dataeight()[20]+" "+Dataeight()[21]+" "+Dataeight()[22]+" "+Dataeight()[23]+""
                                       + ","+Dataeight()[24]+" "+Dataeight()[25]+" "+Dataeight()[26]+" "+Dataeight()[27]+","+Dataeight()[28]+" "+Dataeight()[29]+" "+Dataeight()[30]+" "+Dataeight()[31]+")";
                               stmt.execute(sql); 
                               JOptionPane.showMessageDialog(this,"Successfully created");
//                               PreparedStatement pstmt=conn.prepareStatement(sql);
//                               pstmt.execute();
                           }
                           catch(Exception e)
                           {
                               JOptionPane.showMessageDialog(null,e);
                           }
                           break;
                           
                           case 9:
                            try{
                               JOptionPane.showMessageDialog(null,"Congratulation for successful table built!");
                               Class.forName("com.mysql.jdbc.Driver");//intialize
                               conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/testDb","root","root");//connecting database and java
                               stmt = conn.createStatement();
                               //String sql="create table testDb."+txxtab.getText()+"("+""+Datatwo()[0]+""+Datatwo()[1]+""+Datatwo()[2]+""+Datatwo()[3]+","+Datatwo()[4]+""+Datatwo()[5]+""+Datatwo()[6]+""+Datatwo()[7]+")";
                               String sql="create table "+txxtab.getText()+"("
                + ""+Datanine()[0]+" "+Datanine()[1]+" "+Datanine()[2]+" "+Datanine()[3]+","
                + ""+Datanine()[4]+" "+Datanine()[5]+" "+Datanine()[6]+" "+Datanine()[7]+" ,"+Datanine()[8]+" "+Datanine()[9]+" "+Datanine()[10]+" "+Datanine()[11]+""
                                       + ", "+Datanine()[12]+" "+Datanine()[13]+" "+Datanine()[14]+" "+Datanine()[15]+" ,"+Datanine()[16]+" "+Datanine()[17]+" "+Datanine()[18]+" "+Datanine()[19]+","+Datanine()[20]+" "+Datanine()[21]+" "+Datanine()[22]+" "+Datanine()[23]+""
                                       + ","+Datanine()[24]+" "+Datanine()[25]+" "+Datanine()[26]+" "+Datanine()[27]+","+Datanine()[28]+" "+Datanine()[29]+" "+Datanine()[30]+" "+Datanine()[31]+""
                                       + ","+Datanine()[32]+" "+Datanine()[33]+" "+Datanine()[34]+" "+Datanine()[35]+")";
                               stmt.execute(sql); 
                               JOptionPane.showMessageDialog(this,"Successfully created");
//                               PreparedStatement pstmt=conn.prepareStatement(sql);
//                               pstmt.execute();
                           }
                           catch(Exception e)
                           {
                               JOptionPane.showMessageDialog(null,e);
                           }
                           break;
                           
                           case 10: 
                               System.out.println("work here");
                               try{
                               //JOptionPane.showMessageDialog(null,"Congratulation for successful table built!");
                               Class.forName("com.mysql.jdbc.Driver");//intialize
                               conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/testDb","root","root");//connecting database and java
                               stmt = conn.createStatement();
                               //String sql="create table testDb."+txxtab.getText()+"("+""+Datatwo()[0]+""+Datatwo()[1]+""+Datatwo()[2]+""+Datatwo()[3]+","+Datatwo()[4]+""+Datatwo()[5]+""+Datatwo()[6]+""+Datatwo()[7]+")";
                               String sql="create table "+txxtab.getText()+"("
                + ""+Dataten()[0]+" "+Dataten()[1]+" "+Dataten()[2]+" "+Dataten()[3]+","
                + ""+Dataten()[4]+" "+Dataten()[5]+" "+Dataten()[6]+" "+Dataten()[7]+" ,"+Dataten()[8]+" "+Dataten()[9]+" "+Dataten()[10]+" "+Dataten()[11]+""
                                       + ", "+Dataten()[12]+" "+Dataten()[13]+" "+Dataten()[14]+" "+Dataten()[15]+" ,"+Dataten()[16]+" "+Dataten()[17]+" "+Dataten()[18]+" "+Dataten()[19]+","+Dataten()[20]+" "+Dataten()[21]+" "+Dataten()[22]+" "+Dataten()[23]+""
                                       + ","+Dataten()[24]+" "+Dataten()[25]+" "+Dataten()[26]+" "+Dataten()[27]+","+Dataten()[28]+" "+Dataten()[29]+" "+Dataten()[30]+" "+Dataten()[31]+""
                                       + ","+Dataten()[32]+" "+Dataten()[33]+" "+Dataten()[34]+" "+Dataten()[35]+", "+Dataten()[36]+" "+Dataten()[37]+" "+Dataten()[38]+" "+Dataten()[39]+")";
                               stmt.execute(sql); 
                               JOptionPane.showMessageDialog(this,"Successfully created");
//                               PreparedStatement pstmt=conn.prepareStatement(sql);
//                               pstmt.execute();
                           }
                           catch(Exception e)
                           {
                               JOptionPane.showMessageDialog(null,e);
                           }
                           break;
                   
                   }
                   
               }else{
                   JOptionPane.showMessageDialog(this,"set the table column count");
               }
           }
           shut();
           
            
            
    }//GEN-LAST:event_jButton1ActionPerformed

    private void combo10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_combo10ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_combo10ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(CreateTable.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(CreateTable.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(CreateTable.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(CreateTable.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new CreateTable().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JCheckBox cbnull1;
    private javax.swing.JCheckBox cbnull10;
    private javax.swing.JCheckBox cbnull2;
    private javax.swing.JCheckBox cbnull3;
    private javax.swing.JCheckBox cbnull4;
    private javax.swing.JCheckBox cbnull5;
    private javax.swing.JCheckBox cbnull6;
    private javax.swing.JCheckBox cbnull7;
    private javax.swing.JCheckBox cbnull8;
    private javax.swing.JCheckBox cbnull9;
    private javax.swing.JCheckBox cbpr1;
    private javax.swing.JCheckBox cbpr10;
    private javax.swing.JCheckBox cbpr2;
    private javax.swing.JCheckBox cbpr3;
    private javax.swing.JCheckBox cbpr4;
    private javax.swing.JCheckBox cbpr5;
    private javax.swing.JCheckBox cbpr6;
    private javax.swing.JCheckBox cbpr7;
    private javax.swing.JCheckBox cbpr8;
    private javax.swing.JCheckBox cbpr9;
    private javax.swing.JComboBox<String> cmbTableColumnCount;
    private javax.swing.JComboBox<String> combo1;
    private javax.swing.JComboBox<String> combo10;
    private javax.swing.JComboBox<String> combo2;
    private javax.swing.JComboBox<String> combo3;
    private javax.swing.JComboBox<String> combo4;
    private javax.swing.JComboBox<String> combo5;
    private javax.swing.JComboBox<String> combo6;
    private javax.swing.JComboBox<String> combo7;
    private javax.swing.JComboBox<String> combo8;
    private javax.swing.JComboBox<String> combo9;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel panel1;
    private javax.swing.JPanel panel10;
    private javax.swing.JPanel panel2;
    private javax.swing.JPanel panel3;
    private javax.swing.JPanel panel4;
    private javax.swing.JPanel panel5;
    private javax.swing.JPanel panel6;
    private javax.swing.JPanel panel7;
    private javax.swing.JPanel panel8;
    private javax.swing.JPanel panel9;
    private javax.swing.JTextField txtcol1;
    private javax.swing.JTextField txtcol10;
    private javax.swing.JTextField txtcol2;
    private javax.swing.JTextField txtcol3;
    private javax.swing.JTextField txtcol4;
    private javax.swing.JTextField txtcol5;
    private javax.swing.JTextField txtcol6;
    private javax.swing.JTextField txtcol7;
    private javax.swing.JTextField txtcol8;
    private javax.swing.JTextField txtcol9;
    private javax.swing.JTextField txxtab;
    // End of variables declaration//GEN-END:variables
}
